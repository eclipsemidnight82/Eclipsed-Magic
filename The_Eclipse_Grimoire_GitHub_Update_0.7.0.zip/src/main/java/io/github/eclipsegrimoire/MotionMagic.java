package io.github.eclipsegrimoire;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Three distinct player spells with server-side safe targeting and coven exemptions. */
public final class MotionMagic {
    private MotionMagic() {}
    private static final String AURA_UNTIL="witchfireUntil";
    private static final String AURA_DIMENSION="witchfireDimension";

    public static int cast(ServerPlayer p,String spell) {
        int needed=MagicData.requiredLevel(spell);
        if(MagicData.level(p)<needed) {
            notice(p,"Unlocks at magic level "+needed+".");return 0;
        }
        if("witchfire".equals(spell) && active(p)) {
            stop(p);notice(p,"Witchfire extinguished.");return 1;
        }
        Vec3 destination=null;
        if("blink".equals(spell)) {
            destination=findBlinkDestination(p);
            if(destination==null) {notice(p,"No safe landing spot along your gaze within 20 blocks. No mana spent.");return 0;}
        }
        int cost=switch(spell) {case "pulse"->14;case "blink"->18;case "witchfire"->30;default->0;};
        if(!MagicData.spend(p,cost)) {
            notice(p,"Not enough mana: "+MagicData.mana(p)+"/"+MagicData.maxMana(p));return 0;
        }
        ServerLevel level=p.serverLevel();
        switch(spell) {
            case "pulse" -> {
                int pushed=0;
                for(Entity target:level.getEntitiesOfClass(Entity.class,p.getBoundingBox().inflate(7),
                    e->e.isAlive() && e!=p && !e.isSpectator())) {
                    if(isProtected(p,target)) continue;
                    Vec3 outward=target.getBoundingBox().getCenter().subtract(p.getBoundingBox().getCenter());
                    double d=Math.max(.1,outward.horizontalDistance());
                    if(d>7 || Math.abs(outward.y)>4.5) continue;
                    Vec3 force=new Vec3(outward.x/d*1.45,.36,outward.z/d*1.45);
                    target.setDeltaMovement(force);
                    target.hasImpulse=true;
                    if(target instanceof ServerPlayer other) other.hurtMarked=true;
                    pushed++;
                }
                // An outward air blast, with jagged radial force trails rather than the default casting sigil.
                for(int ray=0;ray<28;ray++) {
                    double a=2*Math.PI*ray/28;
                    for(int step=1;step<=12;step++) {
                        double d=.5+step*.56;
                        ArcaneEffects.point(level,MagicData.magic(p),p.position().add(Math.cos(a)*d,
                            .50+.2*Math.sin(d*2+ray),Math.sin(a)*d));
                    }
                }
                notice(p,"Telekinetic Pulse repelled "+pushed+" nearby entities.");
            }
            case "witchfire" -> {
                var data=MagicData.data(p);
                data.putLong(AURA_UNTIL,level.getGameTime()+600); // 30 seconds, no maintenance cost
                data.putString(AURA_DIMENSION,level.dimension().location().toString());
                ArcaneEffects.witchFlames(p);
                notice(p,"Witchfire surrounds you for 30 seconds. Recast to dismiss it.");
            }
            case "blink" -> {
                Vec3 from=p.position();
                ArcaneEffects.blinkBurst(level,MagicData.magic(p),from);
                p.connection.teleport(destination.x,destination.y,destination.z,p.getYRot(),p.getXRot());
                EclipseEvents.rememberTeleport(p,destination);
                p.fallDistance=0;
                ArcaneEffects.blinkBurst(level,MagicData.magic(p),destination);
                notice(p,"Blink!");
            }
        }
        MagicData.earnXp(p,4);
        net.minecraft.sounds.SoundEvent sound=switch(spell) {
            case "blink"->SoundEvents.ENDERMAN_TELEPORT;
            case "witchfire"->SoundEvents.FIRECHARGE_USE;
            default->SoundEvents.IRON_GOLEM_ATTACK;
        };
        level.playSound(null,p.blockPosition(),sound,SoundSource.PLAYERS,spell.equals("pulse")?1.3f:1f,
            spell.equals("pulse")?.52f:spell.equals("blink")?1.35f:.72f);
        return 1;
    }
    public static boolean active(ServerPlayer p) {
        var d=MagicData.data(p);
        return d.getLong(AURA_UNTIL)>p.serverLevel().getGameTime()
            && p.serverLevel().dimension().location().toString().equals(d.getString(AURA_DIMENSION));
    }
    public static void stop(ServerPlayer p) {
        MagicData.data(p).remove(AURA_UNTIL);
        MagicData.data(p).remove(AURA_DIMENSION);
    }
    public static void tick(ServerPlayer p) {
        if(!active(p) || p.tickCount%4!=0) return;
        ServerLevel level=p.serverLevel();
        String color=MagicData.magic(p);
        double r=3.1;
        if(p.tickCount%8==0) {
            ArcaneEffects.witchFlames(p);
            if(p.tickCount%32==0) ArcaneEffects.sigil(level,color,p.position().add(0,.10,0),2.1);
            level.playSound(null,p.blockPosition(),SoundEvents.FIRE_AMBIENT,SoundSource.PLAYERS,.25f,1.1f);
        }
        for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,p.getBoundingBox().inflate(3.6),
            entity->entity.isAlive() && entity!=p)) {
            if(isProtected(p,target)) continue;
            Vec3 out=target.position().subtract(p.position());
            double dist=out.horizontalDistance();
            if(dist>r+.4 || Math.abs(out.y)>2.8) continue;
            double d=Math.max(.15,dist);
            target.setDeltaMovement(out.x/d*.52,Math.max(.17,target.getDeltaMovement().y),out.z/d*.52);
            target.hasImpulse=true;
            target.setSecondsOnFire(2);
            if(p.tickCount%12==0) {
                target.hurt(p.damageSources().magic(),1.5f);
                ArcaneEffects.ring(level,color,target.getBoundingBox().getCenter(),.55,12);
            }
        }
        // Melt incoming arrows rather than blocking the owner's own shots or coven arrows.
        for(AbstractArrow arrow:level.getEntitiesOfClass(AbstractArrow.class,p.getBoundingBox().inflate(r+1.0),
            e->e.isAlive() && e.getDeltaMovement().lengthSqr()>.001)) {
            Entity owner=arrow.getOwner();
            if(owner==p || (owner!=null && isProtected(p,owner))) continue;
            if(arrow.position().distanceToSqr(p.getEyePosition())> (r+0.9)*(r+0.9)) continue;
            ArcaneEffects.ring(level,color,arrow.position(),.35,9);
            arrow.discard();
        }
    }
    private static boolean isProtected(ServerPlayer caster,Entity target) {
        if(target==caster) return true;
        if(target instanceof LivingEntity living) {
            if(SpellCasting.protectedFrom(caster,living)) return true;
            if(target instanceof ServerPlayer && !caster.server.isPvpAllowed()) return true;
        }
        if(target instanceof Projectile projectile && projectile.getOwner()!=null) {
            Entity owner=projectile.getOwner();
            return owner==caster || (owner instanceof LivingEntity living && SpellCasting.protectedFrom(caster,living));
        }
        return false;
    }
    private static Vec3 findBlinkDestination(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        Vec3 eye=p.getEyePosition(),look=p.getLookAngle();
        HitResult hit=p.pick(20,1f,false);
        Vec3 target=hit.getType()==HitResult.Type.MISS?eye.add(look.scale(20)):hit.getLocation();
        // Search back from the first solid obstruction. Never pass through a wall.
        for(double step=.8;step<=20;step+=.5) {
            Vec3 position=target.subtract(look.scale(step));
            for(int dy=-2;dy<=2;dy++) {
                BlockPos feet=BlockPos.containing(position).offset(0,dy,0);
                BlockPos below=feet.below();
                if(!level.hasChunkAt(feet) || !level.getWorldBorder().isWithinBounds(feet)) continue;
                if(!level.getBlockState(below).isFaceSturdy(level,below,Direction.UP)) continue;
                if(!level.getBlockState(feet).isAir() || !level.getBlockState(feet.above()).isAir()) continue;
                if(!level.getFluidState(feet).isEmpty() || !level.getFluidState(feet.above()).isEmpty()) continue;
                Vec3 result=new Vec3(feet.getX()+.5,feet.getY(),feet.getZ()+.5);
                AABB moved=p.getBoundingBox().move(result.x-p.getX(),result.y-p.getY(),result.z-p.getZ());
                if(!level.noCollision(p,moved)) continue;
                if(result.distanceToSqr(p.position())<1) continue;
                if(result.subtract(p.position()).dot(look)<.6) continue;
                if(result.distanceToSqr(p.position())>20*20) continue;
                return result;
            }
        }
        return null;
    }
    private static void notice(ServerPlayer p,String text) {
        p.sendSystemMessage(Component.literal("[Eclipse] "+text));
    }
}
