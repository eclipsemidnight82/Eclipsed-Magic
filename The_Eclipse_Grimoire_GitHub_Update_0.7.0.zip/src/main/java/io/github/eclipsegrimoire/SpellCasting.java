package io.github.eclipsegrimoire;

import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import org.joml.Vector3f;

/** Uses vanilla potions, particle dust, and visual-only lightning; deals spell damage directly. */
public final class SpellCasting {
    private SpellCasting() { }
    public static int cast(ServerPlayer player,String spell) {
        if ("tether".equals(spell)) return TetherMagic.cast(player);
        if ("pulse".equals(spell) || "witchfire".equals(spell) || "blink".equals(spell))
            return MotionMagic.cast(player,spell);
        int cost=switch(spell) {
            case "ward" -> 8;
            case "power" -> 10;
            case "mend" -> 12;
            case "veil","bind" -> 15;
            case "circle" -> 20;
            case "seal" -> 12;
            case "infuse" -> 8;
            case "shatter" -> 22;
            case "thunder" -> 30;
            case "aegis" -> 40;
            default -> -1;
        };
        if(cost<0) {msg(player,"Unknown spell. Use /eclipse help to view spells.");return 0;}
        int needed=MagicData.requiredLevel(spell);
        if(MagicData.level(player)<needed) {
            msg(player,"This spell unlocks at magic level " + needed + ". Current level: " + MagicData.level(player));
            return 0;
        }
        ServerLevel level=player.serverLevel();
        // Validate the space/target BEFORE charging mana. No spell cooldowns.
        if(spell.equals("infuse") && !player.getMainHandItem().is(EclipseMod.SALT.get())) {
            msg(player,"Hold ordinary white Salt in your main hand to infuse the whole stack.");return 0;
        }
        Set<BlockPos> circle=spell.equals("circle")?circlePositions(player.blockPosition()):Set.of();
        if(spell.equals("circle") && !canDrawCircle(level,circle)) {
            msg(player,"Salt Circle needs a clear, flat 7x7 patch of solid ground. No mana spent.");return 0;
        }
        WardData wards=WardData.get(level);
        Set<BlockPos> network=Set.of();
        BlockPos selectedSalt=null;
        if(spell.equals("seal") || spell.equals("shatter")) {
            HitResult hit=player.pick(8.0,1f,false);
            if(!(hit instanceof BlockHitResult blockHit) || !EclipseMod.isSalt(level.getBlockState(blockHit.getBlockPos()))) {
                msg(player,"Look directly at a salt line within 8 blocks before casting.");return 0;
            }
            selectedSalt=blockHit.getBlockPos();
            network=WardData.connectedSalt(level,selectedSalt);
            if(network.isEmpty()) {
                msg(player,"Salt connection is missing or longer than 512 blocks. No mana spent.");return 0;
            }
            if(spell.equals("seal") && network.stream().anyMatch(pos -> {
                UUID owner=wards.chargedOwner(level,pos);
                return owner!=null && !owner.equals(player.getUUID())
                    && !CovenData.get(level).same(owner,player.getUUID());
            })) {
                msg(player,"Another witch owns part of this ward. Cast Shatter first.");return 0;
            }
        }
        if(!MagicData.spend(player,cost)) {
            msg(player,"Not enough mana: " + MagicData.mana(player) + "/" + MagicData.maxMana(player));return 0;
        }
        switch(spell) {
            case "ward" -> {
                protect(player,600);
                allies(player,16).forEach(ally->protect(ally,600));
                protectPets(player,16,600);
                ArcaneEffects.sigil(level,MagicData.magic(player),player.position().add(0,.2,0),2.3);
                msg(player,"A protective ward surrounds you and your allies.");
            }
            case "power" -> {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600,1));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,600,0));
                ArcaneEffects.spiral(player,3,2.6);
                msg(player,"Your magical power surges.");
            }
            case "thunder" -> {
                ArcaneEffects.handCharge(player);
                attack(player,12,12f,8,true);
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,200,0));
                msg(player,"ALZUR'S THUNDER! You feel drained.");
            }
            case "aegis" -> {
                protect(player,800);allies(player,20).forEach(ally->protect(ally,800));
                protectPets(player,20,800);attack(player,16,16f,12,false);
                ArcaneEffects.aegis(player);
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,500,1));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,200,0));
                msg(player,"The Final Aegis! Its power exacts a price.");
            }
            case "mend" -> {
                player.heal(6f);
                allies(player,8).forEach(a->a.heal(6f));
                for(TamableAnimal pet:level.getEntitiesOfClass(TamableAnimal.class,player.getBoundingBox().inflate(8)))
                    if(protectedFrom(player,pet)) pet.heal(6f);
                ArcaneEffects.healing(player);
                msg(player,"Mending Light heals you and nearby allies.");
            }
            case "veil" -> {
                player.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY,400,0));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,600,0));
                ArcaneEffects.shadow(player);
                msg(player,"Veil of Shadows conceals you for 20 seconds.");
            }
            case "bind" -> {
                int affected=0;
                for(LivingEntity e:level.getEntitiesOfClass(LivingEntity.class,player.getBoundingBox().inflate(10),
                    e->e.isAlive() && e!=player && !protectedFrom(player,e) && e instanceof Enemy)) {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,300,3));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,300,0));
                    ArcaneEffects.chains(level,MagicData.magic(player),e.position());
                    if(++affected>=8) break;
                }
                msg(player,"Chains of Night weakens nearby monsters.");
            }
            case "circle" -> {
                for(BlockPos pos:circle) if(level.getBlockState(pos).isAir())
                    level.setBlock(pos,EclipseMod.SALT_LINE.get().defaultBlockState(),3);
                wards.enchantCircle(circle,player.getUUID());
                ArcaneEffects.saltSurge(player,player.position());
                msg(player,"Enchanted Salt Circle active. You and your coven can cross it; outsiders cannot.");
            }
            case "infuse" -> {
                ItemStack held=player.getMainHandItem();
                int amount=held.getCount();
                if(!player.isCreative()) held.shrink(amount);
                ItemStack infused=new ItemStack(EclipseMod.infusedSaltItem(MagicData.magic(player)).get(),amount);
                if(!player.getInventory().add(infused)) player.drop(infused,false);
                ArcaneEffects.spiral(player,2,1.5);
                msg(player,"Infused " + amount + " salt with your " + MagicData.magic(player) + " magic. Place it to ward the ground instantly.");
            }
            case "seal" -> {
                int count=wards.enchantNetwork(network,player.getUUID());
                ArcaneEffects.saltSurge(player,net.minecraft.world.phys.Vec3.atCenterOf(selectedSalt));
                msg(player,"Enchanted " + count + " connected salt tiles. Only you and your coven may cross.");
            }
            case "shatter" -> {
                int count=wards.shatterNetwork(network);
                // Colored blocks become white when the infusion is shattered, so visual feedback is truthful.
                for(BlockPos pos:network) if(EclipseMod.isColoredSalt(level.getBlockState(pos)))
                    level.setBlock(pos,EclipseMod.SALT_LINE.get().defaultBlockState(),3);
                level.setBlock(selectedSalt,net.minecraft.world.level.block.Blocks.AIR.defaultBlockState(),3);
                level.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                    selectedSalt.getX()+.5,selectedSalt.getY()+.5,selectedSalt.getZ()+.5,44,.5,.4,.5,.15);
                msg(player,"Shattered one salt tile and removed magic from " + count + " connected tiles.");
            }
        }
        MagicData.earnXp(player,spell.equals("circle")||spell.equals("seal")||spell.equals("shatter")?6:4);
        // Spells have distinct geometry and sonic fingerprints, not the old universal ring + chime.
        net.minecraft.sounds.SoundEvent tone=switch(spell) {
            case "thunder"->SoundEvents.LIGHTNING_BOLT_IMPACT;
            case "mend"->SoundEvents.AMETHYST_BLOCK_CHIME;
            case "ward","aegis"->SoundEvents.BEACON_ACTIVATE;
            case "veil"->SoundEvents.ILLUSIONER_CAST_SPELL;
            case "bind"->SoundEvents.EVOKER_PREPARE_ATTACK;
            case "circle","seal","infuse"->SoundEvents.ENCHANTMENT_TABLE_USE;
            case "shatter"->SoundEvents.GLASS_BREAK;
            case "power"->SoundEvents.CONDUIT_ACTIVATE;
            default->SoundEvents.EVOKER_CAST_SPELL;
        };
        float pitch=switch(spell){case "thunder"->.55f;case "mend"->1.65f;case "veil"->.8f;default->1.0f;};
        level.playSound(null,player.blockPosition(),tone,SoundSource.PLAYERS,spell.equals("thunder")?1.65f:.85f,pitch);
        return 1;
    }

    private static Set<BlockPos> circlePositions(BlockPos center) {
        Set<BlockPos> positions=new HashSet<>();
        for(int dx=-3;dx<=3;dx++) for(int dz=-3;dz<=3;dz++)
            if(Math.abs(dx)==3 || Math.abs(dz)==3) positions.add(center.offset(dx,0,dz));
        return positions;
    }
    private static boolean canDrawCircle(ServerLevel level,Set<BlockPos> positions) {
        for(BlockPos pos:positions) {
            BlockState state=level.getBlockState(pos);
            if(!level.hasChunkAt(pos) || !(state.isAir() || EclipseMod.isSalt(state))) return false;
            if(!EclipseMod.SALT_LINE.get().defaultBlockState().canSurvive(level,pos)) return false;
        }
        return true;
    }

    private static void protect(LivingEntity entity,int ticks) {
        entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,ticks,1));
        entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,ticks,1));
    }
    private static void protectPets(ServerPlayer player,double radius,int ticks) {
        for(TamableAnimal pet:player.serverLevel().getEntitiesOfClass(TamableAnimal.class, player.getBoundingBox().inflate(radius))) {
            if(protectedFrom(player,pet)) protect(pet,ticks);
        }
    }
    private static List<ServerPlayer> allies(ServerPlayer p,double r) {
        CovenData covens=CovenData.get(p.serverLevel());
        return p.serverLevel().getEntitiesOfClass(ServerPlayer.class,p.getBoundingBox().inflate(r),other->other!=p && covens.same(p.getUUID(),other.getUUID()));
    }
    public static boolean protectedFrom(ServerPlayer p,LivingEntity target) {
        if(target==p) return true;
        CovenData covens=CovenData.get(p.serverLevel());
        if(target instanceof ServerPlayer sp) return covens.same(p.getUUID(),sp.getUUID());
        if(target instanceof TamableAnimal pet && pet.isTame() && pet.getOwnerUUID()!=null) {
            UUID owner=pet.getOwnerUUID();
            return owner.equals(p.getUUID()) || covens.same(p.getUUID(),owner);
        }
        if(target.getPersistentData().hasUUID("EclipseFamiliarOwner")) {
            UUID owner=target.getPersistentData().getUUID("EclipseFamiliarOwner");
            return owner.equals(p.getUUID()) || covens.same(p.getUUID(),owner);
        }
        return false;
    }
    private static void attack(ServerPlayer p,double range,float damage,int max,boolean lightning) {
        ServerLevel level=p.serverLevel();int count=0;
        List<LivingEntity> targets=level.getEntitiesOfClass(LivingEntity.class,new AABB(p.blockPosition()).inflate(range),
            target->target.isAlive() && target!=p && !protectedFrom(p,target)
            && (target instanceof Enemy || (target instanceof ServerPlayer && p.server.isPvpAllowed())));
        targets.sort((a,b)->Double.compare(a.distanceToSqr(p),b.distanceToSqr(p)));
        for(LivingEntity target:targets) {
            if(count++ >= max) break;
            target.hurt(p.damageSources().magic(),damage);
            if(lightning) ArcaneEffects.handLightning(p,target.getBoundingBox().getCenter());
        }
    }
    public static void dust(ServerPlayer player,int count) {
        int color=switch(MagicData.magic(player)) {
            case "crimson" -> 0xe34e69; case "blue" -> 0x54a6ef; case "emerald" -> 0x43bd94;
            case "gold" -> 0xe6b74e; case "white" -> 0xe7dfe9; case "shadow" -> 0x5b526b;
            case "rose" -> 0xed91cb; default -> 0xa46af5;
        };
        Vector3f rgb=new Vector3f(((color>>16)&255)/255f,((color>>8)&255)/255f,(color&255)/255f);
        player.serverLevel().sendParticles(new DustParticleOptions(rgb,1.4f),player.getX(),player.getY()+1,player.getZ(),count,1.0,1.0,1.0,.06);
    }
    private static void msg(ServerPlayer p,String s){p.sendSystemMessage(Component.literal(s));}
}
