package io.github.eclipsegrimoire;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Distinct visual vocabularies: rings, rays, chains, wisps, stars, lightning and flame tongues. */
public final class ArcaneEffects {
    private ArcaneEffects() { }
    public static int rgb(String color) {
        return switch(color) {
            case "crimson" -> 0xe34e69;case "blue" -> 0x54a6ef;case "emerald" -> 0x43bd94;
            case "gold" -> 0xe6b74e;case "white" -> 0xe7dfe9;case "shadow" -> 0x91829f;
            case "rose" -> 0xed91cb;default -> 0xa46af5;
        };
    }
    public static DustParticleOptions dust(String color,float size) {
        int value=rgb(color);
        return new DustParticleOptions(new Vector3f(((value>>16)&255)/255f,((value>>8)&255)/255f,(value&255)/255f),size);
    }
    public static void point(ServerLevel level,String color,Vec3 at) {
        point(level,color,at,1.2f);
    }
    private static void point(ServerLevel level,String color,Vec3 at,float scale) {
        level.sendParticles(dust(color,scale),at.x,at.y,at.z,1,0,0,0,0);
    }
    public static void ring(ServerLevel level,String color,Vec3 center,double radius,int count) {
        for(int i=0;i<count;i++) {
            double a=2*Math.PI*i/count;
            point(level,color,center.add(Math.cos(a)*radius,0,Math.sin(a)*radius));
        }
    }
    public static void sigil(ServerLevel level,String color,Vec3 center,double radius) {
        ring(level,color,center,radius,44);ring(level,color,center,radius*.68,30);
        for(int i=0;i<8;i++) {
            double a=i*Math.PI/4;
            for(int j=0;j<4;j++) {
                double r=radius*(.69+j*.10);
                point(level,color,center.add(Math.cos(a)*r,.03,Math.sin(a)*r),.9f);
            }
            point(level,color,center.add(Math.cos(a)*radius*1.08,.17,Math.sin(a)*radius*1.08),1.4f);
        }
    }
    public static void castingCircle(ServerPlayer caster) {
        sigil(caster.serverLevel(),MagicData.magic(caster),caster.position().add(0,.08,0),1.6);
    }
    /** Angular twin streams emerge from visible hand-space, with branching sparks into enemies. */
    public static void handLightning(ServerPlayer caster,Vec3 destination) {
        ServerLevel level=caster.serverLevel();String color=MagicData.magic(caster);
        Vec3 look=caster.getLookAngle();
        Vec3 right=new Vec3(-look.z,0,look.x);
        if(right.lengthSqr()<.001) right=new Vec3(1,0,0);
        right=right.normalize();
        Vec3 base=caster.getEyePosition().add(look.scale(.45)).add(0,-.47,0);
        for(int side=-1;side<=1;side+=2) {
            Vec3 hand=base.add(right.scale(side*.37));
            level.sendParticles(ParticleTypes.ELECTRIC_SPARK,hand.x,hand.y,hand.z,20,.14,.13,.14,.09);
            for(int i=0;i<38;i++) {
                double t=i/37.0;
                double jitter=Math.sin(i*11.1+side*2.3)*(.10+.13*Math.sin(Math.PI*t));
                Vec3 sample=hand.lerp(destination,t).add(right.scale(jitter)).add(0,Math.cos(i*7.0)*.09,0);
                point(level,color,sample,i%6==0?1.85f:1.2f);
                if(i%4==0)level.sendParticles(ParticleTypes.ELECTRIC_SPARK,sample.x,sample.y,sample.z,1,.04,.04,.04,.01);
            }
        }
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,destination.x,destination.y,destination.z,30,.5,.6,.5,.07);
    }
    public static void handCharge(ServerPlayer caster) {
        String color=MagicData.magic(caster);ServerLevel level=caster.serverLevel();
        Vec3 forward=caster.getLookAngle();Vec3 sideways=new Vec3(-forward.z,0,forward.x);
        if(sideways.lengthSqr()<.001) sideways=new Vec3(1,0,0);
        sideways=sideways.normalize();
        Vec3 base=caster.getEyePosition().add(forward.scale(.45)).add(0,-.50,0);
        for(int side=-1;side<=1;side+=2) {
            Vec3 hand=base.add(sideways.scale(.38*side));
            for(int i=0;i<20;i++) {
                double a=i*Math.PI/10;
                point(level,color,hand.add(Math.cos(a)*.23,Math.sin(a)*.23,0),1.5f);
            }
        }
    }
    /** A slanted, ascending force helix is visually distinct from circles on the ground. */
    public static void spiral(ServerPlayer p,int turns,double height) {
        ServerLevel level=p.serverLevel();String color=MagicData.magic(p);
        for(int i=0;i<90;i++) {
            double t=i/89.0,a=t*2*Math.PI*turns,r=.35+.8*t;
            point(level,color,p.position().add(Math.cos(a)*r,.12+t*height,Math.sin(a)*r),1.05f);
        }
    }
    /** Bloom of upward-pointing lights and hearts for healing. */
    public static void healing(ServerPlayer p) {
        ServerLevel level=p.serverLevel();String color=MagicData.magic(p);
        for(int i=0;i<45;i++) {
            double a=i*2*Math.PI/45,r=.15+1.4*(i%7)/7.0;
            point(level,color,p.position().add(Math.cos(a)*r,.4+(i%9)*.19,Math.sin(a)*r),1f);
        }
        level.sendParticles(ParticleTypes.HEART,p.getX(),p.getY()+1.4,p.getZ(),8,.6,.5,.6,.025);
    }
    public static void shadow(ServerPlayer p) {
        ServerLevel level=p.serverLevel();
        level.sendParticles(ParticleTypes.SMOKE,p.getX(),p.getY()+1,p.getZ(),45,.7,.8,.7,.04);
        for(int i=0;i<35;i++) {
            double a=2*Math.PI*i/35;
            point(level,MagicData.magic(p),p.position().add(Math.cos(a)*.75,1.65+Math.sin(a*2)*.22,Math.sin(a)*.75),.7f);
        }
    }
    public static void chains(ServerLevel level,String color,Vec3 center) {
        for(int column=0;column<4;column++) {
            double angle=column*Math.PI/2;
            for(int j=0;j<22;j++) {
                double h=j*.09;
                double radius=.7+.12*Math.sin(h*7+column);
                point(level,color,center.add(Math.cos(angle+h*3)*radius,h,Math.sin(angle+h*3)*radius),1.1f);
            }
        }
    }
    public static void aegis(ServerPlayer caster) {
        ServerLevel level=caster.serverLevel();String color=MagicData.magic(caster);
        Vec3 center=caster.position().add(0,.14,0);
        sigil(level,color,center,3);
        for(int lat=1;lat<=6;lat++) {
            double angle=(Math.PI/2)*lat/7.0;
            double radius=3.5*Math.cos(angle),h=3.5*Math.sin(angle);
            ring(level,color,center.add(0,h,0),radius,30);
        }
    }
    /** Flame-shaped tongues in the selected color, not generic concentric dust rings. */
    public static void witchFlames(ServerPlayer caster) {
        ServerLevel level=caster.serverLevel();String color=MagicData.magic(caster);
        Vec3 center=caster.position();int phase=caster.tickCount;
        for(int i=0;i<32;i++) {
            double angle=i*2*Math.PI/32+phase*.014;
            double radius=3.02;
            double x=Math.cos(angle)*radius,z=Math.sin(angle)*radius;
            for(int j=0;j<5;j++) {
                double t=j/4.0;
                double sway=.2*Math.sin(phase*.22+i*2.7+t*5.5)*t;
                point(level,color,center.add(x+Math.cos(angle)*sway,.16+t*(.65+((i*7)%6)*.14),z+Math.sin(angle)*sway),.88f+(float)t*.55f);
            }
            if(i%6==0)level.sendParticles(ParticleTypes.FLAME,center.x+x,center.y+.2,center.z+z,1,.05,.12,.05,.01);
        }
    }
    public static void blinkBurst(ServerLevel level,String color,Vec3 pos) {
        for(int i=0;i<55;i++) {
            double a=i*Math.PI*2/55;
            double h=(i%11)*.19;
            point(level,color,pos.add(Math.cos(a)*(.4+h*.15),h,Math.sin(a)*(.4+h*.15)),1f);
        }
        level.sendParticles(ParticleTypes.PORTAL,pos.x,pos.y+1,pos.z,24,.4,.8,.4,.05);
    }
    public static void saltSurge(ServerPlayer caster,Vec3 pos) {
        ServerLevel level=caster.serverLevel();String color=MagicData.magic(caster);
        for(int i=0;i<50;i++) {
            double a=i*2*Math.PI/50,r=.1+i*.025;
            point(level,color,pos.add(Math.cos(a)*r,.09+.05*(i%3),Math.sin(a)*r),.8f);
        }
    }
}
