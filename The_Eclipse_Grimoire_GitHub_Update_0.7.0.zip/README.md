# The Eclipse Grimoire — Alpha 0.7.0 "Living Grimoire"

**Minecraft 1.20.1 • Forge 47.4.0 • Java 17 • same mod ID `eclipse_grimoire`**

**Status: uncompiled Alpha 0.7.0 source.** This updates the tested Alpha 0.6.0 foundation. Source checks and asset validation were run locally; full Forge compilation and Minecraft testing **still need to happen in GitHub Actions and a test world**. Keep your working 0.6.0 JAR safe.

## What's new

**A more book-like grimoire:** Six sections (Spells, Coven, Familiars, Wheel, Settings, Style) rendered across facing pages with a brief animated curling-page transition and vanilla page-turn sound. Spells now have four illustrated-by-layout chapters: Warding, Force/Storms, Travel, and Rituals. Each chapter shows mana costs, level gates and hover details. All previous cast buttons and shortcuts remain.

**Separate grimoire style:** The new Style section offers **Ancient Regal, Occult Gothic, Natural Witch, Celestial, and Forbidden Relic**. Each changes ornaments, edge treatment, binding and page motifs without changing your independent book dye or magic color. Choose in the Style page or use `/eclipse style regal|gothic|natural|celestial|relic`. Style persists in the player's existing magic save data and defaults to Regal for old characters.

**Living Coven page:** When the book opens it receives an online player list and an online coven member list from the server, plus saved coven name, size and pending invitation. The right page offers **Invite** buttons for available online players if you belong to a coven; use Next/Previous to browse the roster. The left side shows coven membership and allows create/join/leave. Reopen your book to refresh the snapshot. Only current online members' names are displayed (offline members count toward the total, but do not have names listed yet).

**Familiar register:** Bonding your owned tame pet adds it to a persistent up-to-32 familiar roster. The Familiars page displays recorded names and species, and if that mob is currently loaded in your dimension, its approximate distance and health. The familiar remains in the roster when distant or not loaded. Existing pets bonded in older versions must be bonded **one more time** to add them to this new registry; the old ward immunity remains intact.

**Alzur's Thunder:** Twin zigzagging magical arcs now **originate near the caster's hands** and connect to each affected target, with hand-charge sparks and a new impact sound. This replaces the previous visual-only lightning bolts dropped from the sky. Damage and friendly-fire rules remain unchanged. Minecraft player arm-bone animations are **not** modified; this is an effect-origin rework.

**Distinct visual/sound language:** Mending Light emits hearts and rising light motes; Surge of Power creates a rising spiral; Veil shrouds the player in smoke; Chains of Night creates tall binding columns on enemies; Final Aegis forms a multi-ring dome; Blink flashes at departure and arrival; Telekinetic Pulse generates outward moving radial force lines; Witchfire forms flame-shaped colored tongues and quiet fire crackle; salt infusion/sealing produces focused ground magic. Sounds are different **vanilla Minecraft** sound events, so no new external audio downloads are required.

**Witchfire stays non-destructive:** Colored flame-like particles are significantly taller/more flame-shaped, and small vanilla fire particles add texture. These are **not dyed real fire blocks or replacement fire textures**, and the spell does not burn terrain. Color applies to the magical particles, not mobs' vanilla on-fire overlay.

**Kept from 0.6.0:** Spell wheel/keybind and Wheel page customization, enchanted colored salt, levelling/mana, all other spells, lectern book opening, familiar ward exemptions, Arcane Tether, cauldron magic and server-authoritative covens.

## Build this in your existing GitHub repository

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.7.0.zip` **as a ZIP** to the root of `eclipsemidnight82/Eclipsed-Magic` on `main` (do not unpack it on GitHub).
2. Edit `.github/workflows/build.yml` and replace the entire workflow contents with `Eclipsed_Magic_Build_0_7.yml`; commit the edit.
3. Wait for **a green workflow run explicitly saying Alpha 0.7.0**. The ZIP upload commit alone can still run your old workflow; *that* green check is NOT enough.
4. Download the `eclipse-grimoire-forge-1.20.1-alpha-0.7.0` Actions artifact; extract the `.jar` and install it in a separate, backed-up CurseForge **Forge 1.20.1** profile. Only one Eclipse Grimoire JAR in `mods` at a time. For multiplayer, update server and clients together.
5. If Java compilation fails, share the first `error:` lines from the Actions step, not just the red checkmark. Do not replace your working 0.6.0 build until testing succeeds.

## Suggested tests

- Test an old 0.6.0 save: all level/mana/XP, coven memberships and salt wards survive. Change style and both colors independently, exit and reopen.
- Flip between the four spell chapters; click unlocked spells, confirm locked spells remain disabled and hovering reveals details. Ensure familiar pages and invites work with two players online.
- Bond a tamed pet, reopen grimoire, walk away, revisit after restarting the game and check the roster persists; ensure it has not been re-tamed or changed ownership.
- Cast Thunder while looking at a hostile mob, inspect lightning arcs from the two hand origins and verify no terrain ignites. Test Witchfire around skeleton arrows, Pulse near allied pets, and Blink in tight spaces.
- Confirm old wheel key, customized wheel order, salt, tether, and menus work. Check sounds from the Settings audio sliders.

## Known limitations

This is a graphical page-curl **transition**, not true mesh-based 3D paper physics. The book displays **currently online** coven members rather than resolving offline usernames. Familiars show current health only when the mob is loaded in the same dimension. Thunder originates from approximate hand positions, but the Minecraft player model does not animate arms to aim; that would require extra client animation code. No native gameplay testing is claimed for this source ZIP.

MIT licensed. No additional mod dependencies.
