# The Eclipse Grimoire — Alpha 0.10.1

Minecraft 1.20.1 / Forge 47.4.0 / Java 17.

## The Living Index — grimoire interface update

This alpha addresses GUI crowding and overlapping content reported after Alpha 0.10.0.
It is inspired by the clear chapter/article organization of in-game witchcraft guidebooks such as Bewitchment's Book of Shadows, but uses original styling and code.

**How it works:** Open the grimoire. It starts at a dedicated Table of Contents.
Choose Spells, Rituals, Hexes, Poppetry, Runes, Coven, Familiars, Spell Wheel,
Settings or Book Styles. Each chapter now has space for its own content and controls.
Use **CONTENTS** to jump home, and **PREV / NEXT** to turn that chapter's pages.

Spells are laid out in illustrated book-like cards with a description, mana cost,
level requirement and cast control. Rituals use their own page per recipe.
The Coven chapter separates membership management from online-player invites.
No spell IDs, command strings, saved-world data, or item registrations were changed.

### Build through GitHub

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.10.1.zip` to repository root.
2. Replace `.github/workflows/build.yml` with the supplied `Eclipsed_Magic_Build_0_10_1.yml`.
3. Commit. GitHub Actions compiles the versioned sources from the ZIP.
4. Download the successful 0.10.1 artifact, extract the JAR, and test it in a backup world.
5. Keep the tested 0.10.0 JAR as a fallback.

### Test checklist

- Book opens to Contents instead of a crowded top navigation grid.
- All ten chapters open and the Contents button returns home.
- Spell pages show distinct non-overlapping cast controls and spell descriptions.
- Ritual pages show the correct ingredient and cast actions.
- Coven creation, invitation, and Familiar selection controls are clickable.
- Wheel settings and order preferences survive closing and reopening.
- Page scaling and mouse clicks remain aligned at different GUI scales / window sizes.
- A full round of old spellcasting, wards and ritual functionality still works.

### Status

Source and resource structure checked; UI class compiled against API-shape stubs.
A full Forge Gradle compilation and Minecraft gameplay test have **not yet** been completed.
