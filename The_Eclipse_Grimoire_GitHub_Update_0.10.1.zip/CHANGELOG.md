# The Eclipse Grimoire — Changelog

## Alpha 0.10.1 — The Living Index (Interface Refresh)

### Redesigned: Grimoire user interface
- Replaced ten cramped top navigation tabs with a dedicated **Table of Contents**.
- Created separate, focused book spreads for Spells, Rituals, Hexes, Poppetry, Runes, Coven, Familiars, Wheel, Settings, and Styles.
- Added intuitive **Contents / Prev / Next / Close** navigation and chapter folio numbering.
- Reflowed all spell entries into legible, two-per-page cards with descriptions, level requirements, mana costs, and individual cast buttons.
- Gave each ritual its own recipe spread, displaying the altar setup, exact ingredient, effect, cost, and Perform button.
- Split the Hexes section into two spreads and the Poppetry guide into two spreads.
- Paged the rune selector so the runes, their meanings, and active selection are easier to see.
- Reorganized coven management into a membership overview and separate online-player invitation pages.
- Preserved the familiar roster, spell wheel controls, book naming, separate magic/book colors, and five independent book styles.
- Preserved scale-aware mouse coordinates and book auto-fitting for different Minecraft screen sizes.
- Kept page-turn transitions and a Minecraft page-turn sound.

### Preserved gameplay
- Existing spells, mana, XP, covens, familiars, chalk runes, salt wards, Ritual Magic, Hexcraft and Poppetry are unchanged.
- Saved character/world data formats and server command names are unchanged.

### Verification
- Java 17 compilation of the replaced UI class against minimal Minecraft/Forge API-shape stubs passed.
- Full Minecraft Forge 1.20.1 Gradle compilation and in-game GUI testing remain required.
