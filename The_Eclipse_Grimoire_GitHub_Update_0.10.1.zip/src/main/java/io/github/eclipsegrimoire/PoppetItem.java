package io.github.eclipsegrimoire;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Unbound poppets can only be linked using a nearby-collected taglock item. */
public final class PoppetItem extends Item {
    public PoppetItem(Properties properties){super(properties);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
        ItemStack stack=player.getItemInHand(hand);
        if(!(player instanceof ServerPlayer witch)) return InteractionResultHolder.success(stack);
        if(stack.hasTag() && stack.getTag().hasUUID("Target")) {
            CompoundTag previous=stack.getTag();
            if(witch.isShiftKeyDown() && previous.hasUUID("Binder") && witch.getUUID().equals(previous.getUUID("Binder"))) {
                String name=previous.getString("Name");
                previous.remove("Target");previous.remove("Binder");previous.remove("Name");previous.remove("Dimension");
                witch.sendSystemMessage(Component.literal("[Eclipse] Your poppet's bond to "+name+" was safely released."));
            } else {
                witch.sendSystemMessage(Component.literal("[Eclipse] This poppet is linked to "+previous.getString("Name")+". Use a ritual pin, or sneak-use to unbind it."));
            }
            return InteractionResultHolder.success(stack);
        }
        for(int i=0;i<witch.getInventory().getContainerSize();i++) {
            ItemStack link=witch.getInventory().getItem(i);
            if(!link.is(EclipseMod.TAGLOCK.get()) || !link.hasTag() || !link.getTag().hasUUID("Target")) continue;
            CompoundTag tag=stack.getOrCreateTag();
            tag.putUUID("Target",link.getTag().getUUID("Target"));
            tag.putString("Name",link.getTag().getString("Name"));
            tag.putString("Dimension",link.getTag().getString("Dimension"));
            tag.putUUID("Binder",witch.getUUID());
            if(!witch.isCreative()) link.shrink(1);
            witch.sendSystemMessage(Component.literal("[Eclipse] Poppet bound to "+tag.getString("Name")+". Only you can use the link."));
            return InteractionResultHolder.success(stack);
        }
        witch.sendSystemMessage(Component.literal("[Eclipse] Collect a taglock by right-clicking a living target, then use an unbound poppet."));
        return InteractionResultHolder.fail(stack);
    }
}
