package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.MagicData;
import io.github.eclipsegrimoire.RunePattern;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

/** An original illustrated chapter-and-article grimoire, inspired by the clarity of guidebooks.
 *  No ten-tab navigation bar: each page has a bounded layout and its own controls.
 *  The UI is purely client-side; existing server-side spell and coven commands are unchanged.
 */
public final class GrimoireScreen extends Screen {
    private enum Chapter { CONTENTS, SPELLS, RITUALS, HEXES, POPPETRY, RUNES,
        COVEN, FAMILIARS, WHEEL, SETTINGS, STYLE }
    private static final int WIDTH=458, HEIGHT=310;
    private static final int PALE=0xfff3ebdf, FADED=0xffc2b9c9, GOLD=0xffdec38e;
    private static final String[] COLORS={"purple","crimson","blue","emerald","gold","white","shadow","rose"};
    private static final String[] STYLES={"regal","gothic","natural","celestial","relic"};
    private static final String[] STYLE_NAMES={"ANCIENT REGAL","OCCULT GOTHIC","NATURAL WITCH",
        "CELESTIAL","FORBIDDEN RELIC"};
    private static final String[] STYLE_DESCRIPTIONS={"Gold ornament and arcane medallions",
        "Blackened edges and sharp marks","Herbal sprigs and woven vines",
        "Stars, moons and quiet constellations","Weathered binding and lost seals"};
    private static final Chapter[] CONTENTS={Chapter.SPELLS,Chapter.RITUALS,Chapter.HEXES,
        Chapter.POPPETRY,Chapter.RUNES,Chapter.COVEN,Chapter.FAMILIARS,Chapter.WHEEL,
        Chapter.SETTINGS,Chapter.STYLE};
    private static final String[] CONTENT_TITLES={"SPELLS","RITUALS","HEXES","POPPETRY","RUNES",
        "COVEN","FAMILIARS","SPELL WHEEL","SETTINGS","BOOK STYLES"};
    private static final String[] CONTENT_NOTES={"Wards, travel, force and utility","Cauldron rites and altar ingredients",
        "Lingering curses and their remedies","Taglocks, poppets, pins and charms","Eight chalk marks and Binding Rune",
        "Members, invitations and players","Your bonded companions","Order, hide and resize quick casts",
        "Name, magic color and book color","Independent leather and page designs"};

    private record SpellDef(String name,String id,int cost,String description) { }
    private static final SpellDef[][] SPELLS={
        {new SpellDef("Warding Shield","ward",8,"Protect yourself from damage."),
         new SpellDef("Mending Light","mend",12,"Heal yourself, allies and familiars."),
         new SpellDef("Salt Circle","circle",20,"Conjure a connected enchanted ring."),
         new SpellDef("Seal Salt","seal",12,"Enchant connected salt or ward a door."),
         new SpellDef("Absolute Seal","absolute",12,"Lock a prepared doorway to everyone."),
         new SpellDef("Witchfire","witchfire",30,"Burn and repel intruders; stop arrows.")},
        {new SpellDef("Surge of Power","power",10,"Gain strength and quickness."),
         new SpellDef("Chains of Night","bind",15,"Slow and weaken nearby opponents."),
         new SpellDef("Telekinetic Pulse","pulse",14,"Push outsiders safely away."),
         new SpellDef("Alzur's Thunder","thunder",30,"Unleash branching hand-cast lightning."),
         new SpellDef("The Final Aegis","aegis",40,"A powerful last-resort protection.")},
        {new SpellDef("Veil of Shadows","veil",15,"Hide yourself and move swiftly."),
         new SpellDef("Blink","blink",18,"Jump to safe ground along your gaze."),
         new SpellDef("Arcane Tether","tether",10,"Pull a creature with enchanted thread."),
         new SpellDef("Witchlight","witchlight",12,"Summon a light and see in darkness.")},
        {new SpellDef("Infuse Salt","infuse",8,"Turn plain salt into your ward color."),
         new SpellDef("Shatter Ward","shatter",22,"Break a salt or doorway enchantment."),
         new SpellDef("Dispel","dispel",18,"Interrupt certain temporary magic."),
         new SpellDef("Bind Rune","rune_bind",14,"Arm a one-use, one-minute chalk trap.")},
        {new SpellDef("Weakening Hex","hex_weaken",18,"Weaken an outsider for a short time."),
         new SpellDef("Silencing Hex","hex_silence",18,"Temporarily forbid enemy spellcasts."),
         new SpellDef("Binding Hex","hex_bind",18,"Root and weaken a nearby target."),
         new SpellDef("Tracking Hex","hex_mark",18,"Reveal a marked target with glow.")}
    };
    private static final String[] SPELL_CHAPTERS={"THE WARDING ARTS","FORCE & STORMS",
        "VEILS & PASSAGE","SALT & RUNECRAFT","THE HEX ARTS"};
    private static final String[] RITES={"healing","restoration","cleansing","protection","revealing"};
    private static final String[] REAGENTS={"Glistering Melon Slice","Amethyst Shard","Milk Bucket",
        "Iron Ingot","Glowstone Dust"};
    private static final String[] RITE_EFFECTS={"Heal the caster, coven and nearby bonded pets.",
        "Refill mana for the witch and nearby coven members.",
        "Remove temporary hexes from the caster and coven.",
        "Grant damage resistance to protected allies.",
        "Reveal nearby outsiders with a visible glow."};
    private static final String[] HEX_IDS={"hex_weaken","hex_silence","hex_bind","hex_mark"};
    private static final String[] HEX_NAMES={"WEAKENING HEX","SILENCING HEX","BINDING HEX","TRACKING HEX"};
    private static final String[] HEX_DESCRIPTIONS={"Sap the target's strength and movement.",
        "Prevent a witch from casting briefly.","Root a target so they cannot flee.",
        "Mark a target with a revealing glow."};

    private Chapter chapter=Chapter.CONTENTS;
    private int leaf=0, wheelIndex=0, familiarIndex=0;
    private final String bookName,coven,invitation;
    private final int level,xp,xpNext,mana,maxMana,covenSize;
    private final List<String> online=new ArrayList<>(),members=new ArrayList<>();
    private final ListTag familiars,poppets;
    private String magicColor,bookColor,bookStyle,runePattern;
    private EditBox nameInput,covenInput;
    private long turnStarted;
    private boolean turnForward=true;

    public GrimoireScreen(ItemStack book) {
        super(Component.literal("The Eclipse Grimoire"));
        CompoundTag tag=book.getTag();
        bookName=tag!=null&&tag.contains("eclipseName")?tag.getString("eclipseName"):MagicData.DEFAULT_BOOK;
        magicColor=tag!=null&&tag.contains("eclipseMagic")?tag.getString("eclipseMagic"):"purple";
        bookColor=tag!=null&&tag.contains("eclipseUI")?tag.getString("eclipseUI"):"shadow";
        bookStyle=tag!=null&&tag.contains("eclipseStyle")?tag.getString("eclipseStyle"):"regal";
        runePattern=tag!=null&&tag.contains("eclipseRune")?tag.getString("eclipseRune"):"moon";
        level=tag!=null&&tag.contains("eclipseLevel")?tag.getInt("eclipseLevel"):1;
        xp=tag!=null?tag.getInt("eclipseXp"):0;
        xpNext=tag!=null?tag.getInt("eclipseXpNext"):35;
        mana=tag!=null?tag.getInt("eclipseMana"):100;
        maxMana=tag!=null?tag.getInt("eclipseMaxMana"):100;
        coven=tag!=null?tag.getString("eclipseCoven"):"";
        invitation=tag!=null?tag.getString("eclipseInvite"):"";
        covenSize=tag!=null?tag.getInt("eclipseCovenCount"):0;
        if(tag!=null) {
            ListTag people=tag.getList("eclipseOnlinePlayers",8);
            for(int i=0;i<people.size();i++) online.add(people.getString(i));
            ListTag membersTag=tag.getList("eclipseCovenMembers",8);
            for(int i=0;i<membersTag.size();i++) members.add(membersTag.getString(i));
        }
        familiars=tag==null?new ListTag():tag.getList("eclipseFamiliars",10);
        poppets=tag==null?new ListTag():tag.getList("eclipsePoppets",10);
    }

    private float scale() {
        return Math.max(.12f,Math.min(.82f,Math.min((width-14f)/WIDTH,(height-14f)/HEIGHT)));
    }
    private int left() {return Math.round((width/scale()-WIDTH)/2f);}
    private int top() {return Math.round((height/scale()-HEIGHT)/2f);}
    private int tint(String name) {return 0xff000000|switch(name) {
        case "purple"->0xa46af5;case "crimson"->0xe34e69;case "blue"->0x54a6ef;
        case "emerald"->0x43bd94;case "gold"->0xe6b74e;case "white"->0xe7dfe9;
        case "rose"->0xed91cb;default->0x80728f;
    };}
    private int accent(){return tint(bookColor);}
    private int magic(){return tint(magicColor);}
    private int dye(float strength) {
        int c=accent();
        int r=(int)(((c>>16)&255)*strength),g=(int)(((c>>8)&255)*strength),b=(int)((c&255)*strength);
        return 0xff000000|(r<<16)|(g<<8)|b;
    }
    private int edge(){return "natural".equals(bookStyle)?0xffb3ca8f:
        "celestial".equals(bookStyle)?0xffbed9f4:GOLD;}
    private int spine(){return "gothic".equals(bookStyle)?0xff07060e:dye(.1f);}
    private String next(String value,String[] values) {
        for(int i=0;i<values.length;i++)if(values[i].equals(value))return values[(i+1)%values.length];
        return values[0];
    }
    private String prev(String value,String[] values) {
        for(int i=0;i<values.length;i++)if(values[i].equals(value))return values[(i+values.length-1)%values.length];
        return values[0];
    }
    private void sound() {Minecraft.getInstance().getSoundManager()
        .play(SimpleSoundInstance.forUI(SoundEvents.BOOK_PAGE_TURN,1f));}
    private void openChapter(Chapter target) {
        if(chapter==target&&leaf==0)return;
        chapter=target;leaf=0;turnForward=true;turnStarted=System.currentTimeMillis();
        sound();clearWidgets();init();
    }
    private void turn(int delta) {
        int dest=leaf+delta;
        if(dest<0||dest>=leafCount())return;
        leaf=dest;turnForward=delta>0;turnStarted=System.currentTimeMillis();
        sound();clearWidgets();init();
    }
    private int leafCount() {
        return switch(chapter) {
            case CONTENTS,SETTINGS,STYLE->1;
            case SPELLS->spellSpreadCount();
            case RITUALS->RITES.length;
            case HEXES,POPPETRY,RUNES,WHEEL->2;
            case COVEN->Math.max(2,1+(online.size()+3)/4);
            case FAMILIARS->Math.max(1,(familiars.size()+3)/4);
        };
    }
    private int spellSpreadCount() {
        int n=0;for(SpellDef[] chapterSpells:SPELLS)n+=(chapterSpells.length+3)/4;return n;
    }
    private int spellChapterIndex() {
        int page=leaf;
        for(int i=0;i<SPELLS.length;i++) {
            int count=(SPELLS[i].length+3)/4;
            if(page<count)return i;
            page-=count;
        }
        return SPELLS.length-1;
    }
    private int spellPart() {
        int page=leaf;
        for(SpellDef[] group:SPELLS) {
            int count=(group.length+3)/4;
            if(page<count)return page;
            page-=count;
        }
        return 0;
    }
    private void command(String text) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null&&mc.player.connection!=null)mc.player.connection.sendCommand(text);
    }
    private void closeBook(){Minecraft.getInstance().setScreen(null);}
    private Button action(int x,int y,int width,int height,String label,Button.OnPress press) {
        return addRenderableWidget(new PageButton(x,y,width,height,Component.literal(label),press,false));
    }
    private Button selected(int x,int y,int width,int height,String label,Button.OnPress press,boolean selected) {
        return addRenderableWidget(new PageButton(x,y,width,height,Component.literal(label),press,selected));
    }
    private void cast(String id) {command("eclipse cast "+id);closeBook();}

    @Override protected void init() {
        int x=left(),y=top();
        switch(chapter) {
            case CONTENTS->initContents(x,y);
            case SPELLS->initSpells(x,y);
            case RITUALS->initRituals(x,y);
            case HEXES->initHexes(x,y);
            case POPPETRY->{}
            case RUNES->initRunes(x,y);
            case COVEN->initCoven(x,y);
            case FAMILIARS->initFamiliars(x,y);
            case WHEEL->initWheel(x,y);
            case SETTINGS->initSettings(x,y);
            case STYLE->initStyle(x,y);
        }
        // Navigation is the only persistent control row; chapter buttons live on Contents.
        if(chapter!=Chapter.CONTENTS)action(x+17,y+281,62,19,"CONTENTS",b->openChapter(Chapter.CONTENTS));
        if(leaf>0)action(x+94,y+281,59,19,"< PREV",b->turn(-1));
        if(leaf+1<leafCount())action(x+307,y+281,60,19,"NEXT >",b->turn(1));
        action(x+383,y+281,58,19,"CLOSE",b->closeBook());
    }
    private void initContents(int x,int y) {
        for(int i=0;i<CONTENTS.length;i++) {
            final Chapter chapter=CONTENTS[i];
            int col=i/5,row=i%5;
            int xx=x+(col==0?26:247),yy=y+108+row*31;
            action(xx,yy,182,23,(i+1)+"  "+CONTENT_TITLES[i],b->openChapter(chapter));
        }
    }
    private void initSpells(int x,int y) {
        int group=spellChapterIndex(),start=spellPart()*4;
        SpellDef[] spells=SPELLS[group];
        for(int local=0;local<4;local++) {
            int index=start+local;
            if(index>=spells.length)continue;
            SpellDef s=spells[index];
            int col=local/2,row=local%2;
            int xx=x+(col==0?24:246), yy=y+110+row*78;
            boolean unlocked=level>=MagicData.requiredLevel(s.id);
            Button b=action(xx+102,yy+52,74,18,unlocked?"CAST  ["+s.cost+"]":"LV "+MagicData.requiredLevel(s.id),p->cast(s.id));
            b.active=unlocked;
        }
    }
    private void initRituals(int x,int y) {
        String rite=RITES[leaf];
        Button b=action(x+247,y+221,181,23,"PERFORM RITE  [24 MANA]",p->{command("eclipse ritual "+rite);closeBook();});
        b.active=level>=3;
    }
    private void initHexes(int x,int y) {
        for(int local=0;local<2;local++) {
            int idx=leaf*2+local;
            String spell=HEX_IDS[idx];
            int xx=x+(local==0?26:248);
            Button b=action(xx,y+200,180,23,"CAST HEX  [18 MANA]",p->cast(spell));
            b.active=level>=MagicData.requiredLevel(spell);
        }
    }
    private void initRunes(int x,int y) {
        RunePattern[] all=RunePattern.values();
        for(int local=0;local<4;local++) {
            int idx=leaf*4+local;
            if(idx>=all.length)break;
            String id=all[idx].getSerializedName();
            int xx=x+(local/2==0?25:248), yy=y+120+(local%2)*71;
            selected(xx,yy,181,25,id.toUpperCase(),p->{
                runePattern=id;command("eclipse rune select "+id);clearWidgets();init();
            },id.equals(runePattern));
        }
    }
    private void initCoven(int x,int y) {
        if(leaf==0) {
            if(coven.isEmpty()) {
                covenInput=new EditBox(font,x+247,y+138,180,19,Component.literal("Coven name"));
                covenInput.setMaxLength(24);
                covenInput.setHint(Component.literal("Your coven name"));
                addRenderableWidget(covenInput);
                action(x+247,y+164,180,22,"CREATE COVEN",b->{
                    String name=covenInput.getValue().trim();
                    if(name.matches("[a-zA-Z0-9_ -]{2,24}")){command("eclipse coven create "+name);closeBook();}
                });
                if(!invitation.isEmpty())action(x+247,y+204,180,22,"ACCEPT INVITATION",b->{command("eclipse coven join");closeBook();});
            } else {
                action(x+247,y+208,180,22,"LEAVE COVEN",b->{command("eclipse coven leave");closeBook();});
            }
            action(x+247,y+239,180,19,"ONLINE PLAYERS >",b->turn(1));
        } else {
            for(int i=0;i<4;i++) {
                int idx=(leaf-1)*4+i;
                if(idx>=online.size())break;
                String player=online.get(idx);
                int yy=y+115+i*34;
                if(!coven.isEmpty()&&!members.contains(player))
                    action(x+361,yy,68,20,"INVITE",b->{command("eclipse coven invite "+player);closeBook();});
            }
        }
    }
    private void initFamiliars(int x,int y) {
        for(int row=0;row<4;row++) {
            int idx=leaf*4+row;
            if(idx>=familiars.size())break;
            String name=familiars.getCompound(idx).getString("name");
            selected(x+25,y+112+row*35,180,22,name,b->{familiarIndex=idx;},familiarIndex==idx);
        }
        action(x+247,y+229,180,23,"BOND PET IN SIGHT",b->{command("eclipse familiar bond");closeBook();});
    }
    private void initWheel(int x,int y) {
        WheelPreferences prefs=WheelPreferences.get();
        List<String> order=prefs.order();
        if(order.isEmpty())return;
        wheelIndex=Math.floorMod(wheelIndex,order.size());
        if(leaf==0) {
            action(x+25,y+128,181,23,"SIZE: "+prefs.sizeLabel(),b->{prefs.cycleRadius();clearWidgets();init();});
            action(x+25,y+163,181,23,"OPACITY: "+prefs.opacity()+"%",b->{prefs.cycleOpacity();clearWidgets();init();});
            action(x+25,y+198,181,23,"TINT: "+prefs.color().toUpperCase(),b->{prefs.cycleColor();clearWidgets();init();});
            action(x+247,y+224,181,23,"RESTORE DEFAULT WHEEL",b->{prefs.reset();wheelIndex=0;clearWidgets();init();});
            action(x+247,y+185,181,23,"EDIT SPELL ORDER >",b->turn(1));
        } else {
            String key=order.get(wheelIndex);
            action(x+25,y+129,83,23,"< SPELL",b->{wheelIndex=Math.floorMod(wheelIndex-1,order.size());clearWidgets();init();});
            action(x+122,y+129,83,23,"SPELL >",b->{wheelIndex=(wheelIndex+1)%order.size();clearWidgets();init();});
            action(x+247,y+157,87,23,"EARLIER",b->{prefs.move(key,-1);wheelIndex=Math.floorMod(wheelIndex-1,order.size());clearWidgets();init();});
            action(x+342,y+157,87,23,"LATER",b->{prefs.move(key,1);wheelIndex=(wheelIndex+1)%order.size();clearWidgets();init();});
            action(x+247,y+202,182,23,prefs.shown(key)?"HIDE FROM WHEEL":"SHOW ON WHEEL",b->{prefs.toggle(key);clearWidgets();init();});
        }
    }
    private void initSettings(int x,int y) {
        nameInput=new EditBox(font,x+25,y+143,181,22,Component.literal("Book name"));
        nameInput.setMaxLength(32);nameInput.setValue(bookName);addRenderableWidget(nameInput);
        action(x+25,y+180,181,23,"SAVE BOOK NAME",b->{command("eclipse rename "+nameInput.getValue());closeBook();});
        action(x+247,y+134,181,23,"MAGIC: "+magicColor.toUpperCase(),b->{
            magicColor=next(magicColor,COLORS);command("eclipse color magic "+magicColor);clearWidgets();init();
        });
        action(x+247,y+171,181,23,"BOOK: "+bookColor.toUpperCase(),b->{
            bookColor=next(bookColor,COLORS);command("eclipse color book "+bookColor);clearWidgets();init();
        });
        action(x+247,y+216,181,23,"CHOOSE BOOK STYLE >",b->openChapter(Chapter.STYLE));
    }
    private void initStyle(int x,int y) {
        for(int i=0;i<STYLES.length;i++) {
            String target=STYLES[i];
            selected(x+248,y+105+i*31,181,23,STYLE_NAMES[i],b->{
                bookStyle=target;command("eclipse style "+target);turnStarted=System.currentTimeMillis();
                sound();clearWidgets();init();
            },target.equals(bookStyle));
        }
        action(x+25,y+208,82,22,"< STYLE",b->{bookStyle=prev(bookStyle,STYLES);changeStyle();});
        action(x+123,y+208,83,22,"STYLE >",b->{bookStyle=next(bookStyle,STYLES);changeStyle();});
    }
    private void changeStyle() {
        command("eclipse style "+bookStyle);sound();turnStarted=System.currentTimeMillis();clearWidgets();init();
    }

    private void line(GuiGraphics g,String text,int x,int y,int color){g.drawString(font,text,x,y,color);}
    private void clip(GuiGraphics g,String text,int x,int y,int w,int color){
        line(g,font.plainSubstrByWidth(text,Math.max(0,w)),x,y,color);
    }
    private void wrap(GuiGraphics g,String text,int x,int y,int w,int color,int maxLines) {
        List<FormattedCharSequence> lines=font.split(Component.literal(text),w);
        for(int i=0;i<Math.min(maxLines,lines.size());i++)g.drawString(font,lines.get(i),x,y+i*11,color);
    }
    private void heading(GuiGraphics g,String text,int x,int y,int w) {
        clip(g,text,x,y,w,edge());g.fill(x,y+13,x+w,y+14,dye(.82f));
    }
    private void box(GuiGraphics g,int x,int y,int w,int h) {
        g.fill(x,y,x+w,y+h,dye(.2f));
        g.fill(x,y,x+w,y+1,dye(.81f));
        g.fill(x,y+h-1,x+w,y+h,dye(.81f));
    }
    private void frame(GuiGraphics g,int x,int y) {
        g.fill(x-7,y-6,x+WIDTH+7,y+HEIGHT+7,0xbc000000);
        g.fill(x-3,y-3,x+WIDTH+3,y+HEIGHT+3,edge());
        g.fill(x,y,x+WIDTH,y+HEIGHT,dye(.09f));
        g.fillGradient(x+5,y+5,x+WIDTH-5,y+HEIGHT-5,dye(.48f),dye(.22f));
        g.fill(x+11,y+75,x+WIDTH-11,y+273,spine());
        g.fillGradient(x+15,y+79,x+WIDTH/2-3,y+271,dye(.46f),dye(.34f));
        g.fillGradient(x+WIDTH/2+3,y+79,x+WIDTH-15,y+271,dye(.35f),dye(.45f));
        g.fill(x+WIDTH/2-3,y+79,x+WIDTH/2+3,y+272,dye(.08f));
        g.fill(x+WIDTH/2-1,y+80,x+WIDTH/2+1,y+270,edge());
        g.fill(x+14,y+39,x+WIDTH-14,y+40,edge());
        g.fill(x+14,y+271,x+WIDTH-14,y+273,edge());
        ornaments(g,x,y);
        clip(g,bookName,x+22,y+10,WIDTH-46,PALE);
        clip(g,"THE ECLIPSE GRIMOIRE   /   "+chapterTitle(),x+22,y+25,WIDTH-44,FADED);
        line(g,"LEVEL "+level+"     XP "+xp+(xpNext==0?"  MAX":" / "+xpNext),x+23,y+48,PALE);
        line(g,"MANA "+mana+" / "+maxMana,x+WIDTH-134,y+48,PALE);
        int barWidth=WIDTH/2-30;
        g.fill(x+21,y+62,x+21+barWidth,y+65,dye(.15f));
        g.fill(x+21,y+62,x+21+(int)(barWidth*Math.min(1.0,xpNext==0?1.0:(double)xp/Math.max(1,xpNext))),y+65,edge());
        g.fill(x+WIDTH/2+13,y+62,x+WIDTH/2+13+barWidth,y+65,dye(.15f));
        g.fill(x+WIDTH/2+13,y+62,x+WIDTH/2+13+(int)(barWidth*Math.min(1.0,(double)mana/Math.max(1,maxMana))),y+65,magic());
        if(chapter!=Chapter.CONTENTS)g.drawCenteredString(font,"FOLIO "+(leaf+1)+" / "+leafCount(),x+WIDTH/2,y+286,PALE);
    }
    private String chapterTitle() {
        if(chapter==Chapter.CONTENTS)return "CONTENTS";
        if(chapter==Chapter.SPELLS)return "SPELLS";
        return chapter.name().replace('_',' ');
    }
    private void ornaments(GuiGraphics g,int x,int y) {
        int c=edge();
        switch(bookStyle) {
            case "natural" -> {
                for(int i=0;i<8;i++){int yy=y+89+i*20;
                    g.fill(x+16,yy,x+21+(i%3)*2,yy+2,c);
                    g.fill(x+WIDTH-22-(i%3)*2,yy,x+WIDTH-16,yy+2,c);}
            }
            case "celestial" -> {
                for(int i=0;i<9;i++){int xx=x+30+i*45, yy=y+91+(i%3)*52;
                    g.fill(xx,yy,xx+2,yy+2,c);g.fill(xx-2,yy+1,xx+4,yy+2,dye(.8f));}
            }
            case "gothic" -> {
                for(int i=0;i<11;i++){int xx=x+16+i*40;
                    g.fill(xx,y+7,xx+3,y+14,c);g.fill(xx,y+HEIGHT-16,xx+3,y+HEIGHT-9,c);}
            }
            case "relic" -> {
                for(int i=0;i<10;i++){int yy=y+89+i*18;
                    g.fill(x+16+(i%3)*3,yy,x+21+(i%3)*3,yy+2,dye(.8f));}
            }
            default -> {
                for(int i=0;i<4;i++){int xx=i%2==0?x+16:x+WIDTH-22;
                    int yy=i/2==0?y+86:y+260;
                    g.fill(xx,yy,xx+6,yy+2,c);g.fill(xx+2,yy-2,xx+4,yy+5,c);}
            }
        }
        int sx=x+WIDTH/2,sy=y+18;
        g.fill(sx-9,sy,sx+10,sy+1,c);g.fill(sx,sy-8,sx+1,sy+9,c);
        g.fill(sx-3,sy-3,sx+4,sy+4,dye(.17f));
        g.fill(sx-1,sy-1,sx+2,sy+2,magic());
    }
    private void content(GuiGraphics g,int x,int y) {
        switch(chapter) {
            case CONTENTS->drawContents(g,x,y);
            case SPELLS->drawSpells(g,x,y);
            case RITUALS->drawRituals(g,x,y);
            case HEXES->drawHexes(g,x,y);
            case POPPETRY->drawPoppetry(g,x,y);
            case RUNES->drawRunes(g,x,y);
            case COVEN->drawCoven(g,x,y);
            case FAMILIARS->drawFamiliars(g,x,y);
            case WHEEL->drawWheel(g,x,y);
            case SETTINGS->drawSettings(g,x,y);
            case STYLE->drawStyle(g,x,y);
        }
    }
    private void drawContents(GuiGraphics g,int x,int y) {
        heading(g,"TABLE OF CONTENTS",x+24,y+87,185);
        heading(g,"CHAPTERS & COMPANIONS",x+245,y+87,186);

        
    }
    private void drawSpells(GuiGraphics g,int x,int y) {
        int group=spellChapterIndex(),start=spellPart()*4;
        SpellDef[] spells=SPELLS[group];
        heading(g,SPELL_CHAPTERS[group],x+24,y+87,182);
        heading(g,"INCANTATIONS",x+246,y+87,182);
        for(int local=0;local<4;local++) {
            int idx=start+local;if(idx>=spells.length)continue;
            int col=local/2,row=local%2;
            int xx=x+(col==0?24:246), yy=y+110+row*78;
            SpellDef s=spells[idx];
            box(g,xx,yy,181,72);
            clip(g,s.name,xx+5,yy+5,171,PALE);
            int need=MagicData.requiredLevel(s.id);
            line(g,"LV "+need+"     "+s.cost+" MANA",xx+5,yy+18,need<=level?edge():FADED);
            wrap(g,s.description,xx+5,yy+31,169,FADED,2);
        }
        if(start+4>=spells.length&&spells.length%4!=0)
            wrap(g,"Next leaf: more magic, or return to Contents.",x+246,y+259,178,FADED,1);
    }
    private void drawRituals(GuiGraphics g,int x,int y) {
        String name=RITES[leaf].toUpperCase();
        heading(g,"RITE OF "+name,x+24,y+87,183);
        heading(g,"RITUAL EFFECT",x+246,y+87,182);
        line(g,"ALTAR REQUIREMENTS",x+26,y+111,PALE);
        line(g,"1 chalk rune",x+26,y+131,FADED);
        line(g,"3 or more enchanted candles",x+26,y+146,FADED);
        line(g,"1 cauldron within 3 blocks",x+26,y+161,FADED);
        line(g,"INGREDIENT",x+26,y+186,PALE);
        wrap(g,REAGENTS[leaf],x+26,y+201,177,edge(),2);
        wrap(g,RITE_EFFECTS[leaf],x+248,y+122,177,PALE,3);
        wrap(g,"Aim at the chalk focus. Hold the ingredient in your main hand.",x+248,y+170,175,FADED,3);
        line(g,"Unlock: Level 3",x+248,y+207,FADED);
        line(g,"Mana cost: 24",x+26,y+243,FADED);
    }
    private void drawHexes(GuiGraphics g,int x,int y) {
        for(int local=0;local<2;local++) {
            int idx=leaf*2+local;
            int xx=x+(local==0?25:247);
            heading(g,HEX_NAMES[idx],xx,y+89,180);
            wrap(g,HEX_DESCRIPTIONS[idx],xx,y+124,178,PALE,3);
            line(g,"MANA 18",xx,y+165,FADED);
            line(g,"LEVEL "+MagicData.requiredLevel(HEX_IDS[idx]),xx,y+180,FADED);
            wrap(g,"Cleanse with Dispel, Curse Bottle, or a Cleansing Rite.",xx,y+237,180,FADED,2);
        }
    }
    private void drawPoppetry(GuiGraphics g,int x,int y) {
        if(leaf==0) {
            heading(g,"SYMPATHETIC POPPET",x+24,y+89,181);
            heading(g,"THE FOUR RITUAL PINS",x+246,y+89,182);
            line(g,"1. Touch target with Taglock.",x+25,y+124,PALE);
            wrap(g,"2. Use a poppet to bind your captured link.",x+25,y+145,178,FADED,3);
            wrap(g,"3. Use a pin while the linked target is nearby and loaded.",x+25,y+194,178,FADED,4);
            line(g,"BLACK   -  Weakening",x+246,y+124,PALE);
            line(g,"VIOLET  -  Silencing",x+246,y+150,PALE);
            line(g,"BLUE    -  Binding",x+246,y+176,PALE);
            line(g,"SILVER  -  Tracking",x+246,y+202,PALE);
            line(g,"Targets must be within 48 blocks.",x+246,y+242,FADED);
        } else {
            heading(g,"CURSES & REMEDIES",x+24,y+89,182);
            heading(g,"BOUND POPPET",x+246,y+89,182);
            wrap(g,"Curse Bottle clears current hexes. Gris-Gris Charm Bag absorbs an incoming hex.",
                x+25,y+124,178,PALE,6);
            line(g,"Sneak-use a poppet to unbind it.",x+25,y+219,FADED);
            if(poppets.isEmpty())wrap(g,"No bound poppet in your inventory.",x+247,y+127,176,FADED,3);
            else {
                CompoundTag doll=poppets.getCompound(0);
                clip(g,doll.getString("name"),x+247,y+130,175,PALE);
                wrap(g,doll.getBoolean("near")?"Target loaded nearby.":"Target not loaded nearby.",
                    x+247,y+151,177,FADED,2);
            }
        }
    }
    private void drawRunes(GuiGraphics g,int x,int y) {
        heading(g,"CHALK SIGILS",x+24,y+89,181);
        heading(g,"CHOOSE A MARK",x+246,y+89,182);
        RunePattern[] all=RunePattern.values();
        for(int local=0;local<4;local++) {
            int idx=leaf*4+local;
            if(idx>=all.length)break;
            String id=all[idx].getSerializedName();
            int xx=x+(local/2==0?25:248), yy=y+120+(local%2)*71;
            String note=switch(id) {
                case "binding"->"Can be armed as a one-use trap.";
                case "ward"->"A protective chalk sigil.";
                case "moon","star","sun"->"Decorative celestial mark.";
                default->"Permanent decorative rune.";
            };
            wrap(g,note,xx+2,yy+31,174,FADED,2);
        }
        clip(g,"Selected: "+runePattern.toUpperCase(),x+26,y+252,400,PALE);
    }
    private void drawCoven(GuiGraphics g,int x,int y) {
        if(leaf==0) {
            heading(g,"COVEN REGISTER",x+24,y+89,181);
            heading(g,"MEMBERSHIP",x+246,y+89,182);
            clip(g,coven.isEmpty()?"No coven joined":coven,x+26,y+115,178,PALE);
            line(g,"Members: "+covenSize,x+26,y+137,FADED);
            for(int i=0;i<Math.min(6,members.size());i++)
                clip(g,"* "+members.get(i),x+26,y+158+i*14,177,PALE);
            if(members.size()>6)line(g,"More members are registered.",x+26,y+253,FADED);
            wrap(g,coven.isEmpty()?"Create a coven or accept an invitation. Members share ward exemptions.":
                "Invite nearby players from the next leaf. Your spells protect the coven.",
                x+247,y+113,181,FADED,2);
            if(!invitation.isEmpty())clip(g,"Invitation: "+invitation,x+247,y+194,180,edge());
        } else {
            heading(g,"YOUR COVEN",x+24,y+89,180);
            heading(g,"ONLINE PLAYERS",x+247,y+89,181);
            clip(g,coven.isEmpty()?"Join a coven to invite":coven,x+26,y+123,175,PALE);
            wrap(g,"Invitation list refreshes when you reopen the book.",x+25,y+153,176,FADED,4);
            for(int row=0;row<4;row++) {
                int idx=(leaf-1)*4+row;
                if(idx>=online.size())break;
                clip(g,online.get(idx),x+248,y+119+row*34,106,PALE);
                if(members.contains(online.get(idx)))line(g,"MEMBER",x+363,y+121+row*34,edge());
            }
            if(online.isEmpty())wrap(g,"Nobody else is online.",x+248,y+138,174,FADED,2);
        }
    }
    private void drawFamiliars(GuiGraphics g,int x,int y) {
        heading(g,"BONDED COMPANIONS",x+24,y+89,181);
        heading(g,"COMPANION DETAILS",x+246,y+89,182);
        if(familiars.isEmpty()) {
            wrap(g,"No registered familiars yet.",x+27,y+128,176,FADED,3);
            wrap(g,"Look at a tame animal you own and bond it using the button below.",x+247,y+123,175,FADED,5);
        } else {
            int selectedIndex=Math.max(0,Math.min(familiarIndex,familiars.size()-1));
            CompoundTag pet=familiars.getCompound(selectedIndex);
            clip(g,pet.getString("name"),x+248,y+120,174,PALE);
            clip(g,pet.getString("type"),x+248,y+140,174,FADED);
            wrap(g,pet.getBoolean("near")?"Nearby: "+pet.getInt("distance")+" blocks":"Not currently loaded nearby",
                x+248,y+166,178,FADED,3);
            if(pet.getBoolean("near"))line(g,"Health: "+pet.getInt("health"),x+248,y+202,PALE);
        }
        clip(g,"Registered: "+familiars.size(),x+26,y+261,177,FADED);
    }
    private void drawWheel(GuiGraphics g,int x,int y) {
        WheelPreferences prefs=WheelPreferences.get();
        if(leaf==0) {
            heading(g,"QUICK CAST SETTINGS",x+24,y+89,181);
            heading(g,"HOW TO CAST",x+246,y+89,182);
            wrap(g,"Adjust the wheel without altering your unlocked spells.",x+25,y+110,180,FADED,2);
            line(g,"Hold your wheel key",x+247,y+127,PALE);
            line(g,"Scroll to choose a spell",x+247,y+145,FADED);
            line(g,"Release the key to cast",x+247,y+163,PALE);
            wrap(g,"All controls stay rebindable in Minecraft's Key Binds menu.",x+247,y+255,179,FADED,1);
        } else {
            List<String> order=prefs.order();
            heading(g,"SPELL ORDER",x+24,y+89,181);
            heading(g,"SELECTED SPELL",x+246,y+89,182);
            if(!order.isEmpty()) {
                String key=order.get(Math.floorMod(wheelIndex,order.size()));
                clip(g,SpellWheel.label(key),x+247,y+121,180,PALE);
                line(g,"Entry "+(wheelIndex+1)+" / "+order.size(),x+247,y+141,FADED);
                line(g,prefs.shown(key)?"Shown on wheel":"Hidden from wheel",x+247,y+239,PALE);
                line(g,"Required level: "+MagicData.requiredLevel(key),x+25,y+191,FADED);
            }
        }
    }
    private void drawSettings(GuiGraphics g,int x,int y) {
        heading(g,"YOUR BOOK'S NAME",x+24,y+89,181);
        heading(g,"YOUR COLORS",x+246,y+89,182);
        wrap(g,"Name this grimoire and choose your own appearance.",x+25,y+111,180,FADED,2);
        wrap(g,"Magic color controls spells and wards. Book color changes the pages and cover.",
            x+247,y+109,177,FADED,2);
        g.fill(x+248,y+204,x+334,y+209,magic());
        g.fill(x+340,y+204,x+427,y+209,accent());
        line(g,"Change style separately below.",x+25,y+233,FADED);
    }
    private void drawStyle(GuiGraphics g,int x,int y) {
        heading(g,"BINDING & PAGE STYLE",x+24,y+89,181);
        heading(g,"AVAILABLE DESIGNS",x+247,y+89,181);
        int chosen=0;for(int i=0;i<STYLES.length;i++)if(STYLES[i].equals(bookStyle))chosen=i;
        clip(g,STYLE_NAMES[chosen],x+25,y+119,179,PALE);
        wrap(g,STYLE_DESCRIPTIONS[chosen],x+25,y+145,176,FADED,3);
        wrap(g,"Styles and colors are independent. Your magic remains your chosen color.",
            x+25,y+242,182,FADED,2);
    }
    private void pageTurn(GuiGraphics g,int x,int y) {
        long elapsed=System.currentTimeMillis()-turnStarted;
        if(turnStarted==0||elapsed>280)return;
        double wave=Math.sin(Math.min(1.0,elapsed/280.0)*Math.PI);
        int strip=Math.max(1,(int)(195*wave));
        if(turnForward) {
            g.fill(x+WIDTH-strip-16,y+81,x+WIDTH-16,y+270,0x50180e25);
            g.fill(x+WIDTH-strip-16,y+81,x+WIDTH-strip-14,y+270,edge());
        } else {
            g.fill(x+16,y+81,x+16+strip,y+270,0x50180e25);
            g.fill(x+14+strip,y+81,x+16+strip,y+270,edge());
        }
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g);
        float s=scale();
        int virtualX=Math.round(mouseX/s),virtualY=Math.round(mouseY/s);
        int x=left(),y=top();
        g.pose().pushPose();g.pose().scale(s,s,1f);
        frame(g,x,y);
        content(g,x,y);
        super.render(g,virtualX,virtualY,partial);
        pageTurn(g,x,y);
        g.pose().popPose();
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        float s=scale();return super.mouseClicked(mouseX/s,mouseY/s,button);
    }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button) {
        float s=scale();return super.mouseReleased(mouseX/s,mouseY/s,button);
    }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double dx,double dy) {
        float s=scale();return super.mouseDragged(mouseX/s,mouseY/s,button,dx/s,dy/s);
    }
    @Override public boolean mouseScrolled(double mouseX,double mouseY,double delta) {
        float s=scale();return super.mouseScrolled(mouseX/s,mouseY/s,delta);
    }
    @Override public boolean isPauseScreen(){return false;}
    private final class PageButton extends Button {
        private final boolean chosen;
        private PageButton(int x,int y,int width,int height,Component label,OnPress press,boolean selected) {
            super(x,y,width,height,label,press,Button.DEFAULT_NARRATION);chosen=selected;
        }
        @Override protected void renderWidget(GuiGraphics g,int mouseX,int mouseY,float partial) {
            int x=getX(),y=getY(),w=width,h=height;
            boolean hover=isHoveredOrFocused();
            int stroke=chosen||hover?edge():dye(.8f);
            int inner=!active?dye(.15f):chosen?dye(.58f):hover?dye(.47f):dye(.31f);
            g.fill(x,y,x+w,y+h,stroke);
            g.fill(x+1,y+1,x+w-1,y+h-1,inner);
            if(chosen)g.fill(x+3,y+h-3,x+w-3,y+h-1,magic());
            String text=font.plainSubstrByWidth(getMessage().getString(),w-8);
            g.drawCenteredString(font,text,x+w/2,y+(h-8)/2,active?PALE:0xff938ba0);
        }
    }
}
