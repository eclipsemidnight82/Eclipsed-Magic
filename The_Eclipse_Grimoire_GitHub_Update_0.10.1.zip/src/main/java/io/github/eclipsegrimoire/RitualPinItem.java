package io.github.eclipsegrimoire;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Consumable pins affect only currently loaded targets, with normal mana and PvP restrictions. */
public final class RitualPinItem extends Item {
    private final String hex;
    public RitualPinItem(String hex,Properties properties){super(properties);this.hex=hex;}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
        ItemStack pin=player.getItemInHand(hand);
        if(!(player instanceof ServerPlayer witch)) return InteractionResultHolder.success(pin);
        for(int i=0;i<witch.getInventory().getContainerSize();i++) {
            ItemStack doll=witch.getInventory().getItem(i);
            if(!doll.is(EclipseMod.POPPET.get()) || !doll.hasTag()) continue;
            CompoundTag tag=doll.getTag();
            if(!tag.hasUUID("Target") || !tag.hasUUID("Binder") || !witch.getUUID().equals(tag.getUUID("Binder"))) continue;
            if(!witch.serverLevel().dimension().location().toString().equals(tag.getString("Dimension"))) continue;
            Entity entity=witch.serverLevel().getEntity(tag.getUUID("Target"));
            if(!(entity instanceof LivingEntity target) || !target.isAlive() || target.distanceToSqr(witch)>48*48) continue;
            if(HexMagic.apply(witch,target,hex,8,true)==1) {
                if(!witch.isCreative()) pin.shrink(1);
                return InteractionResultHolder.success(pin);
            }
            return InteractionResultHolder.fail(pin);
        }
        witch.sendSystemMessage(Component.literal("[Eclipse] You need your own bound poppet, with its target loaded in this dimension within 48 blocks."));
        return InteractionResultHolder.fail(pin);
    }
}
