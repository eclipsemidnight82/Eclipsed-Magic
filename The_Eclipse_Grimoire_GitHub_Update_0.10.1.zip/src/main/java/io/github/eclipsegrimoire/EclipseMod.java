package io.github.eclipsegrimoire;

import java.util.Map;
import java.util.LinkedHashMap;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(EclipseMod.MOD_ID)
public final class EclipseMod {
    public static final String MOD_ID = "eclipse_grimoire";
    public static final TagKey<EntityType<?>> EXTRA_UNDEAD = TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation(MOD_ID, "undead"));
    private static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    private static final DeferredRegister<CreativeModeTab> TABS=DeferredRegister.create(Registries.CREATIVE_MODE_TAB,MOD_ID);
    public static final Map<String,RegistryObject<Block>> CANDLE_BLOCKS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Item>> CANDLE_ITEMS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Block>> BRAZIER_BLOCKS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Item>> BRAZIER_ITEMS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Block>> RUNE_BLOCKS=new LinkedHashMap<>();
    public static final RegistryObject<Block> WARDSTONE_BLOCK=BLOCKS.register("wardstone",
        ()->new MagicDecorBlock(MagicDecorBlock.Kind.WARDSTONE,"purple",
            BlockBehaviour.Properties.of().strength(2.8f).lightLevel(s->10).noOcclusion()));
    public static final RegistryObject<Item> WARDSTONE_ITEM=ITEMS.register("wardstone",
        ()->new BlockItem(WARDSTONE_BLOCK.get(),new Item.Properties()));
    public static final RegistryObject<Block> WITCH_BELL_BLOCK=BLOCKS.register("witch_bell",
        ()->new MagicDecorBlock(MagicDecorBlock.Kind.BELL,"gold",
            BlockBehaviour.Properties.of().strength(2f).noOcclusion()));
    public static final RegistryObject<Item> WITCH_BELL_ITEM=ITEMS.register("witch_bell",
        ()->new BlockItem(WITCH_BELL_BLOCK.get(),new Item.Properties()));
    public static final RegistryObject<Item> TAGLOCK=ITEMS.register("taglock",()->new TaglockItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> POPPET=ITEMS.register("poppet",()->new PoppetItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> PIN_BLACK=ITEMS.register("ritual_pin_black",()->new RitualPinItem("hex_weaken",new Item.Properties()));
    public static final RegistryObject<Item> PIN_VIOLET=ITEMS.register("ritual_pin_violet",()->new RitualPinItem("hex_silence",new Item.Properties()));
    public static final RegistryObject<Item> PIN_BLUE=ITEMS.register("ritual_pin_blue",()->new RitualPinItem("hex_bind",new Item.Properties()));
    public static final RegistryObject<Item> PIN_SILVER=ITEMS.register("ritual_pin_silver",()->new RitualPinItem("hex_mark",new Item.Properties()));
    public static final RegistryObject<Item> CURSE_BOTTLE=ITEMS.register("curse_bottle",()->new CurseBottleItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> GRIS_GRIS=ITEMS.register("gris_gris_charm",()->new GrisGrisItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> WITCH_CHALK=ITEMS.register("witch_chalk",
        ()->new WitchChalkItem(new Item.Properties().durability(128)));
    public static final RegistryObject<Item> MANA_DRAUGHT=ITEMS.register("mana_draught",
        ()->new ManaDraughtItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> FAMILIAR_CHARM=ITEMS.register("familiar_charm",
        ()->new FamiliarCharmItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Block> SALT_LINE = BLOCKS.register("salt_line", () -> new SaltLineBlock(BlockBehaviour.Properties.copy(Blocks.REDSTONE_WIRE).noOcclusion()));
    public static final RegistryObject<Item> SALT = ITEMS.register("salt", () -> new BlockItem(SALT_LINE.get(), new Item.Properties()));
    /** Eight actual colored blocks keep multiplayer appearance and placed wards server-authoritative. */
    public static final Map<String,RegistryObject<Block>> COLORED_SALT_BLOCKS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Item>> COLORED_SALT_ITEMS=new LinkedHashMap<>();
    static {
        for(String color:MagicData.COLORS) {
            RegistryObject<Block> block=BLOCKS.register("infused_salt_"+color+"_line",
                ()->new SaltLineBlock(BlockBehaviour.Properties.copy(Blocks.REDSTONE_WIRE).noOcclusion()));
            COLORED_SALT_BLOCKS.put(color,block);
            COLORED_SALT_ITEMS.put(color,ITEMS.register("infused_salt_"+color,
                ()->new BlockItem(block.get(),new Item.Properties())));
            RegistryObject<Block> candle=BLOCKS.register("witch_candle_"+color,
                ()->new MagicDecorBlock(MagicDecorBlock.Kind.CANDLE,color,
                    BlockBehaviour.Properties.of().strength(.6f).lightLevel(s->12).noOcclusion()));
            CANDLE_BLOCKS.put(color,candle);
            CANDLE_ITEMS.put(color,ITEMS.register("witch_candle_"+color,
                ()->new BlockItem(candle.get(),new Item.Properties())));
            RegistryObject<Block> brazier=BLOCKS.register("witch_brazier_"+color,
                ()->new MagicDecorBlock(MagicDecorBlock.Kind.BRAZIER,color,
                    BlockBehaviour.Properties.of().strength(2.5f).lightLevel(s->15).noOcclusion()));
            BRAZIER_BLOCKS.put(color,brazier);
            BRAZIER_ITEMS.put(color,ITEMS.register("witch_brazier_"+color,
                ()->new BlockItem(brazier.get(),new Item.Properties())));
            RUNE_BLOCKS.put(color,BLOCKS.register("chalk_rune_"+color,
                ()->new RuneBlock(color,
                    BlockBehaviour.Properties.of().noCollission().noOcclusion().instabreak().lightLevel(s->2))));
        }
    }
    public static boolean isSalt(net.minecraft.world.level.block.state.BlockState state) {
        return state.getBlock() instanceof SaltLineBlock;
    }
    public static boolean isColoredSalt(net.minecraft.world.level.block.state.BlockState state) {
        for(RegistryObject<Block> block:COLORED_SALT_BLOCKS.values()) if(state.is(block.get())) return true;
        return false;
    }
    public static boolean isSaltItem(net.minecraft.world.item.ItemStack held) {
        if(held.is(SALT.get())) return true;
        for(RegistryObject<Item> item:COLORED_SALT_ITEMS.values()) if(held.is(item.get())) return true;
        return false;
    }
    public static String saltItemColor(net.minecraft.world.item.ItemStack held) {
        for(Map.Entry<String,RegistryObject<Item>> item:COLORED_SALT_ITEMS.entrySet())
            if(held.is(item.getValue().get())) return item.getKey();
        return "white";
    }
    public static RegistryObject<Item> infusedSaltItem(String color) {
        return COLORED_SALT_ITEMS.getOrDefault(color,COLORED_SALT_ITEMS.get("purple"));
    }
    public static final RegistryObject<Item> GRIMOIRE = ITEMS.register("grimoire", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<CreativeModeTab> WITCHCRAFT_TAB=TABS.register("witchcraft",()->
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.eclipse_grimoire"))
            .icon(()->new ItemStack(GRIMOIRE.get()))
            .displayItems((parameters,output)->{
                output.accept(GRIMOIRE.get());
                output.accept(SALT.get());
                for(RegistryObject<Item> item:COLORED_SALT_ITEMS.values()) output.accept(item.get());
                output.accept(WITCH_CHALK.get());
                output.accept(TAGLOCK.get());
                output.accept(POPPET.get());
                output.accept(PIN_BLACK.get());
                output.accept(PIN_VIOLET.get());
                output.accept(PIN_BLUE.get());
                output.accept(PIN_SILVER.get());
                output.accept(CURSE_BOTTLE.get());
                output.accept(GRIS_GRIS.get());
                for(RegistryObject<Item> item:CANDLE_ITEMS.values()) output.accept(item.get());
                for(RegistryObject<Item> item:BRAZIER_ITEMS.values()) output.accept(item.get());
                output.accept(WARDSTONE_ITEM.get());
                output.accept(WITCH_BELL_ITEM.get());
                output.accept(FAMILIAR_CHARM.get());
                output.accept(MANA_DRAUGHT.get());
            }).build());

    public EclipseMod() {
        EclipseNetwork.register();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
