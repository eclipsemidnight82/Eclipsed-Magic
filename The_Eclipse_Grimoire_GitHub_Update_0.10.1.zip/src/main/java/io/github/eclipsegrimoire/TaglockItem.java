package io.github.eclipsegrimoire;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** A close-range sympathetic link; cannot silently target offline players. */
public final class TaglockItem extends Item {
    public TaglockItem(Properties properties){super(properties);}
    @Override public InteractionResult interactLivingEntity(ItemStack stack,Player player,LivingEntity target,InteractionHand hand) {
        if(!(player instanceof ServerPlayer witch)) return InteractionResult.SUCCESS;
        if(target==player || SpellCasting.protectedFrom(witch,target)) {
            witch.sendSystemMessage(Component.literal("[Eclipse] You cannot bind yourself, a coven ally, or a bonded familiar."));
            return InteractionResult.CONSUME;
        }
        if(target instanceof ServerPlayer && !witch.server.isPvpAllowed()) {
            witch.sendSystemMessage(Component.literal("[Eclipse] Player taglocks require server PvP to be enabled."));
            return InteractionResult.CONSUME;
        }
        CompoundTag tag=stack.getOrCreateTag();
        tag.putUUID("Target",target.getUUID());
        tag.putString("Name",target.getName().getString());
        tag.putString("Dimension",witch.serverLevel().dimension().location().toString());
        witch.sendSystemMessage(Component.literal("[Eclipse] Taglock linked to "+target.getName().getString()+". Use it to bind a poppet."));
        return InteractionResult.CONSUME;
    }
}
