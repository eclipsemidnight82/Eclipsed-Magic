# Changelog — The Eclipse Grimoire

## Alpha 0.10.0 — Rituals, Hexes & Poppetry

### Added
- Five cauldron-and-candle rituals using chalk rune focuses, reagents and mana.
- Four level-gated Hex spells: Weaken, Silence, Bind, and Track, with matching spell-wheel entries.
- Interactive Rituals, Hexes and Poppetry book chapters.
- Taglock Thread, Sympathetic Poppet, four Ritual Pins, Curse Bottle and Gris-Gris Charm Bag.
- New item models, custom pixel-art textures, survival crafting recipes and Creative tab items.
- Hex cleansing through Dispel, Curse Bottle and ritual.
- Server checks for PvP, protected coven members/familiars, target proximity and dimensions.

### Removed
- The complete 0.9.0 broom system: items/entities, flight networking, keybinds, GUI pages, cosmetics, resources and crafting recipe.

### Preserved
- All previous spells, rune selection/Binding Rune, charged salt, sealed doorways, familiar bonding, coven invitations, book styles, wheel preferences, XP and mana systems.

### Known boundaries
- Rituals are instant-use ceremonies, not persistent staged cutscenes.
- Poppets require nearby loaded targets and don't force-load entities or dimensions.
- Old broom objects may disappear on world upgrade; use backups.
- Full Forge build and gameplay testing are still required.
