# The Eclipse Grimoire — Alpha 0.10.0
## Rituals, Hexes & Poppetry

Minecraft 1.20.1 • Forge 47.4.0 • Java 17.

This release builds on the **gameplay-tested 0.9.0** source but **retires the entire broom feature**. Do not install the old and new mod jars together. Make a world backup and dismount/collect all brooms before upgrading; old broom items or entities may disappear when the ID is retired.

### New grimoire chapters
- **Rituals** — five rites, real altar checks and vanilla ingredients.
- **Hexes** — four short, reversible target spells.
- **Poppetry** — Taglock, poppet, ritual pin, curse bottle, and gris-gris guidance.
- Existing spells, Runes, Coven, Familiars, Wheel, Style, Settings are preserved.

### Five altar rituals (level 3, 24 mana each)
To perform a ritual, **place a chalk rune on solid ground, at least three enchanted witch candles within three blocks, and a vanilla cauldron within three blocks**. Hold the listed ingredient in your main hand. Aim directly at the chalk rune from no farther than six blocks, then choose the rite on the Rituals page or use the command.

| Rite | Required reagent | Effect |
|---|---|---|
| `/eclipse ritual healing` | Glistering melon slice | Heal caster, nearby coven members and bonded familiars |
| `/eclipse ritual restoration` | Amethyst shard | Restore caster mana and some nearby coven mana |
| `/eclipse ritual cleansing` | Milk bucket | Remove Eclipse hexes from caster and nearby coven |
| `/eclipse ritual protection` | Iron ingot | Give protective resistance to nearby allies and familiars |
| `/eclipse ritual revealing` | Glowstone dust | Briefly reveal nearby unprotected creatures |

The reagent is consumed in Survival and the caster gains XP. A milk bucket leaves an empty bucket. Rituals do not destroy the chalk, candles, or cauldron.

### Hexcraft (target within 12 blocks)
Use a grimoire button, the spell wheel, or `/eclipse cast hex_weaken|hex_silence|hex_bind|hex_mark`. These spells cost 18 mana and require line of sight. The minimum levels are 2, 4, 3, and 5 respectively.

| Hex | Effect |
|---|---|
| Weaken | Weakness for 30 sec, with brief slowing |
| Silence | Stop another witch's spells for 10 sec (ordinary mobs receive Weakness) |
| Bind | Strongly restrict movement for 6 sec |
| Track | Apply Glowing to the target for one minute |

Hexes cannot target yourself, protected coven members or bonded familiars. Player hexes require PvP enabled. Dispel, Curse Bottles, and the Cleansing Rite clear the hexes. Temporary potion effects end naturally.

### Poppetry — original fantasy sympathetic magic
These mechanics are fictional, **not a simulation or claim about the living Vodou religion**.

1. Craft **Taglock Thread**, and right-click a nearby living target to record its name/UUID and dimension (other players only when PvP is enabled).
2. Hold an unbound **Poppet** and use it to bind one linked taglock from your inventory.
3. Keep that poppet in your inventory. Use a **Black**, **Violet**, **Blue**, or **Silver** Ritual Pin to apply a remote version of Weaken, Silence, Bind or Track. The target must be **alive, loaded, in the same dimension and within 48 blocks**. Every successful pin costs 8 mana and consumes one pin in Survival.
4. **Curse Bottle** — one-use self-cleanse for Eclipse hexes. Returns an empty glass bottle.
5. **Gris-Gris Charm Bag** — carry it in your inventory to absorb one incoming hex; recharges after roughly 60 seconds of in-game time.

### Legacy support and safety
- Old coven, familiar, magic colors, book styles, salt, enchanted doors and binding rune systems remain.
- PvP disabled servers do not permit target hexes or taglocks on other players.
- Poppets only affect online/loaded nearby targets; they never force-load chunks or act on another dimension.
- The client wheel preferences automatically append newly learned hexes without resetting existing settings.
- **Brooms are removed entirely:** item, entity, customization, keybinds, recipes, models, resources and pages.

### Build the mod using GitHub Actions
1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.10.0.zip` unchanged to the root of your `Eclipsed-Magic` GitHub repository.
2. Replace `.github/workflows/build.yml` with the accompanying `Eclipsed_Magic_Build_0_10.yml` contents.
3. Commit to main. The workflow extracts this ZIP over the stable Forge project, confirms 0.10.0 and absent broom code, and runs `./gradlew --no-daemon build`.
4. Download the successful build artifact, extract its JAR, and test in a copied world before replacing the proven 0.9.0 JAR.

**Validation:** Static package/JSON/PNG checks were performed; full Forge compilation and game testing are still pending. This is an alpha release.
