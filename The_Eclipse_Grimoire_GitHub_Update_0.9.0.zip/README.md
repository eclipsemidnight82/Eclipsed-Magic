# The Eclipse Grimoire — Alpha 0.9.0

**Minecraft 1.20.1 • Forge 47.4.0 • Java 17**

This is an **uncompiled source update** based on the gameplay-tested Alpha 0.8.0.
Never replace your working 0.8.0 JAR until GitHub Actions compiles this update and a test world confirms the features are working. Back up the world as well.

## Enchanted broomsticks

- New **Enchanted Broomstick** craftable item in The Eclipse Grimoire Creative tab. Shaped recipe: amethyst shard (top-right), stick (center), wheat (bottom-left).
- Use the broom item on a block to place its 3D broom entity; right-click the unoccupied broom to mount it.
- **Flight:** WASD to steer, mouse to look/turn, Space to ascend, X to descend, R to toggle speed boost, Shift to dismount. X and R are **rebindable in Options → Controls → Key Binds → The Eclipse Grimoire**.
- Takeoff costs **8 mana**, then flight uses one mana every four seconds, or two while boosted. No spell cooldown. If mana is exhausted, the broom slowly descends. Creative Mode bypasses costs.
- Smooth, Agile, and Swift handling profiles, selected through the grimoire. Normal flight hovers gently.
- **Broom Atelier:** a new BROOM chapter with 3 pages of options. Change shape (5), wood (7), bristles (5), wrap (6), trail (6), sigil (5), accessory (6), handling (3), and magic color (auto + 8 individual colors). Customize the broom name and Reset to Default.
- Cosmetic choices change the broom's blocky 3D geometry, colors, and trail particles, and are saved both as a player preset and on the broom entity. While mounted, edits also update the current broom. Before placement, the player preset is used unless the broom item already has saved appearance data.
- Sneak-right-click an **unoccupied broom** as its owner to collect it with its appearance saved. Nobody else can take or ride the broom while the owner is set.
- Loaded, nearby pet parrots can try flying after their owner; ground animals are not automatically teleported into the air. Pets won't be duplicated or moved across dimensions.

**Visual limitations:** Custom 3D cuboids and colored particles render in-world, but there are no advanced rider pose animations, bespoke bird flight animation, or cinematic shaders in this alpha. Smooth multiplayer flight and entity tracking still need testing.

## Witch's Chalk and runecraft

- Chalk now draws **eight genuinely different sigil designs**: Moon, Star, Eclipse, Knot, Focus, Sun, Ward, and Binding. Every design is available in all eight magic colors, giving **64 rune textures**.
- Open the grimoire's new **RUNES** chapter to select a pattern, or **sneak-use Witch's Chalk** to cycle patterns without opening the book. The selected pattern is remembered per player across deaths.
- Place chalk normally to paint your selected pattern on a sturdy floor. Like previous chalk, each mark costs one durability in Survival.
- **Bind Rune**: level 3, 14 mana. Choose the Binding design, draw it, aim at it within 8 blocks, and cast `/eclipse cast rune_bind` or select it in the book/spell wheel. It arms once; when an outsider steps on it, the target is held in place for at most **60 seconds**, then freed. Recast on the rune to rearm.
- The owner, their coven and familiars are immune. Spectators and Creative players are immune. Player trapping is disabled on PvP-off servers. The rune doesn't change mob ownership.
- An active binding can be broken early by the **Dispel** spell (level 5, mana 18), including self-release if the bound player knows Dispel. Breaking the rune disarms it.
- Armed Rune positions and owner UUIDs save with their dimension; the actual temporary hold does not persist through server restarts, so no one is trapped indefinitely.
- The seven non-binding patterns are decorative in this update; they do not silently cast effects.

## Existing features protected

Previous spells, Coven, Familiars, absolute doorway seals, colored salt, Witchfire, thunder, grimoire customization and Quick Spell Wheel remain in place. Alpha 0.8.0's candles, chalk, braziers, mana, wardstones, bells, and creative tab remain registered.

## Build using GitHub (same steps as before)

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.9.0.zip` **still zipped** to the root of `eclipsemidnight82/Eclipsed-Magic`.
2. Replace `.github/workflows/build.yml` with `Eclipsed_Magic_Build_0_9.yml` (copy its contents; don't upload the YAML as an extra root file).
3. Commit and open GitHub Actions. It applies the ZIP into the existing nested `eclipse_grimoire_safe_build` directory, compiles using Forge 1.20.1 and uploads the compiled JAR if successful.
4. Extract the JAR from the successful workflow artifact. Test on a separate CurseForge profile and a backed-up world. Do not use 0.8.0 and 0.9.0 JARs simultaneously.

## Test checklist (important)

- [ ] Start in Forge 1.20.1, confirm Creative tab includes Enchanted Broom.
- [ ] Craft broom in Survival, place it on the ground, ride it, land safely.
- [ ] Check WASD, Space, X, R, Shift controls and rebindable keys; check low mana and boost.
- [ ] In a second client, verify broom render/trail and rider movement looks correct to observers.
- [ ] Broom Atelier: change each cosmetic option, verify the change is visible, save name, Reset to Default.
- [ ] Sneak-pick up broom and place it again; check appearance persists, including after a world restart.
- [ ] Confirm another player cannot collect the broom; ensure a parrot follows without ground-pet teleportation.
- [ ] Draw all eight colored rune patterns, including after rejoining the world.
- [ ] Arm Bind Rune, trigger using zombie, observe immobilization for 60 seconds, then rearm.
- [ ] Test owner/coven/familiar exemption, PvP-off server exemption, Dispel escape, breaking/removing rune.
- [ ] Verify existing magic, grimoire, salt barriers, candles, braziers, covens and familiars still work.

**Validation completed locally:** Java 17 syntax parsing, ZIP structure, JSON and PNG checks. **Not verified locally:** actual Forge compilation or Minecraft gameplay due to unavailable Forge/Gradle dependencies. Check the GitHub Actions logs for the first real compiler result.
