package io.github.eclipsegrimoire;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Server-authoritative book and low-bandwidth HUD sync; server validates every spell cast. */
public final class EclipseNetwork {
    private EclipseNetwork() { }
    private static final String VERSION="4";
    private static final SimpleChannel CHANNEL=NetworkRegistry.newSimpleChannel(
        new ResourceLocation(EclipseMod.MOD_ID,"main"),()->VERSION,VERSION::equals,VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0,OpenGrimoire.class,OpenGrimoire::encode,OpenGrimoire::decode,OpenGrimoire::handle);
        CHANNEL.registerMessage(1,WheelRequest.class,WheelRequest::encode,WheelRequest::decode,WheelRequest::handle);
        CHANNEL.registerMessage(2,WheelState.class,WheelState::encode,WheelState::decode,WheelState::handle);
        CHANNEL.registerMessage(3,ThunderEffect.class,ThunderEffect::encode,ThunderEffect::decode,ThunderEffect::handle);
        CHANNEL.registerMessage(4,WitchfireEffect.class,WitchfireEffect::encode,WitchfireEffect::decode,WitchfireEffect::handle);
        CHANNEL.registerMessage(5,BroomControl.class,BroomControl::encode,BroomControl::decode,BroomControl::handle);
    }
    public static void open(ServerPlayer player,ItemStack original) {
        ItemStack shown=original.copy();
        MagicData.stamp(shown,player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new OpenGrimoire(shown));
    }
    /** Called only when a player presses their wheel key, not every tick. */
    public static void requestWheel() {CHANNEL.sendToServer(new WheelRequest());}

    /** Actual beam geometry is rendered client-side and sent to all nearby observers. */
    public static void thunder(ServerLevel level,Vec3 from,Vec3 to,String color,int seed) {
        for(ServerPlayer player:level.players()) {
            if(player.position().distanceToSqr(from)<96*96)
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new ThunderEffect(from,to,color,seed));
        }
    }
    public static void witchfire(ServerPlayer caster) {
        for(ServerPlayer viewer:caster.serverLevel().players()) {
            if(viewer.position().distanceToSqr(caster.position())<80*80)
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                    new WitchfireEffect(caster.getId(),MagicData.magic(caster)));
        }
    }
    public static void broomControl(int forward,int strafe,int climb,boolean boost) {
        CHANNEL.sendToServer(new BroomControl(forward,strafe,climb,boost));
    }
    private record BroomControl(int forward,int strafe,int climb,boolean boost) {
        static void encode(BroomControl msg,FriendlyByteBuf buf) {
            buf.writeByte(msg.forward);buf.writeByte(msg.strafe);buf.writeByte(msg.climb);buf.writeBoolean(msg.boost);
        }
        static BroomControl decode(FriendlyByteBuf buf) {
            return new BroomControl(buf.readByte(),buf.readByte(),buf.readByte(),buf.readBoolean());
        }
        static void handle(BroomControl msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->{
                ServerPlayer player=ctx.getSender();
                if(player!=null && player.getVehicle() instanceof BroomEntity broom)
                    broom.control(player,msg.forward,msg.strafe,msg.climb,msg.boost);
            });
            ctx.setPacketHandled(true);
        }
    }
    private record ThunderEffect(Vec3 from,Vec3 to,String color,int seed) {
        static void encode(ThunderEffect msg,FriendlyByteBuf buf) {
            buf.writeDouble(msg.from.x);buf.writeDouble(msg.from.y);buf.writeDouble(msg.from.z);
            buf.writeDouble(msg.to.x);buf.writeDouble(msg.to.y);buf.writeDouble(msg.to.z);
            buf.writeUtf(msg.color,20);buf.writeInt(msg.seed);
        }
        static ThunderEffect decode(FriendlyByteBuf buf) {
            Vec3 from=new Vec3(buf.readDouble(),buf.readDouble(),buf.readDouble());
            Vec3 to=new Vec3(buf.readDouble(),buf.readDouble(),buf.readDouble());
            return new ThunderEffect(from,to,buf.readUtf(20),buf.readInt());
        }
        static void handle(ThunderEffect msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ArcaneRender.bolt(msg.from,msg.to,msg.color,msg.seed)));
            ctx.setPacketHandled(true);
        }
    }
    private record WitchfireEffect(int entityId,String color) {
        static void encode(WitchfireEffect msg,FriendlyByteBuf buf) {buf.writeVarInt(msg.entityId);buf.writeUtf(msg.color,20);}
        static WitchfireEffect decode(FriendlyByteBuf buf) {return new WitchfireEffect(buf.readVarInt(),buf.readUtf(20));}
        static void handle(WitchfireEffect msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ArcaneRender.flame(msg.entityId,msg.color)));
            ctx.setPacketHandled(true);
        }
    }
    private record OpenGrimoire(ItemStack book) {
        static void encode(OpenGrimoire msg,FriendlyByteBuf buf) {buf.writeItem(msg.book);}
        static OpenGrimoire decode(FriendlyByteBuf buf) {return new OpenGrimoire(buf.readItem());}
        static void handle(OpenGrimoire msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ClientBook.open(msg.book)));
            ctx.setPacketHandled(true);
        }
    }
    private record WheelRequest() {
        static void encode(WheelRequest msg,FriendlyByteBuf buf) { }
        static WheelRequest decode(FriendlyByteBuf buf) {return new WheelRequest();}
        static void handle(WheelRequest msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->{
                ServerPlayer player=ctx.getSender();
                if(player==null) return;
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new WheelState(MagicData.level(player),MagicData.mana(player),MagicData.maxMana(player),MagicData.magic(player)));
            });
            ctx.setPacketHandled(true);
        }
    }
    private record WheelState(int level,int mana,int maxMana,String magicColor) {
        static void encode(WheelState msg,FriendlyByteBuf buf) {
            buf.writeVarInt(msg.level);buf.writeVarInt(msg.mana);buf.writeVarInt(msg.maxMana);buf.writeUtf(msg.magicColor,32);
        }
        static WheelState decode(FriendlyByteBuf buf) {
            return new WheelState(buf.readVarInt(),buf.readVarInt(),buf.readVarInt(),buf.readUtf(32));
        }
        static void handle(WheelState msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.SpellWheel.receive(msg.level,msg.mana,msg.maxMana,msg.magicColor)));
            ctx.setPacketHandled(true);
        }
    }
}
