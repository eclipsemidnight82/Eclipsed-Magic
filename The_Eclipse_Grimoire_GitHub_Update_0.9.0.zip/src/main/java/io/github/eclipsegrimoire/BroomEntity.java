package io.github.eclipsegrimoire;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Parrot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraft.server.level.ServerLevel;

/** Non-destructive flying mount. Input is server-checked; settings and owner persist. */
public final class BroomEntity extends Entity {
    private static final EntityDataAccessor<CompoundTag> COSMETICS=SynchedEntityData.defineId(BroomEntity.class,EntityDataSerializers.COMPOUND_TAG);
    @Nullable private UUID owner;
    private int forward,strafe,vertical,controlTicks=0;
    private boolean boost;
    public BroomEntity(EntityType<? extends BroomEntity> type,Level level) {super(type,level);noPhysics=false;setNoGravity(true);}
    @Override protected void defineSynchedData(){entityData.define(COSMETICS,BroomConfig.defaults());}
    public CompoundTag cosmetics(){return BroomConfig.normalized(entityData.get(COSMETICS));}
    public String option(String field){return cosmetics().getString(field);}
    public String color(){String c=option("color");return "magic".equals(c)?"purple":c;}
    public void setOwner(UUID owner){this.owner=owner;}
    public boolean isOwner(Player p){return owner==null || owner.equals(p.getUUID());}
    public void configure(CompoundTag settings){
        var safe=BroomConfig.normalized(settings);
        entityData.set(COSMETICS,safe);
        setCustomName(net.minecraft.network.chat.Component.literal(safe.getString("name")));
    }
    public void control(ServerPlayer rider,int forward,int strafe,int vertical,boolean boost) {
        if(rider.getVehicle()!=this)return;
        this.forward=Math.max(-1,Math.min(1,forward));
        this.strafe=Math.max(-1,Math.min(1,strafe));
        this.vertical=Math.max(-1,Math.min(1,vertical));
        this.boost=boost;this.controlTicks=0;
    }
    @Override public void tick() {
        super.tick();
        if(level().isClientSide()) {
            if(tickCount%2==0 && (getFirstPassenger()!=null || !onGround())) {
                double r=(random.nextDouble()-.5)*.14;
                Vec3 tail=position().subtract(getLookAngle().scale(.8));
                level().addParticle(ArcaneEffects.dust(color(),.95f),tail.x+r,tail.y+.24,tail.z+r,0,.005,0);
                if("runes".equals(option("trail"))) {
                    for(int i=0;i<4;i++) {
                        double a=Math.PI*i/2+tickCount*.13;
                        level().addParticle(ArcaneEffects.dust(color(),.7f),
                            tail.x+.18*Math.cos(a),tail.y+.19+.18*Math.sin(a),tail.z,0,.01,0);
                    }
                }
                if("stars".equals(option("trail")) || "wisps".equals(option("trail")))
                    level().addParticle(net.minecraft.core.particles.ParticleTypes.END_ROD,tail.x+r,tail.y+.25,tail.z+r,0,.025,0);
                else if("smoke".equals(option("trail")))
                    level().addParticle(net.minecraft.core.particles.ParticleTypes.SMOKE,tail.x+r,tail.y+.25,tail.z+r,0,.017,0);
                else if("lightning".equals(option("trail")))
                    level().addParticle(net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK,tail.x+r,tail.y+.25,tail.z+r,0,.017,0);
            }
            return;
        }
        if(getFirstPassenger() instanceof ServerPlayer player) {
            if(controlTicks++>10) {forward=0;strafe=0;vertical=0;boost=false;}
            setYRot(player.getYRot());setXRot(0);
            boolean powered=MagicData.mana(player)>0 || player.isCreative();
            if(tickCount%80==0 && !player.isCreative() && !MagicData.spend(player,boost?2:1)) powered=false;
            if(!powered) {forward=0;strafe=0;vertical=-1;boost=false;}
            double yaw=Math.toRadians(player.getYRot());
            double dx=-Math.sin(yaw)*forward + Math.cos(yaw)*strafe;
            double dz=Math.cos(yaw)*forward + Math.sin(yaw)*strafe;
            double length=Math.sqrt(dx*dx+dz*dz);
            if(length>1){dx/=length;dz/=length;}
            double speed=switch(option("handling")) {case "agile"->.35;case "swift"->.45;default->.29;};
            if(boost && powered) speed*=1.6;
            double dy=vertical>0 && powered?.26:vertical<0?-.24:0;
            Vec3 desired=new Vec3(dx*speed,dy,dz*speed);
            Vec3 smoothed=getDeltaMovement().scale(.65).add(desired.scale(.35));
            setDeltaMovement(smoothed);
            move(MoverType.SELF,smoothed);
            player.fallDistance=0;
            // Existing, loaded parrots may fly alongside their owner. Ground pets remain safely on land.
            if(tickCount%30==0 && level() instanceof ServerLevel nearby) {
                for(Parrot bird:nearby.getEntitiesOfClass(Parrot.class,player.getBoundingBox().inflate(18),
                    e->e.isTame() && !e.isOrderedToSit() && player.getUUID().equals(e.getOwnerUUID())))
                    bird.getNavigation().moveTo(player,1.2);
            }
            if(level() instanceof ServerLevel server && tickCount%75==0)
                server.playSound(null,blockPosition(),SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.PLAYERS,.35f,1.4f);
        } else {
            setDeltaMovement(getDeltaMovement().scale(.83).add(0,onGround()?0:-.045,0));
            move(MoverType.SELF,getDeltaMovement());
        }
    }
    @Override public boolean isPickable(){return true;}
    @Override protected boolean canAddPassenger(Entity p){return getPassengers().isEmpty();}
    @Override protected void positionRider(Entity passenger,MoveFunction move){
        if(hasPassenger(passenger)) move.accept(passenger,getX(),getY()+.31,getZ());
    }
    @Override public InteractionResult interact(Player player,InteractionHand hand) {
        if(player.isShiftKeyDown() && getPassengers().isEmpty()) {
            if(!isOwner(player)) {player.displayClientMessage(net.minecraft.network.chat.Component.literal("[Eclipse] This broom belongs to another witch."),true);return InteractionResult.sidedSuccess(level().isClientSide());}
            if(!level().isClientSide()) {
                ItemStack item=new ItemStack(EclipseMod.BROOM_ITEM.get());
                item.getOrCreateTag().put("broom",cosmetics());
                item.setHoverName(net.minecraft.network.chat.Component.literal(cosmetics().getString("name")));
                if(!player.getInventory().add(item)) player.drop(item,false);
                discard();
            }
            return InteractionResult.sidedSuccess(level().isClientSide());
        }
        if(!getPassengers().isEmpty()) return InteractionResult.PASS;
        if(!level().isClientSide() && player instanceof ServerPlayer p) {
            if(!isOwner(p)) {p.displayClientMessage(net.minecraft.network.chat.Component.literal("[Eclipse] Only its owner may fly this broom."),true);return InteractionResult.CONSUME;}
            if(!p.isCreative() && !MagicData.spend(p,8)) {p.displayClientMessage(net.minecraft.network.chat.Component.literal("[Eclipse] Takeoff requires 8 mana."),true);return InteractionResult.CONSUME;}
            p.startRiding(this);
            level().playSound(null,blockPosition(),SoundEvents.ENDERMAN_TELEPORT,SoundSource.PLAYERS,.6f,1.45f);
        }
        return InteractionResult.sidedSuccess(level().isClientSide());
    }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        if(tag.hasUUID("owner")) owner=tag.getUUID("owner");
        if(tag.contains("appearance",10)) configure(tag.getCompound("appearance"));
    }
    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        if(owner!=null)tag.putUUID("owner",owner);
        tag.put("appearance",cosmetics());
    }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket(){return NetworkHooks.getEntitySpawningPacket(this);}
}
