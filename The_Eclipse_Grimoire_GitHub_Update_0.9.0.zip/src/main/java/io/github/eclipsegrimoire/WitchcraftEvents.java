package io.github.eclipsegrimoire;

import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.BlockEvent.EntityPlaceEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Server-only item effects; ownership is saved per dimension. */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class WitchcraftEvents {
    private WitchcraftEvents() { }
    /** Intercept normal pet use before the sit/stand interaction consumes the click. */
    @SubscribeEvent public static void charmUsedOnPet(PlayerInteractEvent.EntityInteract event) {
        if(event.getHand()!=InteractionHand.MAIN_HAND || !event.getItemStack().is(EclipseMod.FAMILIAR_CHARM.get())
            || !(event.getTarget() instanceof TamableAnimal pet)) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(event.getLevel().isClientSide()));
        if(event.getEntity() instanceof ServerPlayer witch)
            ((FamiliarCharmItem)EclipseMod.FAMILIAR_CHARM.get()).interactLivingEntity(event.getItemStack(),witch,pet,event.getHand());
    }
    @SubscribeEvent public static void placed(EntityPlaceEvent event) {
        if(!(event.getLevel() instanceof ServerLevel level) || !(event.getEntity() instanceof ServerPlayer p)) return;
        if(!(event.getPlacedBlock().getBlock() instanceof MagicDecorBlock b)) return;
        if(b.kind()==MagicDecorBlock.Kind.WARDSTONE || b.kind()==MagicDecorBlock.Kind.BELL)
            WitchcraftData.get(level).bind(event.getPos(),b.kind(),p.getUUID());
    }
    @SubscribeEvent public static void broken(BlockEvent.BreakEvent event) {
        if(!(event.getLevel() instanceof ServerLevel level)) return;
        if(event.getState().getBlock() instanceof RuneBlock) WitchcraftData.get(level).disarmRune(event.getPos());
        if(event.getState().getBlock() instanceof MagicDecorBlock b &&
            (b.kind()==MagicDecorBlock.Kind.WARDSTONE || b.kind()==MagicDecorBlock.Kind.BELL))
            WitchcraftData.get(level).remove(event.getPos());
    }
    @SubscribeEvent public static void worldTick(TickEvent.LevelTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        if(level.getGameTime()%10!=0) return;
        WitchcraftData data=WitchcraftData.get(level);
        for(Map.Entry<Long,UUID> entry:data.wardstones().entrySet()) {
            BlockPos pos=BlockPos.of(entry.getKey());
            if(!level.hasChunkAt(pos)) continue;
            if(!(level.getBlockState(pos).getBlock() instanceof MagicDecorBlock b) || b.kind()!=MagicDecorBlock.Kind.WARDSTONE) {
                data.remove(pos);continue;
            }
            if(data.suppressed(pos,level.getGameTime())) continue;
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(pos).inflate(6),
                e->e.isAlive() && e instanceof Enemy)) {
                if(WardData.canCross(level,entry.getValue(),target)) continue;
                Vec3 away=target.position().subtract(Vec3.atCenterOf(pos));
                double d=Math.max(.25,away.horizontalDistance());
                if(d>6) continue;
                target.setDeltaMovement(away.x/d*.36,Math.max(.11,target.getDeltaMovement().y),away.z/d*.36);
                target.hasImpulse=true;
                if(level.getGameTime()%30==0) ArcaneEffects.point(level,b.color(),target.position().add(0,1,0));
            }
        }
        for(Map.Entry<Long,UUID> entry:data.bells().entrySet()) {
            BlockPos pos=BlockPos.of(entry.getKey());
            if(!level.hasChunkAt(pos)) continue;
            if(!(level.getBlockState(pos).getBlock() instanceof MagicDecorBlock b) || b.kind()!=MagicDecorBlock.Kind.BELL) {
                data.remove(pos);continue;
            }
            if(data.suppressed(pos,level.getGameTime())) continue;
            boolean trespass=false;
            for(LivingEntity target:level.getEntitiesOfClass(LivingEntity.class,new AABB(pos).inflate(7),
                e->e.isAlive() && (e instanceof Enemy || e instanceof ServerPlayer))) {
                if(WardData.canCross(level,entry.getValue(),target)) continue;
                trespass=true;break;
            }
            if(trespass && data.readyToRing(pos,level.getGameTime())) {
                level.playSound(null,pos,SoundEvents.BELL_BLOCK,SoundSource.BLOCKS,1.35f,.75f);
                level.sendParticles(ParticleTypes.END_ROD,pos.getX()+.5,pos.getY()+1.15,pos.getZ()+.5,18,.4,.4,.4,.025);
                for(ServerPlayer watcher:level.players())
                    if(watcher.getUUID().equals(entry.getValue()) || CovenData.get(level).same(watcher.getUUID(),entry.getValue()))
                        watcher.sendSystemMessage(Component.literal("[Eclipse] Witch's Bell: an outsider approaches at "
                            +pos.getX()+", "+pos.getY()+", "+pos.getZ()+"."));
            }
        }
    }
}
