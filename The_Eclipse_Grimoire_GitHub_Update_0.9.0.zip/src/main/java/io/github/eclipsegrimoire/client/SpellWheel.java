package io.github.eclipsegrimoire.client;

import java.util.ArrayList;
import java.util.List;
import io.github.eclipsegrimoire.EclipseMod;
import io.github.eclipsegrimoire.EclipseNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * A HUD overlay, NOT a Screen: players retain movement, attack, jumping and mouse look.
 * Hold configurable key (G by default), scroll to select, release to cast; opening a menu cancels.
 */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class SpellWheel {
    private SpellWheel() { }
    private static final KeyMapping OPEN=new KeyMapping("key.eclipse_grimoire.spell_wheel",
        GLFW.GLFW_KEY_G,"key.categories.eclipse_grimoire");
    private record Entry(String id,String label,int requiredLevel,int cost) { }
    private static final List<Entry> ALL=List.of(
        new Entry("ward","Ward",1,8), new Entry("power","Power",1,10),
        new Entry("witchlight","Witchlight",1,12),
        new Entry("mend","Mend",1,12), new Entry("veil","Veil",2,15),
        new Entry("bind","Bind",2,15), new Entry("tether","Arcane Tether",2,10),
        new Entry("pulse","Telekinetic Pulse",2,14), new Entry("circle","Salt Circle",3,20),
        new Entry("seal","Seal Salt",3,12), new Entry("absolute","Absolute Seal",3,12),
        new Entry("infuse","Infuse Salt",3,8),new Entry("rune_bind","Bind Rune",3,14),
        new Entry("shatter","Shatter",4,22), new Entry("thunder","Thunder",4,30),
        new Entry("blink","Blink",4,18), new Entry("dispel","Dispel",5,18),
        new Entry("witchfire","Witchfire",6,30),
        new Entry("aegis","Final Aegis",6,40)
    );
    private static boolean active=false;
    private static int selected=0,level=1,mana=100,maxMana=100;
    private static String magicColor="purple";
    private static Level knownLevel=null;

    @SubscribeEvent public static void keys(RegisterKeyMappingsEvent event) {event.register(OPEN);}
    @SubscribeEvent public static void overlay(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("spell_wheel",(gui,graphics,partial,width,height)->render(graphics,width,height));
    }
    public static void receive(int playerLevel,int currentMana,int capacity,String color) {
        level=Math.max(1,Math.min(20,playerLevel));
        mana=Math.max(0,currentMana);
        maxMana=Math.max(100,capacity);
        magicColor=color;
        int size=unlocked().size();
        if(size>0) selected=Math.floorMod(selected,size);
    }
    private static List<Entry> unlocked() {
        List<Entry> found=new ArrayList<>();
        WheelPreferences prefs=WheelPreferences.get();
        for(String id:prefs.order()) for(Entry entry:ALL)
            if(entry.id.equals(id) && level>=entry.requiredLevel && prefs.shown(id)) found.add(entry);
        return found;
    }
    public static String label(String id) {
        for(Entry entry:ALL) if(entry.id.equals(id)) return entry.label;
        return id;
    }
    private static int accent() {
        String color=WheelPreferences.get().color();
        if("magic".equals(color)) color=magicColor;
        return switch(color) {
            case "crimson" -> 0xe34e69; case "blue" -> 0x54a6ef;
            case "emerald" -> 0x43bd94; case "gold" -> 0xe6b74e;
            case "white" -> 0xe7dfe9; case "shadow" -> 0x9a90ab;
            case "rose" -> 0xed91cb; default -> 0xa46af5;
        };
    }
    private static boolean usable(Minecraft mc) {
        return mc.player!=null && mc.level!=null && mc.screen==null && !mc.isPaused();
    }
    @Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE,value=Dist.CLIENT)
    public static final class Events {
        private Events() { }
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
            if(event.phase!=TickEvent.Phase.END) return;
            Minecraft mc=Minecraft.getInstance();
            if(mc.level!=knownLevel) {
                knownLevel=mc.level;
                active=false;
                level=1;mana=100;maxMana=100;magicColor="purple";
            }
            boolean down=usable(mc) && OPEN.isDown();
            if(down && !active) {
                active=true;
                selected=0;
                EclipseNetwork.requestWheel();
            } else if(!down && active) {
                active=false;
                // A menu, chat, or disconnection cancels casting instead of accidentally firing a spell.
                if(usable(mc) && mc.player.connection!=null) {
                    List<Entry> choices=unlocked();
                    if(!choices.isEmpty())
                        mc.player.connection.sendCommand("eclipse cast "+choices.get(Math.floorMod(selected,choices.size())).id);
                }
            }
        }
        @SubscribeEvent public static void scroll(InputEvent.MouseScrollingEvent event) {
            if(!active) return;
            List<Entry> choices=unlocked();
            if(choices.isEmpty()) return;
            double delta=event.getScrollDelta();
            if(delta!=0) selected=Math.floorMod(selected+(delta>0?-1:1),choices.size());
            event.setCanceled(true); // scroll selects the spell, not the hotbar slot
        }
    }
    private static int alpha(int rgb,int opacity) {
        return ((Math.max(0,Math.min(255,opacity)) & 0xff)<<24) | (rgb & 0x00ffffff);
    }
    /** The HUD only renders a handful of spells at once. Scrolling crosses pages seamlessly. */
    private static void ring(GuiGraphics g,int cx,int cy,int radius,int rgb) {
        for(int a=0;a<72;a++) {
            double theta=a*Math.PI/36.0;
            int x=cx+(int)Math.round(Math.cos(theta)*radius);
            int y=cy+(int)Math.round(Math.sin(theta)*radius);
            g.fill(x,y,x+2,y+2,rgb);
        }
    }
    private static String compactLabel(Entry entry) {
        return switch(entry.id) {
            case "tether" -> "Tether";
            case "pulse" -> "Pulse";
            case "circle" -> "Circle";
            case "infuse" -> "Infuse";
            case "witchfire" -> "Witchfire";
            case "aegis" -> "Aegis";
            case "thunder" -> "Thunder";
            case "shatter" -> "Shatter";
            default -> entry.label;
        };
    }
    private static void render(GuiGraphics graphics,int width,int height) {
        Minecraft mc=Minecraft.getInstance();
        if(!active || !usable(mc)) return;
        List<Entry> choices=unlocked();
        if(choices.isEmpty()) return;
        WheelPreferences prefs=WheelPreferences.get();
        int cx=width/2,cy=height/2,highlight=accent();
        int opacity=prefs.opacity()*255/100;
        selected=Math.floorMod(selected,choices.size());

        // A six-spell wheel keeps labels readable. Small GUI windows show four at once.
        // Scroll selection still visits *every* unlocked, non-hidden spell in order.
        boolean compact=width<340 || height<230;
        int perPage=compact?4:6;
        int page=selected/perPage;
        int start=page*perPage;
        int visible=Math.min(perPage,choices.size()-start);
        int totalPages=(choices.size()+perPage-1)/perPage;
        int allowed=Math.min((width-120)/2,(height-86)/2);
        int radius=Math.max(35,Math.min(prefs.radius(),allowed));
        // Ring sits inside the screen, independent of GUI scale and player-selected size.
        ring(graphics,cx,cy,Math.max(12,radius-11),alpha(highlight,Math.min(210,opacity)));

        for(int i=0;i<visible;i++) {
            int slot=start+i;
            Entry entry=choices.get(slot);
            double theta=(Math.PI*2*i/visible)-Math.PI/2;
            int x=cx+(int)Math.round(Math.cos(theta)*radius);
            int y=cy+(int)Math.round(Math.sin(theta)*radius);
            boolean chosen=slot==selected;
            String label=compactLabel(entry);
            int maxLabelWidth=compact?70:94;
            label=mc.font.plainSubstrByWidth(label,maxLabelWidth);
            int w=Math.min(maxLabelWidth+12,Math.max(45,mc.font.width(label)+12));
            int h=17;
            int left=Math.max(2,Math.min(width-w-2,x-w/2));
            int top=Math.max(2,Math.min(height-h-2,y-h/2));
            int fill=alpha(chosen?0x39234a:0x1b132b,chosen?Math.min(240,opacity+60):opacity);
            graphics.fill(left,top,left+w,top+h,fill);
            if(chosen) {
                int border=0xFF000000|highlight;
                graphics.fill(left,top,left+w,top+1,border);
                graphics.fill(left,top,left+1,top+h,border);
                graphics.fill(left+w-1,top,left+w,top+h,border);
                graphics.fill(left,top+h-1,left+w,top+h,border);
            }
            graphics.drawCenteredString(mc.font,label,left+w/2,top+4,chosen?0xFFFFFFFF:0xFFE5D9EA);
        }

        Entry chosen=choices.get(selected);
        if(!compact) {
            int panelW=Math.min(118,Math.max(88,width/3));
            graphics.fill(cx-panelW/2,cy-23,cx+panelW/2,cy+26,alpha(0x120e19,Math.min(220,opacity+36)));
            String middle=mc.font.plainSubstrByWidth(chosen.label,panelW-8);
            graphics.drawCenteredString(mc.font,middle,cx,cy-15,0xFFF4E4FE);
            graphics.drawCenteredString(mc.font,"Mana "+mana+"/"+maxMana,cx,cy-1,0xFFDFCAEE);
            graphics.drawCenteredString(mc.font,"Cost "+chosen.cost,cx,cy+12,mana>=chosen.cost?0xFFDEBDFB:0xFFFF8888);
        } else {
            graphics.fill(cx-8,cy-8,cx+9,cy+9,alpha(0x1b132b,opacity));
            graphics.fill(cx-3,cy-3,cx+4,cy+4,0xFF000000|highlight);
            // On smaller screens keep selected information *outside* the ring.
            graphics.drawCenteredString(mc.font,mc.font.plainSubstrByWidth(chosen.label,width-26),cx,8,0xFFF4E4FE);
        }
        String pageText="SPELLS "+(selected+1)+"/"+choices.size()+"  |  PAGE "+(page+1)+"/"+totalPages;
        graphics.drawCenteredString(mc.font,pageText,cx,compact?20:Math.max(5,cy-radius-30),0xFFE5D9EA);
        if(compact)
            graphics.drawCenteredString(mc.font,"Mana "+mana+"/"+maxMana+"  |  Cost "+chosen.cost,cx,height-25,mana>=chosen.cost?0xFFDFCAEE:0xFFFF8888);
        graphics.drawCenteredString(mc.font,"Scroll: select  |  Release "+OPEN.getTranslatedKeyMessage().getString()+": cast",cx,height-13,0xFFE2CDEB);
    }
}
