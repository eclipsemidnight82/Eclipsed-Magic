package io.github.eclipsegrimoire.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import io.github.eclipsegrimoire.BroomEntity;
import io.github.eclipsegrimoire.ArcaneEffects;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Small colorful 3D broom built from cuboids so wood, bristles and wraps really recolor in-world.
 *  Shape and accessories alter geometry; trails and sigils follow the magic-color selection. */
public final class BroomRenderer extends EntityRenderer<BroomEntity> {
    private static final ResourceLocation WHITE=new ResourceLocation("minecraft","textures/block/white_concrete.png");
    public BroomRenderer(EntityRendererProvider.Context context){super(context);shadowRadius=.32f;}
    @Override public ResourceLocation getTextureLocation(BroomEntity entity){return WHITE;}
    @Override public void render(BroomEntity b,float yaw,float partial,PoseStack stack,MultiBufferSource buffer,int light) {
        stack.pushPose();
        stack.translate(0,.34+Math.sin((b.tickCount+partial)*.09)*.025,0);
        stack.mulPose(Axis.YP.rotationDegrees(180-yaw));
        VertexConsumer v=buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        int wood=switch(b.option("wood")) {
            case "spruce"->0x6f4b35;case "birch"->0xdac9a1;case "dark_oak"->0x38261f;
            case "cherry"->0xad7180;case "ebony"->0x231d25;case "ash"->0xa6a8ae;default->0x956640;};
        int straw=switch(b.option("bristles")) {
            case "feather"->0x38333e;case "silver"->0xc3c7cd;case "crystal"->0x9da1ef;
            case "enchanted"->ArcaneEffects.rgb(b.color());default->0xc5a76b;};
        int wrap=switch(b.option("wrap")) {
            case "gold"->0xe3bb54;case "silver"->0xc7ccd4;case "vine"->0x537953;
            case "velvet"->0x683f82;case "leather"->0x553a2b;default->wood;};
        boolean crook="crooked".equals(b.option("shape")) || "thornwood".equals(b.option("shape"));
        float width="royal".equals(b.option("shape"))?.095f:.065f;
        box(v,stack,-width,-.065f,-.95f,width,.065f,.95f,wood,light);
        if(crook) box(v,stack,-.12f,.02f,.57f,.01f,.12f,.86f,wood,light);
        float tailWidth="royal".equals(b.option("shape"))?.32f:.24f;
        box(v,stack,-tailWidth,-.085f,-1.1f,tailWidth,.09f,-.44f,straw,light);
        for(int i=-3;i<=3;i++) {
            float offset=i*.075f;
            box(v,stack,offset-.018f,-.085f,-1.42f-(i%2==0?.1f:0),offset+.018f,.018f,-.89f,straw,light);
        }
        // Three separate wrappings physically visible on the handle.
        for(int i=0;i<3;i++) {
            float z=.22f+i*.22f;
            box(v,stack,-width-.014f,-.084f,z,width+.014f,.084f,z+.045f,wrap,light);
        }
        int gemstone=ArcaneEffects.rgb(b.color());
        // Decorative crown depends on the chosen talisman: not all accessories look alike.
        if(!"none".equals(b.option("accessory"))) {
            int accent="lantern".equals(b.option("accessory"))?0xffcb74:
                       "bells".equals(b.option("accessory"))?0xe6d19a:gemstone;
            box(v,stack,-.065f,.1f,.68f,.065f,.26f,.82f,accent,light);
            if("crystal".equals(b.option("accessory")))
                box(v,stack,-.04f,.24f,.72f,.04f,.38f,.78f,0xd1d2fe,light);
            if("bells".equals(b.option("accessory"))) {
                box(v,stack,-.16f,-.15f,.67f,-.08f,-.055f,.78f,accent,light);
                box(v,stack,.08f,-.15f,.67f,.16f,-.055f,.78f,accent,light);
            }
            if("ribbons".equals(b.option("accessory"))) {
                box(v,stack,-.28f,.1f,.69f,-.1f,.14f,.84f,gemstone,light);
                box(v,stack,.1f,.1f,.69f,.28f,.14f,.84f,gemstone,light);
            }
        }
        if("thornwood".equals(b.option("shape"))) for(int i=0;i<4;i++) {
            float z=-.37f+i*.22f;
            box(v,stack,-.19f,.02f,z,-.075f,.11f,z+.06f,wood,light);
        }
        if("celestial".equals(b.option("shape")) || "royal".equals(b.option("shape"))) {
            box(v,stack,-.14f,.105f,-.53f,.14f,.15f,-.39f,gemstone,light);
        }
        // Sigils appear as physical gems/etched lines above the handle.
        String sigil=b.option("sigil");
        if("moon".equals(sigil)) {
            box(v,stack,-.1f,.09f,.12f,.02f,.11f,.18f,gemstone,light);
            box(v,stack,-.1f,.09f,.18f,-.035f,.11f,.29f,gemstone,light);
        } else if("star".equals(sigil)) {
            box(v,stack,-.16f,.09f,.17f,.16f,.11f,.22f,gemstone,light);
            box(v,stack,-.025f,.09f,.05f,.025f,.11f,.35f,gemstone,light);
        } else if("knot".equals(sigil)) {
            box(v,stack,-.10f,.09f,.11f,.10f,.11f,.15f,gemstone,light);
            box(v,stack,-.10f,.09f,.27f,.10f,.11f,.31f,gemstone,light);
            box(v,stack,-.1f,.09f,.15f,-.06f,.11f,.27f,gemstone,light);
            box(v,stack,.06f,.09f,.15f,.10f,.11f,.27f,gemstone,light);
        } else {
            box(v,stack,-.06f,.09f,.15f,.06f,.11f,.26f,gemstone,light);
        }
        stack.popPose();
        super.render(b,yaw,partial,stack,buffer,light);
    }
    private static void box(VertexConsumer consumer,PoseStack pose,float x1,float y1,float z1,
                            float x2,float y2,float z2,int rgb,int light) {
        int r=(rgb>>16)&255,g=(rgb>>8)&255,bl=rgb&255;
        face(consumer,pose,r,g,bl,light,0,1,0,new float[][]{{x1,y2,z1},{x1,y2,z2},{x2,y2,z2},{x2,y2,z1}});
        face(consumer,pose,r,g,bl,light,0,-1,0,new float[][]{{x1,y1,z2},{x1,y1,z1},{x2,y1,z1},{x2,y1,z2}});
        face(consumer,pose,r,g,bl,light,0,0,1,new float[][]{{x2,y1,z2},{x1,y1,z2},{x1,y2,z2},{x2,y2,z2}});
        face(consumer,pose,r,g,bl,light,0,0,-1,new float[][]{{x1,y1,z1},{x2,y1,z1},{x2,y2,z1},{x1,y2,z1}});
        face(consumer,pose,r,g,bl,light,1,0,0,new float[][]{{x2,y1,z1},{x2,y1,z2},{x2,y2,z2},{x2,y2,z1}});
        face(consumer,pose,r,g,bl,light,-1,0,0,new float[][]{{x1,y1,z2},{x1,y1,z1},{x1,y2,z1},{x1,y2,z2}});
    }
    private static void face(VertexConsumer v,PoseStack stack,int r,int g,int b,int light,
                             float nx,float ny,float nz,float[][] ps) {
        float[][] uv={{0,0},{0,1},{1,1},{1,0}};
        for(int i=0;i<4;i++) {
            float[] p=ps[i];
            v.vertex(stack.last().pose(),p[0],p[1],p[2]).color(r,g,b,255)
                .uv(uv[i][0],uv[i][1]).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(stack.last().normal(),nx,ny,nz).endVertex();
        }
    }
}
