package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.BroomEntity;
import io.github.eclipsegrimoire.EclipseMod;
import io.github.eclipsegrimoire.EclipseNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/** Configurable flight keys. Server validates each movement packet against the player's mount. */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class BroomClient {
    private BroomClient() {}
    private static final KeyMapping DESCEND=new KeyMapping("key.eclipse_grimoire.broom_descend",GLFW.GLFW_KEY_X,"key.categories.eclipse_grimoire");
    private static final KeyMapping BOOST=new KeyMapping("key.eclipse_grimoire.broom_boost",GLFW.GLFW_KEY_R,"key.categories.eclipse_grimoire");
    private static boolean speeding=false;
    private static int lastVehicle=-1;
    @SubscribeEvent public static void register(RegisterKeyMappingsEvent event){event.register(DESCEND);event.register(BOOST);}
    @SubscribeEvent public static void registerRender(EntityRenderersEvent.RegisterRenderers event){
        event.registerEntityRenderer(EclipseMod.BROOM_ENTITY.get(),BroomRenderer::new);
    }
    @Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE,value=Dist.CLIENT)
    public static final class ClientTicks {
        private ClientTicks() {}
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
            if(event.phase!=TickEvent.Phase.END) return;
            Minecraft mc=Minecraft.getInstance();
            if(mc.player==null || !(mc.player.getVehicle() instanceof BroomEntity broom)) {lastVehicle=-1;speeding=false;return;}
            if(mc.screen!=null || mc.isPaused()) return;
            if(lastVehicle!=broom.getId()) {lastVehicle=broom.getId();speeding=false;}
            while(BOOST.consumeClick()) speeding=!speeding;
            if(mc.player.tickCount%3!=0) return;
            int forward=(mc.options.keyUp.isDown()?1:0)-(mc.options.keyDown.isDown()?1:0);
            int sideways=(mc.options.keyRight.isDown()?1:0)-(mc.options.keyLeft.isDown()?1:0);
            int climb=(mc.options.keyJump.isDown()?1:0)-(DESCEND.isDown()?1:0);
            EclipseNetwork.broomControl(forward,sideways,climb,speeding);
        }
    }
}
