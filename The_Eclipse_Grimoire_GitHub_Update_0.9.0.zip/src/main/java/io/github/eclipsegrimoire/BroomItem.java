package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.AABB;

/** Places one real rideable broom entity; collecting it preserves its appearance. */
public final class BroomItem extends Item {
    public BroomItem(Properties properties){super(properties);}
    @Override public InteractionResult useOn(UseOnContext ctx) {
        BlockPos pos=ctx.getClickedPos().relative(ctx.getClickedFace());
        if(!ctx.getLevel().getBlockState(pos).getCollisionShape(ctx.getLevel(),pos).isEmpty()) return InteractionResult.FAIL;
        if(ctx.getLevel().isClientSide()) return InteractionResult.SUCCESS;
        if(!(ctx.getPlayer() instanceof ServerPlayer p) || !(ctx.getLevel() instanceof ServerLevel level)) return InteractionResult.FAIL;
        if(!level.getEntitiesOfClass(BroomEntity.class,new AABB(pos)).isEmpty()) return InteractionResult.FAIL;
        BroomEntity broom=new BroomEntity(EclipseMod.BROOM_ENTITY.get(),level);
        broom.moveTo(pos.getX()+.5,pos.getY()+.1,pos.getZ()+.5,p.getYRot(),0);
        broom.setOwner(p.getUUID());
        var config=ctx.getItemInHand().getTag();
        var settings=config!=null && config.contains("broom",10)
            ?BroomConfig.normalized(config.getCompound("broom")):BroomConfig.preset(p);
        if("magic".equals(settings.getString("color")))settings.putString("color",MagicData.magic(p));
        broom.configure(settings);
        if(!level.noCollision(broom)) return InteractionResult.FAIL;
        if(!level.addFreshEntity(broom)) return InteractionResult.FAIL;
        if(!p.isCreative()) ctx.getItemInHand().shrink(1);
        level.playSound(null,pos,SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.PLAYERS,.85f,.8f);
        p.displayClientMessage(Component.literal("[Eclipse] Right-click to ride. Sneak-right-click an empty broom to collect it."),true);
        return InteractionResult.CONSUME;
    }
}
