package io.github.eclipsegrimoire;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;

/** Whitelisted cosmetic parts, saved as a player preset and on each placed broom. */
public final class BroomConfig {
    private BroomConfig() {}
    public static final Map<String,List<String>> OPTIONS=new LinkedHashMap<>();
    static {
        OPTIONS.put("shape",List.of("classic","crooked","royal","thornwood","celestial"));
        OPTIONS.put("wood",List.of("oak","spruce","birch","dark_oak","cherry","ebony","ash"));
        OPTIONS.put("bristles",List.of("straw","feather","silver","crystal","enchanted"));
        OPTIONS.put("wrap",List.of("none","leather","velvet","gold","silver","vine"));
        OPTIONS.put("trail",List.of("sparkles","runes","smoke","wisps","stars","lightning"));
        OPTIONS.put("sigil",List.of("eclipse","moon","star","knot","rune"));
        OPTIONS.put("accessory",List.of("none","lantern","charm","crystal","ribbons","bells"));
        OPTIONS.put("handling",List.of("smooth","agile","swift"));
        OPTIONS.put("color",List.of("magic","purple","crimson","blue","emerald","gold","white","shadow","rose"));
    }
    public static String safe(String field,String value) {
        List<String> choices=OPTIONS.get(field);
        return choices==null?"":choices.contains(value)?value:choices.get(0);
    }
    public static CompoundTag defaults() {
        CompoundTag tag=new CompoundTag();
        OPTIONS.forEach((key,choices)->tag.putString(key,choices.get(0)));
        tag.putString("name","Enchanted Broom");
        return tag;
    }
    public static CompoundTag normalized(CompoundTag source) {
        CompoundTag tag=defaults();
        OPTIONS.forEach((key,choices)->{
            String value=source.getString(key);
            if(choices.contains(value)) tag.putString(key,value);
        });
        String name=source.getString("name").trim();
        if(!name.isEmpty()) tag.putString("name",name.substring(0,Math.min(32,name.length())));
        return tag;
    }
    public static CompoundTag preset(ServerPlayer player) {
        CompoundTag data=MagicData.data(player);
        CompoundTag preset=normalized(data.getCompound("broomPreset"));
        if(!data.contains("broomPreset",10)) data.put("broomPreset",preset.copy());
        return preset;
    }
    public static void set(ServerPlayer p,String field,String value) {
        CompoundTag preset=preset(p);
        preset.putString(field,value);
        MagicData.data(p).put("broomPreset",preset);
        if(p.getVehicle() instanceof BroomEntity broom && broom.isOwner(p)) {
            CompoundTag mounted=preset.copy();
            if("magic".equals(mounted.getString("color")))mounted.putString("color",MagicData.magic(p));
            broom.configure(mounted);
        }
        MagicData.refreshBooks(p);
    }
    public static void reset(ServerPlayer p) {
        MagicData.data(p).put("broomPreset",defaults());
        if(p.getVehicle() instanceof BroomEntity broom && broom.isOwner(p)) {
            CompoundTag mounted=defaults();
            mounted.putString("color",MagicData.magic(p));
            broom.configure(mounted);
        }
        MagicData.refreshBooks(p);
    }
}
