# The Eclipse Grimoire — Changelog

## Alpha 0.9.0 — Enchanted Flight & Runecraft (source alpha)

### Added
- Craftable Enchanted Broom with placeable, rideable 3D entity and colorful trail.
- Adjustable flight controls, boost, mana cost, hover and gradual emergency descent.
- Broom Atelier chapter: 5 shapes, 7 woods, 5 bristle types, 6 wraps, 6 trails, 5 sigils, 6 accessories, 3 handling profiles, and 9 trail color selections (including follow-magic).
- Saved owner and appearance when collecting, placing and restarting worlds; editable name and Reset to Default.
- Eight selectable chalk patterns in eight magic colors (64 original rune textures).
- Rune selector integrated into grimoire; sneak-use chalk to cycle patterns.
- Bind Rune spell: level 3, 14 mana, single-use, up to 60 seconds of immobilization; respects coven and familiar exemptions.
- Dispel can release held players, including self, if the caster has learned Dispel.
- Broom item in the existing Creative tab and a survival crafting recipe.

### Compatibility and limitations
- Previous Alpha 0.8.0 blocks and spells are retained.
- Rune owner/armed state persists; temporary entity bindings are cleared on restart.
- Player binding is disabled when server PvP is off.
- This is an **uncompiled source alpha** pending a Forge build and in-game testing.
