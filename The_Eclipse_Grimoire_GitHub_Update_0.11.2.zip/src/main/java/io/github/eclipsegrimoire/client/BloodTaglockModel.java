package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.EclipseMod;
import io.github.eclipsegrimoire.TaglockItem;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
public final class BloodTaglockModel {
    private BloodTaglockModel(){}
    @SubscribeEvent public static void setup(FMLClientSetupEvent event){
        event.enqueueWork(()->ItemProperties.register(EclipseMod.TAGLOCK.get(),
            new ResourceLocation(EclipseMod.MOD_ID,"blood"),
            (stack,world,entity,seed)->TaglockItem.filled(stack)?1f:0f));
    }
}
