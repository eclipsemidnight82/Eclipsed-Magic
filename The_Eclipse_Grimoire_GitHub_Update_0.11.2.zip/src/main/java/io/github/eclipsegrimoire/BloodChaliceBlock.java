package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** One blood donor, one persistent immortality anchor; destroying/emptying ends protection. */
public final class BloodChaliceBlock extends Block {
    public static final BooleanProperty BLOOD=BooleanProperty.create("blood");
    private static final VoxelShape SHAPE=Block.box(3,0,3,13,14,13);
    public BloodChaliceBlock(BlockBehaviour.Properties props){super(props);registerDefaultState(stateDefinition.any().setValue(BLOOD,false));}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(BLOOD);}
    @Override public VoxelShape getShape(BlockState s,BlockGetter g,BlockPos p,CollisionContext c){return SHAPE;}
    @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){
        if(level.isClientSide())return InteractionResult.SUCCESS;
        if(!(player instanceof ServerPlayer witch))return InteractionResult.PASS;
        ServerLevel server=(ServerLevel)level;
        BloodRelicsData data=BloodRelicsData.get(server);
        ItemStack held=player.getItemInHand(hand);
        if(TaglockItem.filled(held)) {
            if(data.bindChalice(server,pos,held.getTag().getUUID("Target"),held.getTag().getString("Name"))) {
                server.setBlock(pos,state.setValue(BLOOD,true),3);
                witch.sendSystemMessage(Component.literal("[Eclipse] The chalice now guards "+held.getTag().getString("Name")+" from death while undisturbed."));
                TaglockItem.empty(held);
                server.playSound(null,pos,SoundEvents.BEACON_ACTIVATE,SoundSource.BLOCKS,1f,.65f);
            } else witch.sendSystemMessage(Component.literal("[Eclipse] This blood donor is already bound to another chalice. Break or empty that one first."));
            return InteractionResult.CONSUME;
        }
        BloodRelicsData.BloodBond bond=data.atChalice(server,pos);
        if(player.isShiftKeyDown()&&held.isEmpty()&&bond!=null){
            data.removeChalice(server,pos);
            server.setBlock(pos,state.setValue(BLOOD,false),3);
            witch.sendSystemMessage(Component.literal("[Eclipse] You emptied the chalice. "+bond.name()+" is mortal again."));
            server.playSound(null,pos,SoundEvents.GLASS_BREAK,SoundSource.BLOCKS,.6f,.8f);
        } else witch.sendSystemMessage(Component.literal(bond==null?
            "[Eclipse] An empty Bloodbound Chalice. Offer a filled blood taglock to bind a life.":
            "[Eclipse] Blood of "+bond.name()+". Protection active. Sneak-use with an empty hand to empty it."));
        return InteractionResult.CONSUME;
    }
    @Override public void onRemove(BlockState old,Level level,BlockPos pos,BlockState replacement,boolean moved) {
        if(!old.is(replacement.getBlock()) && level instanceof ServerLevel server)
            BloodRelicsData.get(server).removeChalice(server,pos);
        super.onRemove(old,level,pos,replacement,moved);
    }
}
