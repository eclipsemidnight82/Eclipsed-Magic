# The Eclipse Grimoire — Alpha 0.11.2

**Scrying Registry & Familiar Release** for Minecraft 1.20.1 / Forge 47.4.0.

This is the complete source update for the existing project. It is **not a compiled mod JAR**.

## Installation / GitHub build

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.11.2.zip` to the **repository root** (do not extract).
2. Replace the workflow at `.github/workflows/build.yml` with the provided `Eclipsed_Magic_Build_0_11_2.yml`.
3. Commit. Watch Actions and download the JAR from the `eclipse-grimoire-forge-1.20.1-alpha-0.11.2` artifact when the build succeeds.
4. Back up your world and previous working `.jar`, then test on a Forge 1.20.1 client/server with matching mod versions.

## Scrying registry

- Use the combined vial/needle taglock on a living player or mob.
- Right-click the placed Scrying Crystal with that filled vial; the donor is saved as one of up to **16 entries** on that crystal.
- Right-click with an empty hand to open the registry.
- Use **View** to begin true first-person observation of a *client-tracked* target.
- Use **Remove**, followed by **Confirm**, to forget an entry. This removes only the crystal's record, not the entity, and frees a slot. Repeat with a fresh vial to add them back.
- Online players can remain registered after death and respawn; deceased mobs are forgotten. A mob that is unloaded will read **NOT LOADED**, not automatically die.
- Target must be loaded and within the observing client's tracked rendering range for the first-person camera to attach; cross-dimension and truly distant world streaming are not implemented.
- For all scrying actions stand within 10 blocks of the crystal. Destroying a crystal removes its own registry.

## Cast away a familiar

- Open Grimoire → **Familiars** → select a bond → **Cast Away Selected Familiar** → **Confirm Cast Away**.
- The magical bond is removed, but the animal remains alive and still tamed. It can be re-bound later if desired.

See `CHANGELOG.md` for details.
