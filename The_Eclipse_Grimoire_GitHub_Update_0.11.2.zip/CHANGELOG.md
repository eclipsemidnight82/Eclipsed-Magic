# The Eclipse Grimoire — Alpha 0.11.2
## Scrying Registry & Familiar Release

### Scrying Crystal
- A crystal now stores **up to 16 individual bloodbound targets**, rather than replacing its previous bond when you offer another vial.
- Interact with the crystal with an empty hand to open a readable Scrying Registry containing the saved names and current availability states.
- Choose **View** for a loaded/online target; existing true first-person viewing is retained. Untracked distant entities may not be visible through the camera until they are client-loaded.
- Choose **Remove**, then **Confirm**, to deliberately forget a player or creature from *only that crystal's list*. The subject is unaffected; they can be added again with a new taglock vial.
- Deceased creatures are erased from registries when death is processed; unloaded creatures remain remembered until confirmed dead.
- Player records remain after death and reappear when the player respawns/logs back in.
- The list is saved in the world, scoped separately to each crystal by dimension and block location. Destroying a crystal clears its list.
- A new blood sample for an existing subject updates rather than duplicates the name.
- The registry does not force-load distant chunks.

### Familiars
- Added **Cast Away Selected Familiar** in the grimoire's Familiars section, requiring a second click to confirm.
- Casting away removes the saved magic bond and invalidates matching charms in the user's inventory, but **does not kill or untame** the animal.
- A server-side `/eclipse familiar castaway <uuid>` command handles the action.

### Technical
- Minecraft 1.20.1, Forge 47.4.0; mod version `0.11.2-alpha`.
- Bumped network protocol for registry and action messages; servers and clients must use matching JARs.
- Original grimoire, chalice, poppets, and ritual systems are retained.
- Full Forge compile and multiplayer gameplay must be validated in GitHub Actions and Minecraft.
