# The Eclipse Grimoire — Alpha 0.11.1: True Scrying

Minecraft 1.20.1 / Forge 47.4.0 / Java 17
Version `0.11.1-alpha` — focused update to user-tested Alpha 0.11.0.

## First-person Arcane Sight

- The Scrying Crystal no longer opens an overhead-map UI. It tries to show a **real live first-person Minecraft camera** attached to the target living entity.
- Use a blood taglock to bind the crystal as before. Right-click with an empty hand to enter the bound target's eyes.
- The caster's *actual* player entity stays at the crystal: no teleport and no gamemode switch. Controls are caught by the vision screen; the caster can't control the observed entity.
- A quiet overlay shows the subject and an **End Vision** button. **ESC** exits. The original camera mode is restored on exit.
- Automatic exit if target disappears, player dies, crystal is broken/emptied, or the target changes dimension.
- A carried Gris-Gris charm protects its holder from being watched by other players.
- The server revalidates the connection once per second.
- The viewer and target must be in **the same dimension**. The target must be *already tracked and present in the viewer's client's loaded world*. Other players and mobs outside client view distance **cannot** be viewed yet, even if the server knows their location. They receive a clear feedback message instead of a fake rendering.
- No new chunk loading, proxy spectator players, server gamemode changes, or teleportation are attempted. A fully remote camera across unloaded chunks would require a separate remote chunk-and-entity streaming system, not in this safety-focused update.

## Preserved

- All Alpha 0.11.0 Blood Taglock, Bloodbound Chalice, Poppet Reliquary, poppet crafting, scrying target binding, and protective poppet features.
- All ritual/hex/runecraft, spell wheel, coven/familiar, book theme, and UI organization features.
- Fixed the two previously reported Forge 1.20.1 custom recipe constructors **in source**, so a workflow-side workaround is no longer required.
- Updated Relics chapter text to describe real camera scrying.
- Network protocol bumped 6 → 7 (client and server must both use 0.11.1).

## GitHub build

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.11.1.zip` to the **repository root** (do not extract it).
2. Replace `.github/workflows/build.yml` in GitHub with `Eclipsed_Magic_Build_0_11_1.yml` (provided separately, and included inside the ZIP).
3. Commit, then in Actions download the JAR from the `eclipse-grimoire-forge-1.20.1-alpha-0.11.1` artifact.
4. Back up your world and your working Alpha 0.11.0 JAR. Install the new JAR in both client and multiplayer server environments.

## Gameplay testing

- Bind crystal to a player standing nearby. Use it; view should show **the target's real first-person world**, turning along with their head and following them walking around.
- Open/close with ESC repeatedly; ensure your own perspective and body position are preserved.
- Try scrying on a nearby living mob.
- Try a far-away or other-dimension target; clear blocked message, no broken fake map, no teleport.
- Move the target out of tracking range or disconnect them while watched; vision should close safely.
- Try breaking and emptying the crystal, and carrying a Gris-Gris charm.
- Confirm blood taglocks, poppets, chalice and all old rituals still work.

## Validation

Local source parsing, JSON assets, and archive integrity checked. The real Forge compilation and in-game camera behavior must be verified on GitHub Actions and then in a test world.
