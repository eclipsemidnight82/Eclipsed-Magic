# Alpha 0.11.1 — True Scrying

Changed:
- Replace 15x15 top-down scrying map with true first-person client camera attachment to a loaded/tracked target entity.
- Make scrying full-world view with subtle unobtrusive overlay, ESC/End Vision exit, and forced FIRST_PERSON camera during viewing.
- Restore original camera, close when target despawns/disconnects, and revalidate crystal connection every second.
- Keep observer's player body and gamemode unchanged; suppress observer hand rendering while looking through another entity.
- Shield players carrying the Gris-Gris charm from other players' scrying.
- Show a clear message when the target is outside the client-tracked world, offline, in another dimension, or shrouded.
- Update Relics grimoire page to teach actual first-person scrying.
- Fix two 0.11.0 custom recipe constructors to compile directly under Forge 1.20.1.
- Bump protocol 6 → 7 and version to 0.11.1-alpha.

Known limitation:
- Vanilla clients only render chunks/entities they already receive. No true view of untracked far-away players or cross-dimension targets in this release; separate remote streaming would be required.

Unchanged:
- All prior blood magic, immortality, rituals, hexes, covens, familiars, items, book designs and other systems.
