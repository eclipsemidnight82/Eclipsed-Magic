package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/** Validates each live camera request. Never moves the caster or changes their game mode.
 * Camera rendering happens only on the observing client for normally tracked entities.
 */
public final class ScryingMagic {
    private ScryingMagic() { }

    public static void view(ServerPlayer witch, BlockPos crystal) {
        ServerLevel level=witch.serverLevel();
        if(!level.hasChunkAt(crystal) ||
           witch.distanceToSqr(crystal.getX()+.5,crystal.getY()+.5,crystal.getZ()+.5)>100 ||
           !level.getBlockState(crystal).is(EclipseMod.SCRY_CRYSTAL_BLOCK.get())) {
            EclipseNetwork.scryTarget(witch,-1,null,"The crystal connection was broken.",crystal);
            return;
        }
        long now=level.getGameTime();
        if(witch.getPersistentData().getLong("EclipseNextScry")>now)return;
        witch.getPersistentData().putLong("EclipseNextScry",now+8);

        BloodRelicsData.CrystalBond bond=BloodRelicsData.get(level).crystal(level,crystal);
        if(bond==null){
            EclipseNetwork.scryTarget(witch,-1,null,"Offer the crystal a blood taglock first.",crystal);
            return;
        }
        LivingEntity target=null;
        ServerPlayer online=witch.server.getPlayerList().getPlayer(bond.subject());
        if(online!=null)target=online;
        else {
            ServerLevel remote=witch.server.getLevel(ResourceKey.create(Registries.DIMENSION,new ResourceLocation(bond.dimension())));
            if(remote!=null){
                Entity e=remote.getEntity(bond.subject());
                if(e instanceof LivingEntity living)target=living;
            }
        }
        if(target==null || !target.isAlive()){
            EclipseNetwork.scryTarget(witch,-1,null,"Target offline, dead, or not loaded.",crystal);
            return;
        }
        // The vanilla client cannot render chunks/entities from a different dimension.
        if(target.level()!=witch.level()){
            EclipseNetwork.scryTarget(witch,-1,null,"Cross-dimensional sight is not yet supported.",crystal);
            return;
        }
        // A carried protective charm shrouds this player's eyes from hostile scrying.
        if(target!=witch && target instanceof ServerPlayer protectedPlayer &&
           protectedPlayer.getInventory().items.stream().anyMatch(s->s.is(EclipseMod.GRIS_GRIS.get()))){
            EclipseNetwork.scryTarget(witch,-1,null,"Their protective charm obscures your vision.",crystal);
            return;
        }
        // The target must be tracked client-side: a real first-person view needs vanilla
        // chunks and entity rotation updates. We never fake remote terrain or load chunks.
        EclipseNetwork.scryTarget(witch,target.getId(),target.getUUID(),target.getName().getString(),crystal);
    }
}
