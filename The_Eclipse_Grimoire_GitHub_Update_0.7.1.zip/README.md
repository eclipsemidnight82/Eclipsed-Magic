# The Eclipse Grimoire — Alpha 0.7.1: Arcane Protection & Compact Wheel

**Minecraft 1.20.1 | Forge 47.4.0 | Java 17 | mod ID `eclipse_grimoire`**

**Status:** SOURCE PACKAGE / UNCOMPILED. Static resources and archive consistency were checked, but Forge compilation and actual gameplay still require GitHub Actions and a backup test world. Keep your known-working Alpha 0.7.0 `.jar` safe. Multiplayer clients and server must use the same version.

## What changed since Alpha 0.7.0

### Much smaller, screen-fitting spell wheel
- Default wheel radius reduced from 100 to **72 GUI pixels**.
- The wheel now displays up to **6 unlocked spells per page** (4 when the Minecraft GUI is small), not 15 labels at once. Keep scrolling to reach every available spell. The page follows your current selection.
- Automatically clamps its radius and label positions so smaller screens do not push spell buttons off-screen.
- The selection, mana and cost remain visible, with a page counter and release-key reminder. It stays a HUD overlay so WASD, mouse-look and jumping continue to work.
- Grimoire → Wheel → **Wheel Size** cycles Compact/Normal/Large. The Reset button now returns to the more compact default. Older large saved sizes are clamped to the new allowed bounds on load.

### Stronger Alzur's Thunder and Witchfire visuals
- Thunder sends **continuous, jagged, branching bolts** starting at approximated hand positions, with a bright white electrical core and magic-colored outer arc. Both caster and nearby multiplayer observers receive the effect.
- Witchfire now has a **visible 3D wall of shifting, tapering flame tongues**, tinted with your magic color, accompanied by particles/sounds and its existing knockback/arrow protection. It does not place real fire blocks or burn terrain; a vanilla burning mob may still show vanilla fire color.
- The client-side bolt/flame geometry is short-lived and bounded to avoid accumulating effects.

### Salted doors and sealed openings
- Right-click a **wood or iron door** with enchanted colored salt to place a color-matched **door ward**. Owners, coven allies and familiars may cross this *ordinary ward*; outsiders are blocked. Plain salt still works.
- Aim at an **already salted door** and cast `/eclipse cast seal` to upgrade it to an **absolute lockdown**. No entities—including the caster or their coven—can enter, and incoming projectiles are removed.
- Empty doorways: place infused salt along the floor of a **framed opening 1–3 blocks wide**, with sturdy side pillars and a solid lintel overhead; aim at the salt and cast Seal. This creates a visible two-block-tall magical veil across the opening. The salt must belong to you.
- To remove a seal, aim at it and cast `/eclipse cast shatter` (this dispels an empty doorway veil or a salted door's ward) or use **`/eclipse ward release`** while within 12 blocks of a seal you own (or as a server operator). Release is a safety escape and restores the door to its underlying normal ward, or removes the empty doorway veil while keeping the salt.
- For safety, entities already inside an absolute veil can walk OUT but cannot walk back IN; this prevents trapping a player with an unrecoverable barrier. Teleports and unusual movement may require additional gameplay hardening.
- Salt/door protection persists per dimension with the existing saved-data infrastructure. Normal door wards still exempt the owner/coven/familiars.

## Install & compile using your GitHub repository

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.7.1.zip` **without extracting it** to the root of `eclipsemidnight82/Eclipsed-Magic` (branch `main`).
2. Open `.github/workflows/build.yml` and replace the entire contents with `Eclipsed_Magic_Build_0_7_1.yml` (separate file beside the ZIP), then commit.
3. Confirm that the newly triggered Actions run says **Alpha 0.7.1** and succeeds at the *Compile Alpha 0.7.1 Forge mod* step. A green run from the ZIP-upload commit may still compile an older version, so check its workflow steps and artifact name.
4. Download the `eclipse-grimoire-forge-1.20.1-alpha-0.7.1` artifact, extract the JAR and test it in a backed-up Forge 1.20.1 profile. Only one version of the Eclipse Grimoire JAR should be in `mods`.

## Gameplay checks before replacing your stable JAR

- Open and close the spell wheel at Minecraft's smallest and largest GUI scales; make sure no labels clip. Scroll across page boundaries, cast from the wheel, rearrange spells, choose different wheel sizes, and press Reset in the grimoire.
- Test Alzur's Thunder from first- and third-person views, and from a second multiplayer player's view. Check whether the bolts emerge near both hands and remain legible.
- Test Witchfire near enemies and incoming skeleton arrows. Verify no nearby wood catches fire; coven members and tamed familiars should be protected.
- Right-click normal doors and double doors with colored salt, cast Seal, test entry with outsider, owner, coven ally, hostile mob, arrows, and dropped items. Check that you can undo the seal from either side using the command.
- Build a framed empty doorway with the right threshold and lintel, cast Seal, test it and then break its salt. Test world saves, reload, and chunk unload. Check old enchanted salt lines, coven invites, familiars, leveling and grimoire pages remain working.

**Known limitations:** The screen overlay is not a native radial-input GUI; mouse-look is preserved and scrolling selects spells. Thunder's hand positions are approximated; player arm bones do not physically animate. Magical flames are 3D rendered geometry and particles rather than real burnable Minecraft fire. Neither full Forge compilation nor gameplay testing has been performed for this package yet.

MIT licensed; no extra mod dependencies.
