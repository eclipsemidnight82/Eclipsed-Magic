# Changelog — Alpha 0.11.3 (Arcane Aesthetic)

## Added and improved
- **Actual translucency** for the new faceted Scrying Crystal models (client Forge `minecraft:translucent` model rendering).
- Scrying core now looks visibly different when empty/bound, with arcane particles while linked.
- Bloodbound Chalice reconstructed as a hollow sculptural golden cup; the `blood=true` variant visibly fills with deep-red blood, and the `blood=false` variant is empty.
- Empty and blood-filled Taglock item icons now switch properly using existing client item property + JSON override.
- Unbound / bloodbound / protective poppet item icons automatically switch using saved NBT; descriptive tooltips added.
- High-contrast new silhouettes and textures for Wardstone, Witch's Bell, Poppet Reliquary, pins, chalk, curse bottle, mana draught, gris-gris bag, and familiar charm.

## Unchanged
Scrying Registry, true scrying, death/respawn policies, Chalice immortality rules, poppet recipe semantics, covens, familiars, all rituals/hexes/salt wards, and Book of Shadows UI.

## Release warning
Visual changes have been validated in source but must still pass Forge GitHub compilation and in-game inspection before public publication.
