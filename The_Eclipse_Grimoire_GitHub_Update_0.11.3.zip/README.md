# The Eclipse Grimoire — Alpha 0.11.3: Arcane Aesthetic
Forge 1.20.1 / Forge 47.4.0 / Java 17

A visual-only release candidate based on the gameplay-tested Alpha 0.11.2.

## Visual changes
- Scrying Crystal: remodeled pedestal, prongs, translucent faceted gemstone and an interior core. Empty uses frosted blue/violet, bound uses translucent violet. The models specify `minecraft:translucent` for Forge 1.20.1. Bound crystals emit restrained ambient enchantment particles.
- Bloodbound Chalice: remodeled as a genuinely hollow golden goblet with handles and gilded rim. The `blood` blockstate exposes a bright recessed red liquid surface in the bowl; empty chalices have a dark cup interior. Bound chalices have faint crimson particles.
- Blood Taglock: two original hand-drawn 32px icons, empty/filled, driven by the existing `eclipse_grimoire:blood` item property. Blood donor data remains unchanged.
- Poppets: original unbound, bound, protective item art, selected from NBT via new `eclipse_grimoire:poppet_state` item property; item tooltips show donor and protective charge.
- Wardstone, Witch's Bell: ornate 3D geometry, improved gem, trim, wood and metal materials.
- Poppet Reliquary: cloth/wood texture improvements, existing occupied models retained.
- Witch's Chalk, mana draught, curse bottle, familiar charm, gris-gris bag and four ritual pins: refreshed original pixel-art icons.

## Compatibility
- No registry IDs removed or renamed.
- No spells, mana, covens, scrying registry, familiars, recipes, immersion protection or SavedData schemas changed.
- Old worlds remain compatible, but **always back up** before testing.
- Actual in-game visual appearance still needs verification (light settings, FOV, GUI scale and resource packs affect how models look).

## Build
Upload `The_Eclipse_Grimoire_GitHub_Update_0.11.3.zip` to the GitHub repository ROOT without extracting it; replace `.github/workflows/build.yml` with the accompanying Alpha 0.11.3 workflow. Commit the changes and download the artifact from Actions after the build succeeds.

Publish publicly only after build and game tests pass. Keep Alpha 0.11.2 as rollback.
