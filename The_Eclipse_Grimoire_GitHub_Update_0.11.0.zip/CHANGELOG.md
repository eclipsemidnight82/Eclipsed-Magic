# Alpha 0.11.0 — Bloodbound Relics

Added:
- Blood Taglock Vial with original empty/filled pixel art and a saved donor identity.
- Self-collection, entity interaction collection, and emptying/reusing the vial.
- Custom shaped taglock recipe and dynamic 2x2/3x3 blood + poppet crafting (transfers donor UUID, returns emptied vial).
- Existing 0.10.1 bound poppet compatibility, updated tooltip and binding instructions.
- One-use Golden-Apple-charged Protective Bloodbound Poppets.
- Placeable Poppet Reliquary, holding one bound doll with SavedData persistence.
- Bloodbound Chalice (3D block model, filled/empty blockstates, recipe, loot table).
- Cross-dimension overworld SavedData backing indefinite blood-donor revival (player or living creature), until the chalice is broken or emptied.
- Scrying Crystal (3D block model, bound/empty states, recipe, loot table).
- Real server-sampled 15×15 overhead scrying view of a loaded player/creature, updating every second; no spectator-mode or chunk forcing.
- New Relics chapter and third Poppetry page in the organized grimoire.
- New Creative tab entries and language strings.
- Network message protocol bumped to 6 for scrying packets.

Preserved:
- All Alpha 0.10.1 spells, rituals, hexes, chalk runes, wards, covens, familiars, spell wheel, layouts and book styles.

Still needs testing:
- Full GitHub Forge 47.4.0 build; item property registration and models; saved data through server restarts; death-handler mod interactions; multiplayer scrying.
