# The Eclipse Grimoire — Alpha 0.11.0: Bloodbound Relics

Minecraft 1.20.1 • Forge 47.4.0 • Java 17 • `mod_version=0.11.0-alpha`

Source built from the user-tested Alpha 0.10.1 Living Index release. Original artwork and implementations; no Bewitchment source or assets copied.

## New systems

### Blood Taglock Vial (replaces the visual of the original Taglock Thread)
- Craft a reusable bottle-and-needle item with a glass bottle, iron nugget and string.
- Right-click in the air to take your own blood. Right-click a living entity to take its blood. Taking blood from a player outside your coven requires server PvP enabled.
- Its *same inventory item* visually switches to a filled deep-red vial with a shimmering enchantment.
- Hovering shows the donor name; the UUID is saved in NBT for identity integrity. Sneak-use the vial in the air to empty it.

### Bloodbound and Protective Poppets
- Craft any **unbound Poppet + filled Blood Taglock Vial** in a 2x2 or 3x3 crafting grid to make a poppet bound to the blood donor.
- The filled blood is consumed but the empty Taglock Vial is returned to the crafting grid.
- Hover to view bound donor name; original 0.10.1 bound poppets remain usable.
- Craft **bound Poppet + Golden Apple** to charge a one-use protective ward (named "Protective Bloodbound Poppet"). A ward saves its donor from one lethal event when carried by that player or displayed on a Poppet Reliquary.
- **Poppet Reliquary:** place, right-click with a bound poppet to store it, sneak-use with empty hand to retrieve. Breaking the shelf drops its stored poppet. Shelf and ward persist across server restarts and unloaded chunks.
- Existing four ritual pins continue using bound poppets. Enemies must be loaded within 48 blocks in the recorded dimension, and old PvP/coven restrictions still apply.

### Bloodbound Chalice
- Craft with 5 Gold Ingots and 1 Amethyst Shard. Place as a distinct 3D goblet.
- Right-click with a **filled Taglock Vial** to pour the donor's blood into it; the vial becomes empty and the chalice visibly fills red.
- The recorded donor (player or living mob) survives repeated fatal damage indefinitely. The link persists across server restarts and while the chalice's chunk is unloaded. It can be broken or emptied: sneak-use with an empty hand.
- Only one living blood donor per chalice, and one active chalice per donor. The donor does not need to be the placer. Severe void falls send the rescued target to the current dimension's spawn.
- Test in a **backup world** before relying on permanent immortality. Some other mods with custom death handlers may interact differently.

### Scrying Crystal
- Craft with Glass, Amethyst Shard and Obsidian. Place as a magical crystal on a pedestal.
- Right-click with a filled Taglock Vial to bind the target; the vial is emptied. Right-click with empty hand to open a remote scrying display.
- **Real-time, server-verified overhead magical survey** of the subject's terrain with live coordinates, health, and markers for nearby living creatures. Auto-refreshes every second or use Refresh Vision; you must stay within ten blocks of the crystal. The target must be loaded (online players can be in other dimensions), and the system never forcibly loads distant chunks.
- This is an overhead scrying map, **not** a first-person video feed or a full cinematic camera. An unloaded or offline target yields "VISION OBSCURED".
- Sneak-use with empty hand to clear the link. Breaking the crystal removes the link.

### Grimoire
- Separate **RELICS** chapter for blood taglocks, scrying and the chalice; third POPPETRY page for protection and display shelves.
- Table of Contents now fits 11 subjects in two organized columns. All existing spells, rituals, runes, covens, familiars, wheels and saved customization remain.

## GitHub build
1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.11.0.zip` to the **repository root**, without extracting.
2. Replace `.github/workflows/build.yml` on your GitHub repository with the separate `Eclipsed_Magic_Build_0_11.yml` (also supplied inside the archive).
3. Commit; GitHub Actions applies the versioned update ZIP into `eclipse_grimoire_safe_build`, builds using the official Forge MDK wrapper and uploads the JAR as a workflow artifact.
4. **Back up your world and working 0.10.1 JAR.** Extract the workflow artifact, install only the `.jar`, and test on a copy of the world.

## First gameplay tests
- Two creative inventory items: Bloodbound Chalice and Scrying Crystal. Poppet Reliquary present.
- Empty vial ↔ blood-filled vial icon and tooltip; self and target interactions.
- Crafting Poppet + blood transfers donor identity; vial returns empty; pins still work.
- Bound poppet + Golden Apple makes one-charge protective poppet. Shelf persists across unload/reload.
- Chalice binding survives relog, reload and dimension travel. Multiple lethal hits revive donor; breaking/emptying the chalice ends protection.
- Crystal binds an online player or loaded creature; remote map displays real terrain and refreshes. Offline/unloaded creatures give a blocked vision.
- Grimoire Contents, Relics and Poppetry pages have no overlap at your normal GUI scale.

## Validation status
Source-level Java 17 syntax parsing, JSON resource validation, image checks, and ZIP integrity are completed locally. **A real Forge build and Minecraft runtime testing remain required through GitHub Actions and your test profile.**
