package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.EclipseNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** True server-sampled overhead vision of a bound target. Not a fake video or spectator mode. */
public final class ScryingScreen extends Screen {
    private String name="",dimension="";
    private int x,y,z;private float hp,maxHp;
    private int[] colors=new int[225],dots=new int[0];
    private BlockPos crystal=BlockPos.ZERO;
    private int refresh=0;
    public ScryingScreen(){super(Component.literal("The Scrying Crystal"));}
    public static void show(String name,String dimension,BlockPos crystal,int x,int y,int z,float hp,float maxHp,int[] colors,int[] dots){
        Minecraft mc=Minecraft.getInstance();
        ScryingScreen screen=mc.screen instanceof ScryingScreen s?s:new ScryingScreen();
        screen.name=name;screen.dimension=dimension;screen.crystal=crystal;screen.x=x;screen.y=y;screen.z=z;
        screen.hp=hp;screen.maxHp=maxHp;screen.colors=colors;screen.dots=dots;
        if(mc.screen!=screen)mc.setScreen(screen);
    }
    @Override protected void init(){
        addRenderableWidget(Button.builder(Component.literal("Refresh Vision"),b->EclipseNetwork.requestScry(crystal)).bounds(width/2-98,height/2+118,95,19).build());
        addRenderableWidget(Button.builder(Component.literal("Close"),b->onClose()).bounds(width/2+4,height/2+118,95,19).build());
    }
    @Override public void tick(){if(++refresh%20==0)EclipseNetwork.requestScry(crystal);}
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial){
        renderBackground(g);
        int ox=width/2-163,oy=height/2-138;
        g.fill(ox-5,oy-5,ox+330,oy+269,0xe1070613);
        g.fill(ox,oy,ox+325,oy+265,0xff181022);
        g.fill(ox+4,oy+4,ox+321,oy+6,0xff9463d4);
        g.drawCenteredString(font,"THE SCRYING CRYSTAL",width/2,oy+11,0xffddb9fa);
        g.drawCenteredString(font,name,width/2,oy+27,0xffefdfef);
        if(dimension.startsWith("VISION OBSCURED")) {
            g.drawCenteredString(font,dimension,width/2,oy+117,0xffe7a6d4);
        } else {
            int tile=12,startX=ox+72,startY=oy+49;
            for(int dz=0;dz<15;dz++)for(int dx=0;dx<15;dx++){
                int index=dz*15+dx;
                int color=index<colors.length?colors[index]:0xff151020;
                g.fill(startX+dx*tile,startY+dz*tile,startX+dx*tile+tile-1,startY+dz*tile+tile-1,color);
            }
            for(int index:dots){if(index>=0&&index<225){int dx=index%15,dz=index/15;
                g.fill(startX+dx*tile+4,startY+dz*tile+4,startX+dx*tile+9,startY+dz*tile+9,0xffe8ad50);
            }}
            g.fill(startX+7*tile+2,startY+7*tile+2,startX+7*tile+tile-2,startY+7*tile+tile-2,0xffdb53f1);
            g.drawCenteredString(font,"LIVE ARCANE OVERHEAD VISION",width/2,oy+234,0xffbdb0cb);
            g.drawCenteredString(font,"X:"+x+"  Y:"+y+"  Z:"+z+"   HP:"+(int)Math.ceil(hp)+"/"+(int)Math.ceil(maxHp),width/2,oy+248,0xffe5c6ed);
        }
        super.render(g,mouseX,mouseY,partial);
    }
    @Override public boolean isPauseScreen(){return false;}
}
