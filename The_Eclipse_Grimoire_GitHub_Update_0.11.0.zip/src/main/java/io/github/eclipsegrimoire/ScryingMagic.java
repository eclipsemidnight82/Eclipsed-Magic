package io.github.eclipsegrimoire;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

/** Remote, genuine live overhead map. Samples ONLY already loaded terrain; no forced chunks. */
public final class ScryingMagic {
    private ScryingMagic() { }
    public static void view(ServerPlayer witch,BlockPos crystal){
        ServerLevel level=witch.serverLevel();
        if(witch.distanceToSqr(crystal.getX()+.5,crystal.getY()+.5,crystal.getZ()+.5)>100 ||
            !level.getBlockState(crystal).is(EclipseMod.SCRY_CRYSTAL_BLOCK.get()))return;
        long now=level.getGameTime();
        if(witch.getPersistentData().getLong("EclipseNextScry")>now)return;
        witch.getPersistentData().putLong("EclipseNextScry",now+8);
        BloodRelicsData.CrystalBond bond=BloodRelicsData.get(level).crystal(level,crystal);
        if(bond==null){witch.sendSystemMessage(Component.literal("[Eclipse] The crystal is blank. Offer it blood to bind a target."));return;}
        LivingEntity target=null;
        ServerPlayer online=witch.server.getPlayerList().getPlayer(bond.subject());
        if(online!=null)target=online;
        else {
            ServerLevel last=witch.server.getLevel(ResourceKey.create(Registries.DIMENSION,new ResourceLocation(bond.dimension())));
            if(last!=null){Entity entity=last.getEntity(bond.subject());if(entity instanceof LivingEntity living)target=living;}
        }
        if(target==null||!target.isAlive()){
            EclipseNetwork.scryVision(witch,bond.name(),"VISION OBSCURED - target is offline or unloaded",crystal,0,0,0,0f,0f,new int[225],new int[0]);
            return;
        }
        ServerLevel remote=(ServerLevel)target.level();
        BlockPos mid=target.blockPosition();int[] colors=new int[225];
        for(int dz=-7;dz<=7;dz++)for(int dx=-7;dx<=7;dx++){
            int px=mid.getX()+dx,pz=mid.getZ()+dz,index=(dz+7)*15+(dx+7);
            BlockPos probe=new BlockPos(px,mid.getY(),pz);
            if(!remote.hasChunkAt(probe)){colors[index]=0xff10101a;continue;}
            int height=remote.getHeight(Heightmap.Types.WORLD_SURFACE,px,pz)-1;
            BlockPos surface=new BlockPos(px,height,pz);
            int rgb=remote.getBlockState(surface).getMapColor(remote,surface).col;
            colors[index]=0xff000000|(rgb&0x00ffffff);
        }
        List<Integer> dots=new ArrayList<>();
        final LivingEntity centerTarget=target;
        for(LivingEntity nearby:remote.getEntitiesOfClass(LivingEntity.class,new AABB(mid).inflate(7,5,7),
            living->living!=centerTarget&&living.isAlive())){
            int dx=nearby.blockPosition().getX()-mid.getX(),dz=nearby.blockPosition().getZ()-mid.getZ();
            if(Math.abs(dx)<=7&&Math.abs(dz)<=7)dots.add((dz+7)*15+(dx+7));
            if(dots.size()==24)break;
        }
        EclipseNetwork.scryVision(witch,target.getName().getString(),remote.dimension().location().toString(),crystal,
            mid.getX(),mid.getY(),mid.getZ(),target.getHealth(),target.getMaxHealth(),colors,
            dots.stream().mapToInt(Integer::intValue).toArray());
    }
}
