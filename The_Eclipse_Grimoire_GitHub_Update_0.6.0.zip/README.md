# The Eclipse Grimoire — Alpha 0.6.0 Source

Minecraft **1.20.1 · Forge 47.4.0 · Java 17** · same mod ID (`eclipse_grimoire`) and saved magic/coven data as 0.5.0.

**Status: source package and resource validation only. Not yet compiled or play-tested.** Keep your working, tested **0.5.0 JAR** backed up. Compile the 0.6.0 ZIP via the supplied GitHub Actions workflow, then try it in a backed-up world before replacing your main mod.

## New spells (no cooldowns)

| Spell | Level | Cost | Behavior |
|---|---:|---:|---|
| Telekinetic Pulse (`/eclipse cast pulse`) | 2 | 14 mana | A circular force wave pushes nearby mobs, items and other entities outward. The caster, coven and bonded familiars/tamed pets are protected. PvP-off server players are protected, too. |
| Blink (`/eclipse cast blink`) | 4 | 18 mana | Teleport toward the first point you're looking at, within 20 blocks, to a safe collision-free spot on solid ground. No mana spent if no safe place is found. Doesn't blindly teleport through walls. |
| Witchfire (`/eclipse cast witchfire`) | 6 | 30 mana | A magic-colored ring burns and repels nearby outsiders for 30 seconds; destroys nearby incoming arrows. Another cast turns it off for free. Never places fire blocks or spreads fire to the terrain. |

**Visuals:** Each successful regular spell now draws a brief colored two-ring magical sigil with radial rune marks. Pulse draws a larger wave; Witchfire has persistent colored rings and a rune circle while active; Blink marks the departure/arrival points. Your selected **magic color**, not the book color, controls these effects. Vanilla on-fire flames on burning mobs remain vanilla-colored; the magical ring itself matches your color.

The existing Salt, Tether, mana/XP, leveling, cauldron, lectern, coven and familiar mechanics are preserved.

## New grimoire style

The book now dyes **the whole visible cover, both parchment pages, panels, spine, buttons, and borders**, not just the header ribbon. Existing eight book colors remain under **Settings → Book**. Your spell color can stay separate from the book color.

There is now a **Wheel** tab where players can:
- browse their complete spell list, reorder spells, and show/hide individual wheel entries;
- adjust wheel **size**, **transparency**, and **color** (independent from magic color or following it);
- **RESET WHEEL TO DEFAULT** to restore the complete original spell order, visibility, opacity, size, and magic-following tint.

Settings persist on each client at `config/eclipse_grimoire_wheel.properties`, surviving restarts; they are cosmetic/preferences, not server-side progression. The key is still customizable in Minecraft **Controls → Key Binds → The Eclipse Grimoire** (default **G**). Hold G, scroll through unlocked and visible spells, release G to cast; movement and mouse look remain active. A second ring is used for larger spell collections to reduce overlapping labels. The server still validates all spell levels and mana.

## GitHub workflow: how to build

1. Upload **`The_Eclipse_Grimoire_GitHub_Update_0.6.0.zip`** directly to the **root of `eclipsemidnight82/Eclipsed-Magic`** on `main`. Keep it zipped; do NOT extract in GitHub.
2. Open `.github/workflows/build.yml` and replace its text with the separate **`Eclipsed_Magic_Build_0_6.yml`** file's contents; commit.
3. In GitHub Actions, watch the latest run. The workflow unzips 0.6.0 on top of the existing Forge project, checks new source files, compiles, then uploads the resulting JAR as an Actions artifact if successful.
4. Only when the build is green, download the **Alpha 0.6.0 artifact** and extract its JAR. Back up and remove 0.5.0 in a separate Forge 1.20.1 test profile, install 0.6.0, and verify first. All participating multiplayer clients and the server need the matching version.

## Suggested in-game test

- Use `/eclipse level` to check XP; OP may use `/eclipse level addxp 1000` to test new high-level spells and `/eclipse mana refill`.
- Try Pulse next to a cow, a zombie, a dropped item, your own tamed wolf and a coven member. Only non-allies should get pushed; test PvP-off as well.
- Try Blink at a safe flat spot, a wall, across a gap, at a ceiling, and toward a dangerous ledge. The spell should fail safely if there's no landing spot. Verify it costs no mana on failure.
- Try Witchfire while skeletons shoot arrows; test neutral creatures, allied pets, and coven players. Cast again to dismiss and check that no blocks catch fire.
- Change **Book** to blue, red or emerald in Settings. Open the grimoire again and verify both pages, borders, panels and buttons are all tinted. Confirm the magic color can remain different.
- In the Wheel tab hide Pulse, move Blink earlier, change size and alpha, quit and relaunch to check persistence, then click Reset Wheel to Default. Make sure no locked spells appear and G still permits movement.
- Recheck 0.5.0 staples: colored salt/barriers, lectern opening, coven controls, Arcane Tether, and spell mana/XP.

## Known boundaries

- The spell circles are **particle effects**, not placed rune blocks or permanent decals.
- Witchfire stops vanilla **arrows**, not every modded projectile or potion. It won't protect against melee from enemies outside the ring, teleportation or other damage types.
- Pulse does not force movement of immovable/boss entities that have custom physics, and it respects PvP-disabled servers.
- The wheel controls are stored **per installation**, not synchronized between PCs or servers. Other players cannot edit your local wheel via the server.
- Full Forge compilation, client/server startup and multiplayer compatibility remain to be verified in GitHub Actions and actual Minecraft.

MIT license for source. No external UI dependencies. Keep the previous JAR until tested.
