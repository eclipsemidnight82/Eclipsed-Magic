package io.github.eclipsegrimoire;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Server-origin visual sigils: no client installation assumptions or block modifications. */
public final class ArcaneEffects {
    private ArcaneEffects() {}

    public static int rgb(String color) {
        return switch (color) {
            case "crimson" -> 0xe34e69;
            case "blue" -> 0x54a6ef;
            case "emerald" -> 0x43bd94;
            case "gold" -> 0xe6b74e;
            case "white" -> 0xe7dfe9;
            case "shadow" -> 0x91829f;
            case "rose" -> 0xed91cb;
            default -> 0xa46af5;
        };
    }
    public static DustParticleOptions dust(String color, float size) {
        int rgb=rgb(color);
        return new DustParticleOptions(new Vector3f(((rgb>>16)&255)/255f,
            ((rgb>>8)&255)/255f,(rgb&255)/255f),size);
    }
    public static void point(ServerLevel level,String color,Vec3 at) {
        level.sendParticles(dust(color,1.2f),at.x,at.y,at.z,1,0,0,0,0);
    }
    public static void ring(ServerLevel level,String color,Vec3 center,double radius,int points) {
        for(int i=0;i<points;i++) {
            double a=Math.PI*2*i/points;
            point(level,color,center.add(Math.cos(a)*radius,0,Math.sin(a)*radius));
        }
    }
    /** Interlocking inner/outer circles, radial arms and small runic marks. */
    public static void sigil(ServerLevel level,String color,Vec3 center,double radius) {
        ring(level,color,center,radius,48);
        ring(level,color,center,radius*.65,32);
        for(int i=0;i<8;i++) {
            double a=2*Math.PI*i/8;
            for(int j=0;j<4;j++) {
                double r=radius*(.65+j*.10);
                point(level,color,center.add(Math.cos(a)*r,0,Math.sin(a)*r));
            }
            double x=Math.cos(a)*radius*1.09,z=Math.sin(a)*radius*1.09;
            point(level,color,center.add(x,.17,z));
            point(level,color,center.add(x,.33,z));
        }
    }
    public static void castingCircle(ServerPlayer caster) {
        ServerLevel level=caster.serverLevel();
        sigil(level,MagicData.magic(caster),caster.position().add(0,.10,0),1.65);
    }
}
