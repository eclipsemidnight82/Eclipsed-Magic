package io.github.eclipsegrimoire.client;

import java.util.ArrayList;
import java.util.List;
import io.github.eclipsegrimoire.EclipseMod;
import io.github.eclipsegrimoire.EclipseNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * A HUD overlay, NOT a Screen: players retain movement, attack, jumping and mouse look.
 * Hold configurable key (G by default), scroll to select, release to cast; opening a menu cancels.
 */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.MOD,value=Dist.CLIENT)
public final class SpellWheel {
    private SpellWheel() { }
    private static final KeyMapping OPEN=new KeyMapping("key.eclipse_grimoire.spell_wheel",
        GLFW.GLFW_KEY_G,"key.categories.eclipse_grimoire");
    private record Entry(String id,String label,int requiredLevel,int cost) { }
    private static final List<Entry> ALL=List.of(
        new Entry("ward","Ward",1,8), new Entry("power","Power",1,10),
        new Entry("mend","Mend",1,12), new Entry("veil","Veil",2,15),
        new Entry("bind","Bind",2,15), new Entry("circle","Salt Circle",3,20),
        new Entry("seal","Seal Salt",3,12), new Entry("infuse","Infuse Salt",3,8),
        new Entry("shatter","Shatter",4,22), new Entry("thunder","Thunder",4,30),
        new Entry("aegis","Final Aegis",6,40)
    );
    private static boolean active=false;
    private static int selected=0,level=1,mana=100,maxMana=100;
    private static String magicColor="purple";
    private static Level knownLevel=null;

    @SubscribeEvent public static void keys(RegisterKeyMappingsEvent event) {event.register(OPEN);}
    @SubscribeEvent public static void overlay(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("spell_wheel",(gui,graphics,partial,width,height)->render(graphics,width,height));
    }
    public static void receive(int playerLevel,int currentMana,int capacity,String color) {
        level=Math.max(1,Math.min(20,playerLevel));
        mana=Math.max(0,currentMana);
        maxMana=Math.max(100,capacity);
        magicColor=color;
        int size=unlocked().size();
        if(size>0) selected=Math.floorMod(selected,size);
    }
    private static List<Entry> unlocked() {
        List<Entry> found=new ArrayList<>();
        for(Entry entry:ALL) if(level>=entry.requiredLevel) found.add(entry);
        return found;
    }
    private static int accent() {
        return switch(magicColor) {
            case "crimson" -> 0xe34e69; case "blue" -> 0x54a6ef;
            case "emerald" -> 0x43bd94; case "gold" -> 0xe6b74e;
            case "white" -> 0xe7dfe9; case "shadow" -> 0x9a90ab;
            case "rose" -> 0xed91cb; default -> 0xa46af5;
        };
    }
    private static boolean usable(Minecraft mc) {
        return mc.player!=null && mc.level!=null && mc.screen==null && !mc.isPaused();
    }
    @Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE,value=Dist.CLIENT)
    public static final class Events {
        private Events() { }
        @SubscribeEvent public static void tick(TickEvent.ClientTickEvent event) {
            if(event.phase!=TickEvent.Phase.END) return;
            Minecraft mc=Minecraft.getInstance();
            if(mc.level!=knownLevel) {
                knownLevel=mc.level;
                active=false;
                level=1;mana=100;maxMana=100;magicColor="purple";
            }
            boolean down=usable(mc) && OPEN.isDown();
            if(down && !active) {
                active=true;
                selected=0;
                EclipseNetwork.requestWheel();
            } else if(!down && active) {
                active=false;
                // A menu, chat, or disconnection cancels casting instead of accidentally firing a spell.
                if(usable(mc) && mc.player.connection!=null) {
                    List<Entry> choices=unlocked();
                    if(!choices.isEmpty())
                        mc.player.connection.sendCommand("eclipse cast "+choices.get(Math.floorMod(selected,choices.size())).id);
                }
            }
        }
        @SubscribeEvent public static void scroll(InputEvent.MouseScrollingEvent event) {
            if(!active) return;
            List<Entry> choices=unlocked();
            if(choices.isEmpty()) return;
            double delta=event.getScrollDelta();
            if(delta!=0) selected=Math.floorMod(selected+(delta>0?-1:1),choices.size());
            event.setCanceled(true); // scroll selects the spell, not the hotbar slot
        }
    }
    private static void render(GuiGraphics graphics,int width,int height) {
        Minecraft mc=Minecraft.getInstance();
        if(!active || !usable(mc)) return;
        List<Entry> choices=unlocked();
        if(choices.isEmpty()) return;
        int cx=width/2,cy=height/2,highlight=accent();
        selected=Math.floorMod(selected,choices.size());
        // Semi-transparent ring and compact buttons: world and crosshair remain visible.
        for(int a=0;a<72;a++) {
            double rad=a*Math.PI/36.0;
            int x=cx+(int)(Math.cos(rad)*103),y=cy+(int)(Math.sin(rad)*103);
            graphics.fill(x-1,y-1,x+2,y+2,0x774e3568);
        }
        for(int i=0;i<choices.size();i++) {
            Entry entry=choices.get(i);
            double theta=(Math.PI*2.0*i/choices.size())-Math.PI/2.0;
            int x=cx+(int)Math.round(Math.cos(theta)*99);
            int y=cy+(int)Math.round(Math.sin(theta)*99);
            boolean chosen=i==selected;
            int w=Math.max(65,mc.font.width(entry.label)+12),h=19;
            int left=x-w/2,top=y-h/2;
            graphics.fill(left,top,left+w,top+h,chosen?0xC8241839:0x79301640);
            if(chosen) {
                int border=0xFF000000|highlight;
                graphics.fill(left,top,left+w,top+2,border);
                graphics.fill(left,top,left+2,top+h,border);
                graphics.fill(left+w-2,top,left+w,top+h,border);
                graphics.fill(left,top+h-2,left+w,top+h,border);
            }
            graphics.drawCenteredString(mc.font,entry.label,x,top+5,chosen?0xFFFFFFFF:0xFFE5D9EA);
        }
        Entry chosen=choices.get(selected);
        graphics.fill(cx-49,cy-20,cx+49,cy+26,0xB5120E19);
        graphics.drawCenteredString(mc.font,chosen.label,cx,cy-12,0xFFF4E4FE);
        graphics.drawCenteredString(mc.font,"Mana "+mana+"/"+maxMana,cx,cy+1,0xFFDFCAEE);
        graphics.drawCenteredString(mc.font,"Cost "+chosen.cost,cx,cy+13,mana>=chosen.cost?0xFFDEBDFB:0xFFFF8888);
        graphics.drawCenteredString(mc.font,"Level "+level+"  |  Hold "+OPEN.getTranslatedKeyMessage().getString(),cx,cy+135,0xFFE2CDEB);
        graphics.drawCenteredString(mc.font,"Scroll: choose     Release: cast",cx,cy+147,0xFFE2CDEB);
    }
}
