package io.github.eclipsegrimoire;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Server-authoritative book and low-bandwidth HUD sync; server validates every spell cast. */
public final class EclipseNetwork {
    private EclipseNetwork() { }
    private static final String VERSION="2";
    private static final SimpleChannel CHANNEL=NetworkRegistry.newSimpleChannel(
        new ResourceLocation(EclipseMod.MOD_ID,"main"),()->VERSION,VERSION::equals,VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0,OpenGrimoire.class,OpenGrimoire::encode,OpenGrimoire::decode,OpenGrimoire::handle);
        CHANNEL.registerMessage(1,WheelRequest.class,WheelRequest::encode,WheelRequest::decode,WheelRequest::handle);
        CHANNEL.registerMessage(2,WheelState.class,WheelState::encode,WheelState::decode,WheelState::handle);
    }
    public static void open(ServerPlayer player,ItemStack original) {
        ItemStack shown=original.copy();
        MagicData.stamp(shown,player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new OpenGrimoire(shown));
    }
    /** Called only when a player presses their wheel key, not every tick. */
    public static void requestWheel() {CHANNEL.sendToServer(new WheelRequest());}

    private record OpenGrimoire(ItemStack book) {
        static void encode(OpenGrimoire msg,FriendlyByteBuf buf) {buf.writeItem(msg.book);}
        static OpenGrimoire decode(FriendlyByteBuf buf) {return new OpenGrimoire(buf.readItem());}
        static void handle(OpenGrimoire msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ClientBook.open(msg.book)));
            ctx.setPacketHandled(true);
        }
    }
    private record WheelRequest() {
        static void encode(WheelRequest msg,FriendlyByteBuf buf) { }
        static WheelRequest decode(FriendlyByteBuf buf) {return new WheelRequest();}
        static void handle(WheelRequest msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->{
                ServerPlayer player=ctx.getSender();
                if(player==null) return;
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new WheelState(MagicData.level(player),MagicData.mana(player),MagicData.maxMana(player),MagicData.magic(player)));
            });
            ctx.setPacketHandled(true);
        }
    }
    private record WheelState(int level,int mana,int maxMana,String magicColor) {
        static void encode(WheelState msg,FriendlyByteBuf buf) {
            buf.writeVarInt(msg.level);buf.writeVarInt(msg.mana);buf.writeVarInt(msg.maxMana);buf.writeUtf(msg.magicColor,32);
        }
        static WheelState decode(FriendlyByteBuf buf) {
            return new WheelState(buf.readVarInt(),buf.readVarInt(),buf.readVarInt(),buf.readUtf(32));
        }
        static void handle(WheelState msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.SpellWheel.receive(msg.level,msg.mana,msg.maxMana,msg.magicColor)));
            ctx.setPacketHandled(true);
        }
    }
}
