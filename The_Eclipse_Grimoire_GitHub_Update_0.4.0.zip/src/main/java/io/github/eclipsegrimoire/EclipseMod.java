package io.github.eclipsegrimoire;

import java.util.Map;
import java.util.LinkedHashMap;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(EclipseMod.MOD_ID)
public final class EclipseMod {
    public static final String MOD_ID = "eclipse_grimoire";
    public static final TagKey<EntityType<?>> EXTRA_UNDEAD = TagKey.create(Registries.ENTITY_TYPE, new ResourceLocation(MOD_ID, "undead"));
    private static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    private static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final RegistryObject<Block> SALT_LINE = BLOCKS.register("salt_line", () -> new SaltLineBlock(BlockBehaviour.Properties.copy(Blocks.REDSTONE_WIRE).noOcclusion()));
    public static final RegistryObject<Item> SALT = ITEMS.register("salt", () -> new BlockItem(SALT_LINE.get(), new Item.Properties()));
    /** Eight actual colored blocks keep multiplayer appearance and placed wards server-authoritative. */
    public static final Map<String,RegistryObject<Block>> COLORED_SALT_BLOCKS=new LinkedHashMap<>();
    public static final Map<String,RegistryObject<Item>> COLORED_SALT_ITEMS=new LinkedHashMap<>();
    static {
        for(String color:MagicData.COLORS) {
            RegistryObject<Block> block=BLOCKS.register("infused_salt_"+color+"_line",
                ()->new SaltLineBlock(BlockBehaviour.Properties.copy(Blocks.REDSTONE_WIRE).noOcclusion()));
            COLORED_SALT_BLOCKS.put(color,block);
            COLORED_SALT_ITEMS.put(color,ITEMS.register("infused_salt_"+color,
                ()->new BlockItem(block.get(),new Item.Properties())));
        }
    }
    public static boolean isSalt(net.minecraft.world.level.block.state.BlockState state) {
        return state.getBlock() instanceof SaltLineBlock;
    }
    public static boolean isColoredSalt(net.minecraft.world.level.block.state.BlockState state) {
        for(RegistryObject<Block> block:COLORED_SALT_BLOCKS.values()) if(state.is(block.get())) return true;
        return false;
    }
    public static RegistryObject<Item> infusedSaltItem(String color) {
        return COLORED_SALT_ITEMS.getOrDefault(color,COLORED_SALT_ITEMS.get("purple"));
    }
    public static final RegistryObject<Item> GRIMOIRE = ITEMS.register("grimoire", () -> new Item(new Item.Properties().stacksTo(1)));

    public EclipseMod() {
        EclipseNetwork.register();
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::creativeTab);
    }
    private void creativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(SALT.get());
            for(RegistryObject<Item> enchanted:COLORED_SALT_ITEMS.values()) event.accept(enchanted.get());
            event.accept(GRIMOIRE.get());
        }
    }
}
