# The Eclipse Grimoire — Forge 1.20.1 — Alpha 0.4.0

**Uncompiled source update, not a playable JAR.** GitHub Actions must compile it; then test the resulting JAR in a **backup/test world**. The previous Alpha 0.3.0 was confirmed working by the user; Alpha 0.4.0 has not yet been compiled or play-tested.

## New: pre-enchanted colored salt

- Ordinary salt is still white, redstone-like powder and repels undead mobs.
- Hold one or more regular salt items in **your MAIN hand** and cast `/eclipse cast infuse` (magic level 3; costs 8 mana).
- The entire held stack becomes **enchanted salt matching your currently selected magic color**, including purple, crimson, blue, emerald, gold, white, shadow, or rose.
- Place infused salt on the ground. Each placed tile immediately records *the placer* as its owner and forms a five-block-high ward against other living creatures. No second spell cast needed.
- The owner, members of their current coven, and their tamed/bonded pets can pass. Outsiders cannot walk through normally.
- Colored and white salt connect visually. Up to 512 connected tiles can still be enchanted with `/eclipse cast seal` (magic level 3), including mixed lines.
- `/eclipse cast shatter` (level 4) targets a connected salt line, removes the ward from all connected tiles, turns any colored salt back to white, and opens a one-tile gap. This is intentional so a colorful nonworking ward does not mislead players.
- Removing a tile, running water/lava, or breaking its support removes that tile's ward; like previous alphas, salt is not washed away by rain.
- Projectiles, teleportation, other mods' special movement and some flying behavior are **not guaranteed blocked**; this is a ground-level living-entity ward, not an absolute force field.

## New: non-blocking spell wheel

- Default key: **hold G**. Remap under Options > Controls > Key Binds > The Eclipse Grimoire.
- **Scroll mouse wheel** while holding G to select a spell; **release G to cast**. This also prevents accidental scroll-hotbar changes while the wheel is open.
- A translucent radial HUD overlay is drawn over gameplay, **not a Screen**, leaving mouse-look, movement, combat, jumping, and other normal controls active.
- Only spells unlocked at your server-authoritative magic level appear; level and mana are requested from the server on opening the wheel. The first very quick press on a freshly joined world may show level-one choices before the reply arrives.
- Opening chat, inventory, another menu or disconnecting cancels the wheel without casting.
- No spell cooldowns; mana and spell-level requirements remain enforced by the server.

## Spell unlocks

- Level 1: Ward (8), Power (10), Mend (12)
- Level 2: Veil (15), Bind (15)
- Level 3: Salt Circle (20), Seal Salt (12), Infuse Salt (8)
- Level 4: Shatter (22), Thunder (30)
- Level 6: Final Aegis (40)

## Existing features retained

- Customizable grimoire, lectern reading, level/XP and max mana scaling, Coven tab controls, bonded familiars, magical colors, salt door wards, cauldron rituals.
- Server-authoritative spell validation and friendly-fire protection for coven members and bonded pets.

## Upload to GitHub and build

1. Upload `The_Eclipse_Grimoire_GitHub_Update_0.4.0.zip` (the ZIP file itself) to the **root** of `eclipsemidnight82/Eclipsed-Magic` on branch `main`. Do **not** unzip it in GitHub. This method matches your last successful 0.3.0 build.
2. Edit `.github/workflows/build.yml` in the GitHub web editor. Replace its entire contents with `Eclipsed_Magic_Build_0_4.yml`, then commit.
3. In Actions, check the resulting build. Download the **0.4.0** artifact only if it has a green checkmark.
4. Extract the artifact ZIP, install the **compiled mod JAR** in your Forge 1.20.1 CurseForge profile, **removing the prior version from the mods folder** (keep its JAR backed up).
5. Test in a clean, backed-up world and verify all listed behavior before publishing on CurseForge. Multiplayer players and server need the same 0.4.0 version.

## Troubleshooting checklist

- Spell wheel does not appear: verify Key Binds, the 0.4.0 JAR, and that you are in-game without a menu open.
- Infuse does nothing: be level 3+, hold regular white salt in main hand, have 8 mana (unless creative), cast from the book or `/eclipse cast infuse`.
- New salt remains white: make sure you're placing `infused_salt_<color>`, not regular `salt`.
- Wards fail to stop intruders: test with an ordinary living mob on level ground first; teleportation/projectiles are not warded.
- Build fails: send the first `error:` line from the GitHub job's Compile step. The source was validated for file structure and JSON but not compiled in this environment.

Minecraft 1.20.1 • Forge 47.4.0 • Java 17 • MIT source license.
