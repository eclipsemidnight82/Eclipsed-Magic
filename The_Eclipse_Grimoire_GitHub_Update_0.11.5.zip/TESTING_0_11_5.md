# Alpha 0.11.5 — Taglock Final Visual Test

1. Back up the working Alpha 0.11.4 JAR and world; install only the Alpha 0.11.5 JAR.
2. In a creative inventory, find `Taglock Vial` (ID `eclipse_grimoire:taglock`). Empty vial must use the **new** glass bottle + needle, not the old cylindrical icon.
3. Collect blood using the vial. The bottle outline, glass, stopper and needle must not change; only the interior becomes red and an enchanted glint may appear.
4. Sneak-right-click in air to empty it; the bottle returns to the exact same empty design without changing shape.
5. Verify target name tooltip, infusing a poppet and binding a chalice all work.
6. Confirm the Witch's Bell, crystal, and all previous visuals remain unchanged.

This update changes resource models and the version only; no Java gameplay classes were modified.
