# Alpha 0.11.5 — Taglock Model Consistency Hotfix

## Fixed
- Corrected the actual registered `eclipse_grimoire:taglock` item model to use the matching new empty vial artwork, not the obsolete cylinder texture.
- Changed the blood predicate to select the blood-filled model **directly** from the registered item model; removed nested overrides from the intermediate model.
- Updated the legacy `taglock.png` texture to the current empty vial artwork to avoid future accidental mismatch.
- Both states share exactly the same bottle, needle, silhouette, and dimensions; the interior blood pixels are the only intended visual difference.

## Preserved
- The same item ID, blood target data, tooltip, blood collection, crafting recipes, chalice, scrying, familiar bonds and all other Alpha 0.11.4 features.

## Validation
- JSON checks, direct item model resolution tests, texture alpha silhouette tests, ZIP integrity and workflow validation. Full Forge build and in-game appearance still require GitHub Actions / CurseForge testing.
