package io.github.eclipsegrimoire;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.saveddata.SavedData;

/** Persists each charged salt tile's caster and each salted door's owner per dimension. */
public final class WardData extends SavedData {
    private final Map<Long,UUID> chargedSalt=new HashMap<>();
    private final Map<Long,UUID> saltedDoors=new HashMap<>();
    public static final int MAX_NETWORK=512;

    public static WardData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(WardData::load,WardData::new,"eclipse_salt_wards");
    }
    private static WardData load(CompoundTag tag) {
        WardData data=new WardData();
        // Old 0.2 circle_salt had no caster information: leave physical salt intact,
        // but clear legacy enchantments rather than permanently trapping their caster.
        for(Tag e:tag.getList("charged",Tag.TAG_COMPOUND)) {
            CompoundTag t=(CompoundTag)e;
            if(t.hasUUID("owner")) data.chargedSalt.put(t.getLong("pos"),t.getUUID("owner"));
        }
        for(Tag e:tag.getList("doors",Tag.TAG_COMPOUND)) {
            CompoundTag t=(CompoundTag)e;
            if(t.hasUUID("owner")) data.saltedDoors.put(t.getLong("pos"),t.getUUID("owner"));
        }
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.put("charged",encode(chargedSalt));
        tag.put("doors",encode(saltedDoors));
        return tag;
    }
    private static ListTag encode(Map<Long,UUID> source) {
        ListTag all=new ListTag();
        source.forEach((pos,owner)->{CompoundTag t=new CompoundTag();t.putLong("pos",pos);t.putUUID("owner",owner);all.add(t);});
        return all;
    }
    /** Collect one continuous horizontal, surface-level line, regardless of its shape. */
    public static Set<BlockPos> connectedSalt(ServerLevel level,BlockPos start) {
        if(!level.hasChunkAt(start) || !level.getBlockState(start).is(EclipseMod.SALT_LINE.get())) return Set.of();
        Set<BlockPos> found=new HashSet<>();
        ArrayDeque<BlockPos> queue=new ArrayDeque<>();queue.add(start);
        while(!queue.isEmpty()) {
            BlockPos p=queue.removeFirst();
            if(found.contains(p)) continue;
            if(!level.hasChunkAt(p) || !level.getBlockState(p).is(EclipseMod.SALT_LINE.get())) continue;
            found.add(p);
            if(found.size()>MAX_NETWORK) return Set.of(); // refuse partial protection
            for(Direction d:Direction.Plane.HORIZONTAL) queue.addLast(p.relative(d));
        }
        return found;
    }
    public int enchantNetwork(Set<BlockPos> network,UUID caster) {
        if(network.isEmpty() || network.size()>MAX_NETWORK) return 0;
        for(BlockPos p:network) chargedSalt.put(p.asLong(),caster);
        setDirty();return network.size();
    }
    public int shatterNetwork(Set<BlockPos> network) {
        int removed=0;
        for(BlockPos p:network) if(chargedSalt.remove(p.asLong())!=null) removed++;
        if(removed>0) setDirty();return removed;
    }
    public int enchantCircle(Set<BlockPos> positions,UUID caster) {return enchantNetwork(positions,caster);}
    public UUID chargedOwner(ServerLevel level,BlockPos p) {
        UUID owner=chargedSalt.get(p.asLong());
        if(owner==null) return null;
        if(level.getBlockState(p).is(EclipseMod.SALT_LINE.get())) return owner;
        chargedSalt.remove(p.asLong());setDirty();return null;
    }
    public static BlockPos doorBase(ServerLevel level,BlockPos pos) {
        BlockState state=level.getBlockState(pos);
        if(!(state.getBlock() instanceof DoorBlock)) return null;
        return state.getValue(DoorBlock.HALF)==DoubleBlockHalf.UPPER?pos.below():pos;
    }
    public UUID doorOwner(ServerLevel level,BlockPos pos) {
        BlockPos base=doorBase(level,pos);
        return base==null?null:saltedDoors.get(base.asLong());
    }
    public boolean saltDoor(ServerLevel level,BlockPos pos,UUID owner) {
        BlockPos base=doorBase(level,pos);
        if(base==null || saltedDoors.containsKey(base.asLong())) return false;
        saltedDoors.put(base.asLong(),owner);setDirty();return true;
    }
    public boolean clearDoor(ServerLevel level,BlockPos pos,UUID player,boolean operator) {
        BlockPos base=doorBase(level,pos);
        if(base==null) return false;
        UUID owner=saltedDoors.get(base.asLong());
        if(owner==null || (!operator && !owner.equals(player))) return false;
        saltedDoors.remove(base.asLong());setDirty();return true;
    }
    public void broken(ServerLevel level,BlockPos pos) {
        if(chargedSalt.remove(pos.asLong())!=null) setDirty();
        BlockPos base=doorBase(level,pos);
        if(base!=null && saltedDoors.remove(base.asLong())!=null) setDirty();
    }
    public static boolean canCross(ServerLevel level,UUID caster,LivingEntity actor) {
        if(caster==null) return true;
        if(caster.equals(actor.getUUID())) return true;
        CovenData covens=CovenData.get(level);
        if(covens.same(caster,actor.getUUID())) return true;
        if(actor instanceof TamableAnimal pet && pet.isTame() && pet.getOwnerUUID()!=null) {
            UUID petOwner=pet.getOwnerUUID();
            if(caster.equals(petOwner) || covens.same(caster,petOwner)) return true;
        }
        if(actor.getPersistentData().hasUUID("EclipseFamiliarOwner")) {
            UUID familiarOwner=actor.getPersistentData().getUUID("EclipseFamiliarOwner");
            return caster.equals(familiarOwner) || covens.same(caster,familiarOwner);
        }
        return false;
    }
}
