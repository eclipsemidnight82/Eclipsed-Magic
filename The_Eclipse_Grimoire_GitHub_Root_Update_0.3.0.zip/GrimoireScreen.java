package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.MagicData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;

/** Functional spell list, progression, coven administration and settings. */
public final class GrimoireScreen extends Screen {
    private enum Page {SPELLS,COVEN,FAMILIARS,SETTINGS}
    private Page page=Page.SPELLS;
    private final String name,startingCoven,invitation;
    private final int level,xp,xpNext,mana,maxMana;
    private String magicColor,uiColor;
    private EditBox nameInput,covenInput,playerInput;
    private static final String[] COLORS={"purple","crimson","blue","emerald","gold","white","shadow","rose"};

    public GrimoireScreen(ItemStack book) {
        super(Component.literal("The Eclipse Grimoire"));
        CompoundTag tag=book.getTag();
        name=tag!=null&&tag.contains("eclipseName")?tag.getString("eclipseName"):MagicData.DEFAULT_BOOK;
        magicColor=tag!=null&&tag.contains("eclipseMagic")?tag.getString("eclipseMagic"):"purple";
        uiColor=tag!=null&&tag.contains("eclipseUI")?tag.getString("eclipseUI"):"shadow";
        level=tag!=null&&tag.contains("eclipseLevel")?tag.getInt("eclipseLevel"):1;
        xp=tag!=null?tag.getInt("eclipseXp"):0;
        xpNext=tag!=null&&tag.contains("eclipseXpNext")?tag.getInt("eclipseXpNext"):35;
        mana=tag!=null&&tag.contains("eclipseMana")?tag.getInt("eclipseMana"):100;
        maxMana=tag!=null&&tag.contains("eclipseMaxMana")?tag.getInt("eclipseMaxMana"):100;
        startingCoven=tag!=null?tag.getString("eclipseCoven"):"";
        invitation=tag!=null?tag.getString("eclipseInvite"):"";
    }
    private int accent() {return 0xff000000|switch(uiColor) {
        case "purple"->0xa46af5;case "crimson"->0xe34e69;case "blue"->0x54a6ef;
        case "emerald"->0x43bd94;case "gold"->0xe6b74e;case "white"->0xe7dfe9;
        case "rose"->0xed91cb;default->0x5b526b;
    };}
    @Override protected void init() {
        int x=width/2-169,y=height/2-123;
        String[] tabs={"Spells","Coven","Familiars","Settings"};
        Page[] pages=Page.values();
        for(int i=0;i<4;i++) {
            final Page target=pages[i];
            addRenderableWidget(Button.builder(Component.literal(tabs[i]),b->switchPage(target))
                .bounds(x+12+i*79,y+29,75,20).build());
        }
        switch(page) {
            case SPELLS -> {
                spellButton("Ward 8","ward",x+13,y+79);
                spellButton("Power 10","power",x+175,y+79);
                spellButton("Mend 12","mend",x+13,y+102);
                spellButton("Veil 15","veil",x+175,y+102);
                spellButton("Bind 15","bind",x+13,y+125);
                spellButton("Salt Circle 20","circle",x+175,y+125);
                spellButton("Seal Salt 12","seal",x+13,y+148);
                spellButton("Shatter Ward 22","shatter",x+175,y+148);
                spellButton("Thunder 30","thunder",x+13,y+171);
                spellButton("Final Aegis 40","aegis",x+175,y+171);
            }
            case COVEN -> {
                covenInput=new EditBox(font,x+13,y+91,196,20,Component.literal("Coven name"));
                covenInput.setMaxLength(24);covenInput.setHint(Component.literal("Name your coven"));
                addRenderableWidget(covenInput);
                addRenderableWidget(Button.builder(Component.literal("Create"),b->{
                    String v=covenInput.getValue().trim();
                    if(v.matches("[a-zA-Z0-9_ -]{2,24}")){command("eclipse coven create "+v);close();}
                }).bounds(x+216,y+91,104,20).build());
                playerInput=new EditBox(font,x+13,y+120,196,20,Component.literal("Player username"));
                playerInput.setMaxLength(16);playerInput.setHint(Component.literal("Online player username"));
                addRenderableWidget(playerInput);
                addRenderableWidget(Button.builder(Component.literal("Invite"),b->{
                    String v=playerInput.getValue().trim();
                    if(v.matches("[a-zA-Z0-9_]{3,16}")){command("eclipse coven invite "+v);close();}
                }).bounds(x+216,y+120,104,20).build());
                addRenderableWidget(Button.builder(Component.literal("Join Invite"),b->{command("eclipse coven join");close();}).bounds(x+13,y+154,98,20).build());
                addRenderableWidget(Button.builder(Component.literal("Leave Coven"),b->{command("eclipse coven leave");close();}).bounds(x+118,y+154,99,20).build());
                addRenderableWidget(Button.builder(Component.literal("Info"),b->{command("eclipse coven info");close();}).bounds(x+224,y+154,96,20).build());
            }
            case FAMILIARS -> addRenderableWidget(Button.builder(Component.literal("Bond My Tamed Pet"),b->{
                command("eclipse familiar bond");close();
            }).bounds(x+70,y+122,198,22).build());
            case SETTINGS -> {
                nameInput=new EditBox(font,x+15,y+92,308,20,Component.literal("Grimoire name"));
                nameInput.setMaxLength(32);nameInput.setValue(name);addRenderableWidget(nameInput);
                addRenderableWidget(Button.builder(Component.literal("Save Book Name"),b->{
                    command("eclipse rename "+nameInput.getValue());close();
                }).bounds(x+15,y+118,308,20).build());
                addRenderableWidget(Button.builder(Component.literal("Magic: "+magicColor),b->{
                    magicColor=nextColor(magicColor);command("eclipse color magic "+magicColor);switchPage(Page.SETTINGS);
                }).bounds(x+15,y+154,147,21).build());
                addRenderableWidget(Button.builder(Component.literal("Book: "+uiColor),b->{
                    uiColor=nextColor(uiColor);command("eclipse color book "+uiColor);switchPage(Page.SETTINGS);
                }).bounds(x+176,y+154,147,21).build());
            }
        }
        addRenderableWidget(Button.builder(Component.literal("Close"),b->close()).bounds(x+128,y+219,82,20).build());
    }
    private void spellButton(String text,String spell,int x,int y) {
        int needed=MagicData.requiredLevel(spell);
        String label=(level>=needed?text:text+" (Lv "+needed+")");
        Button b=Button.builder(Component.literal(label),button->{command("eclipse cast "+spell);close();})
            .bounds(x,y,151,21).build();
        b.active=level>=needed;
        addRenderableWidget(b);
    }
    private String nextColor(String current) {
        for(int i=0;i<COLORS.length;i++) if(COLORS[i].equals(current))return COLORS[(i+1)%COLORS.length];
        return COLORS[0];
    }
    private void command(String value) {
        if(Minecraft.getInstance().player!=null && Minecraft.getInstance().player.connection!=null)
            Minecraft.getInstance().player.connection.sendCommand(value);
    }
    private void close() {Minecraft.getInstance().setScreen(null);}
    private void switchPage(Page newPage) {page=newPage;clearWidgets();init();}
    private void text(GuiGraphics g,String line,int x,int y) {g.drawString(font,line,x,y,0xffe4d6ee);}
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g);
        int x=width/2-169,y=height/2-123;
        g.fill(x,y,x+338,y+249,0xff120f18);
        g.fill(x+5,y+5,x+333,y+244,0xff241b2c);
        g.fill(x+5,y+5,x+333,y+7,accent());
        g.drawCenteredString(font,name,width/2,y+13,0xfff0e0fa);
        g.drawCenteredString(font,"Level "+level+"   XP "+xp+"/"+(xpNext==0?"MAX":xpNext)+"   Mana "+mana+"/"+maxMana,
            width/2,y+57,0xffd9bef5);
        super.render(g,mouseX,mouseY,partial);
        switch(page) {
            case SPELLS -> text(g,"No cooldowns  •  Cast spells to earn XP",x+43,y+201);
            case COVEN -> {
                text(g,"Coven: "+(startingCoven.isEmpty()?"None":startingCoven),x+15,y+77);
                text(g,"Pending invitation: "+(invitation.isEmpty()?"None":invitation),x+15,y+188);
                text(g,"Invite an online player by username",x+15,y+204);
            }
            case FAMILIARS -> {
                text(g,"Tame a pet, then look directly at it.",x+42,y+87);
                text(g,"Bonding keeps it safe from your magic.",x+30,y+162);
            }
            case SETTINGS -> text(g,"Customize your book and spell colors",x+38,y+195);
        }
    }
    @Override public boolean isPauseScreen() {return false;}
}
