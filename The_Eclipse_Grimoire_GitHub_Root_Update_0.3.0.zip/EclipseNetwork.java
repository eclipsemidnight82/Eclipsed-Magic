package io.github.eclipsegrimoire;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** A server-authoritative open-book packet fixes reading a grimoire placed on a lectern. */
public final class EclipseNetwork {
    private EclipseNetwork() { }
    private static final String VERSION="1";
    private static final SimpleChannel CHANNEL=NetworkRegistry.newSimpleChannel(
        new ResourceLocation(EclipseMod.MOD_ID,"main"),()->VERSION,VERSION::equals,VERSION::equals);
    public static void register() {
        CHANNEL.registerMessage(0,OpenGrimoire.class,OpenGrimoire::encode,OpenGrimoire::decode,OpenGrimoire::handle);
    }
    public static void open(ServerPlayer player,ItemStack original) {
        ItemStack shown=original.copy();
        MagicData.stamp(shown,player); // show the reader's live level, mana and coven
        CHANNEL.send(PacketDistributor.PLAYER.with(player),new OpenGrimoire(shown));
    }
    private record OpenGrimoire(ItemStack book) {
        static void encode(OpenGrimoire msg,FriendlyByteBuf buf) {buf.writeItem(msg.book);}
        static OpenGrimoire decode(FriendlyByteBuf buf) {return new OpenGrimoire(buf.readItem());}
        static void handle(OpenGrimoire msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ClientBook.open(msg.book)));
            ctx.setPacketHandled(true);
        }
    }
}
