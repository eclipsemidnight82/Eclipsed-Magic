# The Eclipse Grimoire — Forge 1.20.1 — Alpha 0.3.0 source

## STATUS

**Uncompiled, untested source update.** Do not install this ZIP as a mod. Run the GitHub Actions build, extract the compiled `.jar`, and test it in a BACKUP world before updating CurseForge. Keep the working 0.2.0 jar until this version is verified. The 0.3 code adds a Forge server-to-client packet for reliable lectern reading, and must be tested on both integrated and dedicated server.

## New in Alpha 0.3

- **Lectern fix:** place a grimoire on a vanilla lectern; right-click it to open a custom UI using a server-to-client packet. Sneak-right-click to take it back.
- **No cooldowns:** every spell uses mana only. Costs have been reduced to 8–40 mana.
- **Progression:** Level 1–20. Successful casts grant 4 XP, or 6 XP for salt magic. XP required for the next level is `20 + 15*level`; max mana grows by +20 per level, from 100 to 480. Mana regenerates +4 per second, and level-ups increase current mana by the same amount as the new capacity. Existing magic players start at Level 1.
- **Spell unlocks:** Level 1: Ward, Power, Mend. Level 2: Veil, Bind. Level 3: Salt Circle, Seal Salt. Level 4: Thunder, Shatter. Level 6: Final Aegis.
- **Coven page:** text fields and working Create / Invite / Join / Leave / Info buttons, instead of instructions to type commands. Coven information and pending invitation display when you reopen the book.
- **Wards:** cast `circle` for a 7x7 enchanted salt circle; the caster, coven members, and their pets may cross, but outsiders cannot (up to five blocks above the line). Cast `seal` while looking at ANY connected physical salt line (up to 512 tiles, horizontal N/E/S/W) to enchant it. Cast `shatter` while looking at ANY physical salt line to remove all linked magic and break a single salt tile, opening a gap. Plain salt still stops undead. Salted doors also exempt the owner/coven.
- **Preservation:** Old coven memberships, magic colors, book names and physical salt remain. 0.2 magic circles had no owner stored; their enchanted protection is deliberately reset for safety. Recast `seal` on any existing lines that you want protected.
- **Existing cauldron rituals** remain: water cauldron + amethyst shard (healing); glowstone dust (mana+night vision); blaze powder (fire resistance).

## Commands

| Command | Use | Level |
| --- | --- | --- |
| `/eclipse book` | Give grimoire | 1 |
| `/eclipse level` | Read XP, level, mana | 1 |
| `/eclipse mana` | Read mana | 1 |
| `/eclipse cast ward` | Protection, 8 mana | 1 |
| `/eclipse cast power` | Strength/speed, 10 mana | 1 |
| `/eclipse cast mend` | Heal allies, 12 mana | 1 |
| `/eclipse cast veil` | Invisibility, 15 mana | 2 |
| `/eclipse cast bind` | Disable monsters, 15 mana | 2 |
| `/eclipse cast circle` | Draw 7x7 enchanted ring, 20 mana | 3 |
| `/eclipse cast seal` | Enchant connected salt you're looking at, 12 mana | 3 |
| `/eclipse cast shatter` | Break targeted salt tile and ward, 22 mana | 4 |
| `/eclipse cast thunder` | Lightning attack, 30 mana | 4 |
| `/eclipse cast aegis` | Final Aegis, 40 mana | 6 |
| `/eclipse mana refill` | Refill to new maximum (OP only) | — |
| `/eclipse salt 64` | Give salt (OP only) | — |

Coven commands used by GUI: `/eclipse coven create <name>`, `invite <player>`, `join`, `leave`, `info`. Familiar button uses `/eclipse familiar bond`.

## Installation / GitHub build from a root-file upload

1. Extract `The_Eclipse_Grimoire_GitHub_Root_Update_0.3.0.zip` and upload **all the Java files plus `build.gradle` and `gradle.properties`** to the ROOT of `eclipsemidnight82/Eclipsed-Magic` on GitHub. The existing repository structure intentionally stores the alpha update files at root for its workflow to copy into `eclipse_grimoire_safe_build` when building.
2. Edit `.github/workflows/build.yml` on GitHub: replace its contents with `Eclipsed_Magic_Build_0_3.yml`. Commit.
3. In GitHub Actions, run `Build The Eclipse Grimoire (Forge 1.20.1)` if there isn't an automatic push build. The new workflow verifies that all expected 0.3 code is present before building.
4. If green, download the `eclipse-grimoire-forge-1.20.1-alpha-0.3.0` artifact ZIP, extract the **normal mod `.jar`** (not sources), replace the older jar in a separate test profile. Test on Forge 1.20.1 with Java 17.

Or use this ZIP's full source project folder for your own builds. GitHub Actions uses Forge's official Gradle wrapper and JDK 17.

## Test priorities

1. Place/read/reclaim grimoire from lectern (empty hand to read; sneak-right-click to reclaim). Repeat on a multiplayer dedicated server.
2. Use `/eclipse level` and cast `ward` several times (no cooldown); verify leveling and mana capacity. Confirm higher-level spells start greyed out then unlock.
3. Use the Coven UI to create a coven and invite a second online player. Confirm they accept from the UI and can pass through your circle.
4. Create a flat 7x7 area; cast `circle` at Level 3. Verify caster can walk across; outsider mobs cannot; another coven player can.
5. Place irregular connected salt line; target it and cast `seal`. Confirm blocking and restart persistence. Cast `shatter` on any segment; confirm one piece breaks and the enchantment falls.
6. Re-test salted doors, cauldrons, spell effects, death/relogin, and ordinary undead salt resistance.

## Known limits

- Not tested in Minecraft or compiled locally for this update. GitHub Actions and game testing may reveal errors.
- Barriers stop server-side living entity movement by position rollback, not projectiles or teleportation. Vertical height is five blocks. Modded movement, flying, jumping, and cross-dimensional cases need game tests.
- `seal` follows same-level, N/E/S/W touching salt blocks up to 512 tiles. It does NOT detect closed loops, diagonal connections, or underground vertical lines automatically. You can cast it on an open line or a complete circle.
- `shatter` can break another witch's line and deliberately destroys one piece of physical salt, so do not allow untrusted players to use it on builds you want protected.
- Leveling by successful casts is intentionally simple; later builds can rebalance XP rewards to reduce repetitive casting.
- All clients and the server must run the SAME build.
