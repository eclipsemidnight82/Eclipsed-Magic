# The Eclipse Grimoire — Changelog

## Alpha 0.8.0 — Witchcraft & Curiosities (source candidate)
- Added an independent **The Eclipse Grimoire** Creative Mode inventory tab for 30 mod items.
- Added eight magic-colored placeable Witch Candles and eight Witchfire Braziers with functional light and particles.
- Added durable **Witch's Chalk**, drawing flat color-matched floor runes.
- Added craftable **Bottled Mana** (+50 mana, glass bottle returned).
- Added owner-saved **Wardstones**, which repel hostile mobs without affecting the caster's coven or pets.
- Added owner-saved **Witch's Bells**, which warn the caster and coven about nearby outsiders.
- Added **Familiar Charms**, allowing safe binding, locating, and same-dimension loaded pet recall without duplicating or retaming pets.
- Added the level 1 **Witchlight** utility spell and level 5 **Dispel** spell, integrated into the grimoire and spell wheel.
- Added survival crafting recipes and models for all new items and blocks.
- Retained the preexisting 0.7.2 grimoire, spells, progression, wards and covens.

**Status:** static package checks only. Forge compilation and Minecraft gameplay testing remain required.
