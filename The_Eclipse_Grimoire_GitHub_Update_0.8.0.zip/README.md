# The Eclipse Grimoire — Alpha 0.8.0

**Minecraft 1.20.1 · Forge 47.4.0 · Java 17**

This is an **uncompiled source update** based directly on the gameplay-tested Alpha 0.7.2 source. The GitHub workflow must finish successfully before its JAR can be used. **Back up your working 0.7.2 JAR and your worlds** before testing. Keep only one Eclipse Grimoire JAR in `mods` at a time.

## New in 0.8.0

### Creative Inventory tab
The Eclipse Grimoire now has its own Creative-mode inventory tab, displaying all 30 items: the grimoire, plain salt, eight enchanted salt colors, Witch's Chalk, eight colored enchanted candles, eight colored Witchfire Braziers, a Wardstone, Witch's Bell, Familiar Charm, and Bottled Mana. The tab's icon is the grimoire.

### Real items and blocks
- **Enchanted Witch Candles:** eight craftable, colored light-emitting decorations, each with subtle enchanted and fire particles.
- **Witch's Chalk:** a durable item (128 uses) that draws your selected magic color's rune on the top of a sturdy block. The rune is a decorative flat block, not a ward by itself.
- **Witchfire Braziers:** eight craftable, permanently luminous and particle-emitting decorative braziers; no wildfire or block damage.
- **Bottled Mana:** craftable, instant +50 mana up to your max; consumed in Survival and returns a glass bottle. Cannot be wasted when mana is full.
- **Wardstone:** placeable magical crystal. Saved owner automatically on player placement; gently pushes away hostile mobs within six blocks. Owner and coven creatures aren't repelled. No terrain damage. Right-click to see ownership.
- **Familiar Charm:** right-click **your own tamed animal** to bind (sneak-use on another one to rebind). Right-click in air to check its status, sneak-right-click in air to safely recall a loaded pet in the **same dimension, within 128 blocks**. Unloaded, dead, or unowned pets cannot be teleported. This never changes pet ownership.
- **Witch's Bell:** placeable, owner-bound bell; rings when outsiders (hostile mobs or non-coven players) come within seven blocks, at most once per five seconds. Alerts owner and nearby/online coven members in the same dimension. Right-click to ring manually.

Wardstone and bell ownership is saved per world dimension. Removing the block removes the saved ownership. Older salt wards are not modified.

### New spells
- **Witchlight** (`/eclipse cast witchlight`): level 1, 12 mana, two-minute following orb of your magic color and Night Vision for practical cave visibility. Recast to dismiss. The orb is particles and doesn't place temporary light blocks or physically illuminate surrounding surfaces.
- **Dispel** (`/eclipse cast dispel`): level 5, 18 mana. Aim at a Wardstone or Witch's Bell within 12 blocks to temporarily suppress its powers for 15 seconds without removing ownership. Or aim at an **unobstructed player** within 12 blocks to interrupt Eclipse Witchfire, Witchlight, and their active Arcane Tether. PvP-off servers prevent hostile player dispels. Permanent door/salt/absolute ward ownership is never deleted; use the existing owner controls or Shatter Ward for those.

Both spells are added to the grimoire chapters and customizable spell wheel. No cooldowns added.

### Crafting
New survival recipes are in `data/eclipse_grimoire/recipes/` for all eight candles and braziers, chalk, bottled mana, Wardstone, Familiar Charm, and Witch's Bell. Check the in-game Recipe Book or a crafting recipe viewer such as JEI; ordinary Minecraft crafting works.

## How to build on GitHub
1. Upload **`The_Eclipse_Grimoire_GitHub_Update_0.8.0.zip`** to the **root** of `eclipsemidnight82/Eclipsed-Magic` (keep ZIP compressed).
2. Replace `.github/workflows/build.yml` with the separately provided **`Eclipsed_Magic_Build_0_8.yml`** contents.
3. Commit the changes. The workflow unzips the new source into `eclipse_grimoire_safe_build`, checks the actual version and required files, then builds Forge Java 17 and uploads `eclipse-grimoire-forge-1.20.1-alpha-0.8.0` on success.
4. Download the **artifact ZIP** from the successful workflow, extract its mod JAR, and install it in a separate CurseForge test profile. Back up 0.7.2 and use a copy of your world first.

## Practical testing checklist
- [ ] Mod starts in Minecraft Forge 1.20.1; old save loads in a backup.
- [ ] Creative inventory has the **The Eclipse Grimoire** tab and every new item; no missing purple/black textures.
- [ ] Crafting recipes for all eight candle and brazier colors work in Survival.
- [ ] Candles/braziers emit light and particles but don't burn down structures.
- [ ] Chalk draws a flat magic-color rune without replacing an existing block.
- [ ] Bottled Mana restores no more than 50 mana and returns a bottle.
- [ ] Wardstone owner remains after world reload; it repels enemies but leaves coven/familiars alone.
- [ ] Witch's Bell alerts the owner/coven on intruders without spam.
- [ ] Familiar Charm binds only *owned* tamed pets and recalls only loaded pets safely; no duplicated animals.
- [ ] Witchlight orb follows the caster and gives Night Vision; can be toggled off.
- [ ] Dispel temporarily disables Wardstones/Bells and disrupts Witchfire/Tether without wiping permanent wards.
- [ ] Older spell wheel, salt wards, Absolute Seal, book UI, covens and familiar roster still work.
- [ ] Multiplayer: a second player without the mod cannot join a Forge modded server; all clients should install matching 0.8.0.

## Known boundaries
Chalk runes are decorative markings, **not** ritual triggers. Braziers are decorative flame sources, not cauldron recipe stations. Familiar recall requires a loaded pet; this update deliberately does **not** load faraway chunks or spawn a replacement. Witchlight's visibility boost is Night Vision, not a moving block light. Wardstone protection applies to hostile mobs nearby, not every projectile or type of creature. Full gameplay correctness has not been verified until the GitHub build and Minecraft testing pass.
