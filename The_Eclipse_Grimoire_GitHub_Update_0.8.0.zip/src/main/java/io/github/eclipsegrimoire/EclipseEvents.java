package io.github.eclipsegrimoire;

import java.util.Map;
import java.util.WeakHashMap;
import java.util.UUID;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class EclipseEvents {
    private EclipseEvents() { }
    private static final Map<LivingEntity,Vec3> PREVIOUS=new WeakHashMap<>();
    // Weak keys ensure entities leaving a chunk or dimension never persist in memory.
    private static final Map<Entity,Vec3> ABSOLUTE_PREVIOUS=new WeakHashMap<>();
    public static void rememberTeleport(LivingEntity entity,Vec3 destination) { PREVIOUS.put(entity,destination); }

    @SubscribeEvent public static void playerTick(TickEvent.PlayerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        TetherMagic.tick(player);
        MotionMagic.tick(player);
        WitchcraftSpells.tick(player);
        if(player.tickCount%20==0 && MagicData.mana(player)<MagicData.maxMana(player))
            MagicData.mana(player,MagicData.mana(player)+4);
        if(player.tickCount%100==0) MagicData.refreshBooks(player);
    }
    @SubscribeEvent public static void playerLeaves(PlayerEvent.PlayerLoggedOutEvent event) {
        if(event.getEntity() instanceof ServerPlayer player) { TetherMagic.release(player, ""); MotionMagic.stop(player); WitchcraftSpells.stopLight(player); }
    }
    @SubscribeEvent public static void playerChangesDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if(event.getEntity() instanceof ServerPlayer player) { TetherMagic.release(player, ""); MotionMagic.stop(player); WitchcraftSpells.stopLight(player); }
    }
    @SubscribeEvent public static void clonePlayer(PlayerEvent.Clone event) {
        CompoundTag prior=event.getOriginal().getPersistentData();
        if(prior.contains(MagicData.KEY,10))
            {
                CompoundTag cloned=prior.getCompound(MagicData.KEY).copy();
                cloned.remove("witchfireUntil");cloned.remove("witchfireDimension");
                cloned.remove("witchlightUntil");cloned.remove("witchlightDimension");
                event.getEntity().getPersistentData().put(MagicData.KEY,cloned);
            }
    }
    /** Final safeguard: cancel an arrow impact even if it crosses the aura between ticks. */
    @SubscribeEvent public static void witchfireArrow(ProjectileImpactEvent event) {
        if(!(event.getProjectile() instanceof AbstractArrow arrow)) return;
        if(!(event.getRayTraceResult() instanceof EntityHitResult hit)) return;
        if(!(hit.getEntity() instanceof ServerPlayer player) || !MotionMagic.active(player)) return;
        Entity owner=arrow.getOwner();
        if(owner==player || (owner instanceof LivingEntity living && SpellCasting.protectedFrom(player,living))) return;
        event.setImpactResult(ProjectileImpactEvent.ImpactResult.STOP_AT_CURRENT_NO_DAMAGE);
        arrow.discard();
        ArcaneEffects.ring(player.serverLevel(),MagicData.magic(player),arrow.position(),.65,18);
    }


    /** Full lockdown runs on the SERVER and examines all entities, not only LivingEntity. */
    @SubscribeEvent public static void absoluteDoorwayTick(TickEvent.LevelTickEvent event) {
        if(event.phase!=TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) return;
        WardData wards=WardData.get(level);
        List<WardData.OpeningSeal> seals=wards.activeSeals(level);
        for(WardData.OpeningSeal seal:seals) {
            var area=seal.area();
            for(Entity entity:level.getEntities((Entity)null,area.inflate(4.0),e->e.isAlive() && !e.isSpectator())) {
                Vec3 current=entity.position();
                Vec3 previous=ABSOLUTE_PREVIOUS.put(entity,current);
                if(previous==null) previous=current.subtract(entity.getDeltaMovement());
                if(current.distanceToSqr(previous)<.00001) continue;
                double midY=entity.getBbHeight()*.5;
                Vec3 from=previous.add(0,midY,0),to=current.add(0,midY,0);
                // Creatures already inside when a seal is raised can walk OUT. Reentry is denied.
                if(area.inflate(.04).contains(from)) continue;
                if(!area.inflate(.04).contains(to) && area.clip(from,to).isEmpty()) continue;
                if(entity instanceof net.minecraft.world.entity.projectile.Projectile projectile) {
                    projectile.discard();
                } else {
                    if(entity instanceof ServerPlayer player)
                        player.connection.teleport(previous.x,previous.y,previous.z,player.getYRot(),player.getXRot());
                    else entity.setPos(previous.x,previous.y,previous.z);
                    entity.setDeltaMovement(Vec3.ZERO);
                    entity.hasImpulse=true;
                    ABSOLUTE_PREVIOUS.put(entity,previous);
                }
                if(level.getGameTime()%3==0) ArcaneEffects.sealImpact(level,seal.color(),to);
            }
            if(level.getGameTime()%12==0) {
                if(seal.door()) ArcaneEffects.doorWard(level,seal.color(),seal.start(),true);
                else ArcaneEffects.emptyDoorway(level,seal,false);
            }
        }
        if(level.getGameTime()%24==0) {
            for(WardData.OpeningSeal door:wards.visibleDoors(level))
                if(!wards.isAbsoluteDoor(level,door.start()))
                    ArcaneEffects.doorWard(level,door.color(),door.start(),false);
        }
    }
    /** Server-only rollback when crossing an active ward; owner and coven are exempt. */
    @SubscribeEvent public static void saltBoundaryTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity=event.getEntity();
        if(!(entity.level() instanceof ServerLevel level)) return;
        if(entity.isSpectator()) return;
        Vec3 current=entity.position();
        Vec3 previous=PREVIOUS.put(entity,current);
        if(previous==null) return;
        double length=current.distanceTo(previous);
        if(length>16) return; // allow deliberate teleportation/portal travel
        boolean undead=entity.getMobType()==MobType.UNDEAD || entity.getType().is(EclipseMod.EXTRA_UNDEAD);
        WardData wards=WardData.get(level);
        int steps=Math.max(1,(int)Math.ceil(length*6));
        for(int i=1;i<=steps;i++) {
            Vec3 point=previous.lerp(current,(double)i/steps);
            if(crossesWard(level,wards,entity,point,undead)) {
                if(entity instanceof ServerPlayer player)
                    player.connection.teleport(previous.x,previous.y,previous.z,player.getYRot(),player.getXRot());
                else entity.setPos(previous.x,previous.y,previous.z);
                entity.setDeltaMovement(0,Math.min(0,entity.getDeltaMovement().y),0);
                PREVIOUS.put(entity,previous);
                if(entity.tickCount%12==0)
                    level.sendParticles(ParticleTypes.END_ROD,point.x,point.y+.15,point.z,3,.15,.3,.15,.01);
                break;
            }
        }
    }
    private static boolean crossesWard(ServerLevel level,WardData wards,LivingEntity entity,Vec3 point,boolean undead) {
        BlockPos at=BlockPos.containing(point.x,point.y+.05,point.z);
        // Charged salt forms a five-block-high magical plane; plain salt repels undead.
        for(int dy=0;dy>=-5;dy--) {
            BlockPos salt=at.offset(0,dy,0);
            UUID owner=wards.chargedOwner(level,salt);
            if(owner!=null && !WardData.canCross(level,owner,entity)) return true;
            if(undead && owner==null && dy>=-2 && EclipseMod.isSalt(level.getBlockState(salt))) return true;
        }
        // Salted vanilla doors also respect caster/coven exemptions.
        for(int dy=-2;dy<=1;dy++) {
            UUID owner=wards.doorOwner(level,at.offset(0,dy,0));
            if(owner!=null && !WardData.canCross(level,owner,entity)) return true;
        }
        return false;
    }
}
