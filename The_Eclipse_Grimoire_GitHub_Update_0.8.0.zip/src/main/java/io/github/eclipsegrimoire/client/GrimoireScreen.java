package io.github.eclipsegrimoire.client;

import java.util.ArrayList;
import java.util.List;
import io.github.eclipsegrimoire.MagicData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

/** Facing-page, animated grimoire. Separate book style, page dye, and magic tint. */
public final class GrimoireScreen extends Screen {
    private enum Section { SPELLS, COVEN, FAMILIARS, WHEEL, SETTINGS, STYLE }
    private Section section=Section.SPELLS;
    private final String bookName, coven, invitation;
    private final int level,xp,xpNext,mana,maxMana,covenSize;
    private final List<String> players=new ArrayList<>(),members=new ArrayList<>();
    private final ListTag familiarRoster;
    private String magicColor,bookColor,bookStyle;
    private EditBox nameInput,covenInput;
    private int leaf=0,wheelIndex=0,familiarIndex=0;
    private long turnStarted=0;
    private boolean turnForward=true;
    private final List<SpellHint> hints=new ArrayList<>();
    private static final int WIDTH=458,HEIGHT=310;
    // 82% of the former size on normal displays; smaller GUI windows are fitted automatically.
    private float bookScale() {
        return Math.max(0.12f,Math.min(0.82f,Math.min((width-12f)/WIDTH,(height-12f)/HEIGHT)));
    }
    private static final int PALE=0xffefe8de,FADED=0xffc1b5ce,GOLD=0xffddc389;
    private static final String[] COLORS={"purple","crimson","blue","emerald","gold","white","shadow","rose"};
    private static final String[] STYLES={"regal","gothic","natural","celestial","relic"};
    private static final String[] STYLE_NAMES={"ANCIENT REGAL","OCCULT GOTHIC","NATURAL WITCH","CELESTIAL","FORBIDDEN RELIC"};
    private static final String[] STYLE_DESC={"Gilded borders and royal medallions",
        "Blackened paper, sharp occult runes","Leaf motifs and flowing vine-work",
        "Constellations and lunar diagrams","Weathered corners and ancient seals"};
    private record SpellDef(String title,String id,int cost,String description) { }
    private record SpellHint(int x,int y,int w,int h,String description) { }
    private static final SpellDef[][] SPELL_CHAPTERS={
        {new SpellDef("Warding Shield","ward",8,"Resist damage; protect nearby allies"),
         new SpellDef("Mending Light","mend",12,"Restore health to your coven and pets"),
         new SpellDef("Salt Circle","circle",20,"Create a seven-block enchanted salt ring"),
         new SpellDef("Seal Salt","seal",12,"Enchant connected salt; existing door wards remain supported"),
         new SpellDef("Absolute Seal","absolute",12,"Lock an already-warded door or framed enchanted threshold"),
         new SpellDef("Witchfire","witchfire",30,"Protective magical flames and arrow ward")},
        {new SpellDef("Surge of Power","power",10,"Strength and speed bestowed by magic"),
         new SpellDef("Chains of Night","bind",15,"Weaken and slow hostile creatures"),
         new SpellDef("Telekinetic Pulse","pulse",14,"Repel outsiders without hurting your coven"),
         new SpellDef("Alzur's Thunder","thunder",30,"Hand-cast lightning along your gaze"),
         new SpellDef("The Final Aegis","aegis",40,"Expensive, all-encompassing protection")},
        {new SpellDef("Veil of Shadows","veil",15,"Disappear from view and move faster"),
         new SpellDef("Blink","blink",18,"Travel to a safe place along your gaze"),
         new SpellDef("Arcane Tether","tether",10,"Attach a magic-colored strand to any mob"),
         new SpellDef("Witchlight","witchlight",12,"Summon a following light orb and cave vision")},
        {new SpellDef("Infuse Salt","infuse",8,"Color your held salt; each piece wards"),
         new SpellDef("Shatter Ward","shatter",22,"Dispel doors, thresholds or salt lines"),
         new SpellDef("Dispel","dispel",18,"Disrupt temporary magic and silence ward objects")}
    };
    private static final String[] CHAPTER_NAMES={"THE WARDING ARTS","FORCE AND STORMS","VEILS AND PASSAGE","SALT AND RITUAL"};

    public GrimoireScreen(ItemStack book) {
        super(Component.literal("The Eclipse Grimoire"));
        CompoundTag tag=book.getTag();
        bookName=tag!=null&&tag.contains("eclipseName")?tag.getString("eclipseName"):MagicData.DEFAULT_BOOK;
        magicColor=tag!=null&&tag.contains("eclipseMagic")?tag.getString("eclipseMagic"):"purple";
        bookColor=tag!=null&&tag.contains("eclipseUI")?tag.getString("eclipseUI"):"shadow";
        bookStyle=tag!=null&&tag.contains("eclipseStyle")?tag.getString("eclipseStyle"):"regal";
        level=tag!=null&&tag.contains("eclipseLevel")?tag.getInt("eclipseLevel"):1;
        xp=tag!=null?tag.getInt("eclipseXp"):0;
        xpNext=tag!=null?tag.getInt("eclipseXpNext"):35;
        mana=tag!=null?tag.getInt("eclipseMana"):100;
        maxMana=tag!=null?tag.getInt("eclipseMaxMana"):100;
        coven=tag!=null?tag.getString("eclipseCoven"):"";
        invitation=tag!=null?tag.getString("eclipseInvite"):"";
        covenSize=tag!=null?tag.getInt("eclipseCovenCount"):0;
        if(tag!=null) {
            ListTag online=tag.getList("eclipseOnlinePlayers",8);
            for(int i=0;i<online.size();i++) players.add(online.getString(i));
            ListTag roster=tag.getList("eclipseCovenMembers",8);
            for(int i=0;i<roster.size();i++) members.add(roster.getString(i));
        }
        familiarRoster=tag==null?new ListTag():tag.getList("eclipseFamiliars",10);
    }
    // Widget coordinates are laid out in virtual book space; rendering and mouse input
    // share the exact same scaling so buttons and text fields remain clickable.
    private int left() {return Math.round((width/bookScale()-WIDTH)/2f);}
    private int top() {return Math.round((height/bookScale()-HEIGHT)/2f);}
    private int tint(String name) {return 0xff000000|switch(name) {
        case "purple"->0xa46af5;case "crimson"->0xe34e69;case "blue"->0x54a6ef;
        case "emerald"->0x43bd94;case "gold"->0xe6b74e;case "white"->0xe7dfe9;
        case "rose"->0xed91cb;default->0x80728f;
    };}
    private int accent() {return tint(bookColor);}
    private int magic() {return tint(magicColor);}
    private int dye(float strength) {
        int c=accent();
        int r=(int)(((c>>16)&255)*strength),g=(int)(((c>>8)&255)*strength),b=(int)((c&255)*strength);
        return 0xff000000|(r<<16)|(g<<8)|b;
    }
    private int spineColor() {return "gothic".equals(bookStyle)?0xff08080d:dye(.12f);}
    private int edgeColor() {return "natural".equals(bookStyle)?0xffb3ca8f:"celestial".equals(bookStyle)?0xffbed9f4:GOLD;}
    private int leafCount() {return switch(section) {
        case SPELLS->SPELL_CHAPTERS.length;
        case COVEN->Math.max(1,(int)Math.ceil(Math.max(1,players.size())/4.0));
        case FAMILIARS->Math.max(1,(int)Math.ceil(Math.max(1,familiarRoster.size())/5.0));
        default->1;
    };}
    private String next(String current,String[] values) {
        for(int i=0;i<values.length;i++) if(values[i].equals(current))return values[(i+1)%values.length];
        return values[0];
    }
    private void clickSound() {
        Minecraft mc=Minecraft.getInstance();
        mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.BOOK_PAGE_TURN,1f));
    }
    private void changeSection(Section to) {
        if(to==section) return;
        turnForward=to.ordinal()>section.ordinal();section=to;leaf=0;turnStarted=System.currentTimeMillis();
        clickSound();clearWidgets();init();
    }
    private void turnLeaf(int dir) {
        int next=leaf+dir;
        if(next>=0 && next<leafCount()) {leaf=next;turnForward=dir>0;turnStarted=System.currentTimeMillis();clickSound();clearWidgets();init();}
        else {
            int sectionIndex=section.ordinal()+dir;
            if(sectionIndex>=0 && sectionIndex<Section.values().length) changeSection(Section.values()[sectionIndex]);
        }
    }
    private void command(String cmd) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null&&mc.player.connection!=null) mc.player.connection.sendCommand(cmd);
    }
    private void closeBook() {Minecraft.getInstance().setScreen(null);}
    private Button button(int x,int y,int w,int h,String label,Button.OnPress action,boolean selected) {
        return new PageButton(x,y,w,h,Component.literal(label),action,selected);
    }
    @Override protected void init() {
        hints.clear();
        int x=left(),y=top();
        String[] names={"SPELLS","COVEN","FAMILIARS","WHEEL","SETTINGS","STYLE"};
        for(int i=0;i<Section.values().length;i++) {
            Section target=Section.values()[i];
            addRenderableWidget(button(x+12+i*73,y+40,69,19,names[i],b->changeSection(target),target==section));
        }
        switch(section) {
            case SPELLS -> initSpells(x,y);
            case COVEN -> initCoven(x,y);
            case FAMILIARS -> initFamiliars(x,y);
            case WHEEL -> initWheel(x,y);
            case SETTINGS -> initSettings(x,y);
            case STYLE -> initStyle(x,y);
        }
        addRenderableWidget(button(x+12,y+280,67,20,"< PREV",b->turnLeaf(-1),false));
        addRenderableWidget(button(x+380,y+280,67,20,"NEXT >",b->turnLeaf(1),false));
        addRenderableWidget(button(x+306,y+280,67,20,"CLOSE",b->closeBook(),false));
    }
    private void initSpells(int x,int y) {
        SpellDef[] spellList=SPELL_CHAPTERS[Math.min(leaf,SPELL_CHAPTERS.length-1)];
        for(int i=0;i<spellList.length;i++) {
            SpellDef spell=spellList[i];int by=y+111+i*27;
            boolean unlocked=level>=MagicData.requiredLevel(spell.id);
            Button b=button(x+241,by,196,21,spell.title+(unlocked?"  ["+spell.cost+"]":"  [LV "+MagicData.requiredLevel(spell.id)+"]"),
                press->{command("eclipse cast "+spell.id);closeBook();},false);
            b.active=unlocked;addRenderableWidget(b);
            hints.add(new SpellHint(x+241,by,196,21,spell.description));
        }
    }
    private void initCoven(int x,int y) {
        covenInput=new EditBox(font,x+22,y+206,178,19,Component.literal("Coven name"));
        covenInput.setMaxLength(24);covenInput.setHint(Component.literal("New coven name"));
        addRenderableWidget(covenInput);
        addRenderableWidget(button(x+22,y+231,178,21,"CREATE A COVEN",b->{
            String value=covenInput.getValue().trim();
            if(value.matches("[a-zA-Z0-9_ -]{2,24}")){command("eclipse coven create "+value);closeBook();}
        },false));
        if(!invitation.isEmpty())
            addRenderableWidget(button(x+22,y+178,178,19,"ACCEPT INVITATION",b->{command("eclipse coven join");closeBook();},false));
        if(!coven.isEmpty())
            addRenderableWidget(button(x+22,y+178,178,19,"LEAVE COVEN",b->{command("eclipse coven leave");closeBook();},false));
        for(int i=0;i<4;i++) {
            int idx=leaf*4+i;
            if(idx>=players.size()) break;
            String player=players.get(idx);
            int yy=y+117+i*31;
            if(!coven.isEmpty() && !members.contains(player))
                addRenderableWidget(button(x+348,yy-3,83,19,"INVITE",b->{command("eclipse coven invite "+player);closeBook();},false));
        }
    }
    private void initFamiliars(int x,int y) {
        for(int i=0;i<5;i++) {
            int idx=leaf*5+i;
            if(idx>=familiarRoster.size()) break;
            String name=familiarRoster.getCompound(idx).getString("name");
            int yy=y+112+i*27;
            addRenderableWidget(button(x+20,yy,187,21,name,b->{familiarIndex=idx;},idx==familiarIndex));
        }
        addRenderableWidget(button(x+244,y+216,191,22,"BOND TAMED PET IN SIGHT",b->{command("eclipse familiar bond");closeBook();},false));
    }
    private void initWheel(int x,int y) {
        WheelPreferences prefs=WheelPreferences.get();
        List<String> order=prefs.order();
        wheelIndex=Math.floorMod(wheelIndex,order.size());
        String selected=order.get(wheelIndex);
        addRenderableWidget(button(x+245,y+114,85,23,"< SPELL",b->{wheelIndex=Math.floorMod(wheelIndex-1,order.size());clearWidgets();init();},false));
        addRenderableWidget(button(x+346,y+114,85,23,"SPELL >",b->{wheelIndex=(wheelIndex+1)%order.size();clearWidgets();init();},false));
        addRenderableWidget(button(x+244,y+153,89,22,"EARLIER",b->{prefs.move(selected,-1);wheelIndex=Math.floorMod(wheelIndex-1,order.size());clearWidgets();init();},false));
        addRenderableWidget(button(x+340,y+153,89,22,"LATER",b->{prefs.move(selected,1);wheelIndex=(wheelIndex+1)%order.size();clearWidgets();init();},false));
        addRenderableWidget(button(x+243,y+186,188,22,prefs.shown(selected)?"HIDE FROM WHEEL":"SHOW ON WHEEL",b->{prefs.toggle(selected);clearWidgets();init();},false));
        addRenderableWidget(button(x+22,y+132,185,21,"WHEEL SIZE: "+prefs.sizeLabel(),b->{prefs.cycleRadius();clearWidgets();init();},false));
        addRenderableWidget(button(x+22,y+160,185,21,"TRANSPARENCY: "+prefs.opacity()+"%",b->{prefs.cycleOpacity();clearWidgets();init();},false));
        addRenderableWidget(button(x+22,y+188,185,21,"WHEEL TINT: "+prefs.color().toUpperCase(),b->{prefs.cycleColor();clearWidgets();init();},false));
        addRenderableWidget(button(x+22,y+231,185,21,"RESET WHEEL TO DEFAULT",b->{prefs.reset();wheelIndex=0;clearWidgets();init();},false));
    }
    private void initSettings(int x,int y) {
        nameInput=new EditBox(font,x+22,y+126,185,21,Component.literal("Book name"));
        nameInput.setMaxLength(32);nameInput.setValue(bookName);addRenderableWidget(nameInput);
        addRenderableWidget(button(x+22,y+156,185,22,"SAVE BOOK NAME",b->{command("eclipse rename "+nameInput.getValue());closeBook();},false));
        addRenderableWidget(button(x+238,y+126,194,23,"MAGIC: "+magicColor.toUpperCase(),b->{magicColor=next(magicColor,COLORS);command("eclipse color magic "+magicColor);clearWidgets();init();},false));
        addRenderableWidget(button(x+238,y+162,194,23,"BOOK: "+bookColor.toUpperCase(),b->{bookColor=next(bookColor,COLORS);command("eclipse color book "+bookColor);clearWidgets();init();},false));
        addRenderableWidget(button(x+238,y+220,194,22,"BOOK STYLE >",b->changeSection(Section.STYLE),false));
    }
    private void initStyle(int x,int y) {
        addRenderableWidget(button(x+24,y+199,73,23,"< STYLE",b->{bookStyle=previousStyle();changeStyle();},false));
        addRenderableWidget(button(x+126,y+199,74,23,"STYLE >",b->{bookStyle=next(bookStyle,STYLES);changeStyle();},false));
        for(int i=0;i<STYLES.length;i++) {
            final String target=STYLES[i];
            addRenderableWidget(button(x+244,y+107+i*30,189,23,STYLE_NAMES[i],b->{bookStyle=target;changeStyle();},target.equals(bookStyle)));
        }
    }
    private String previousStyle() {
        for(int i=0;i<STYLES.length;i++)if(STYLES[i].equals(bookStyle))return STYLES[(i+STYLES.length-1)%STYLES.length];
        return STYLES[0];
    }
    private void changeStyle() {
        command("eclipse style "+bookStyle);
        turnForward=true;turnStarted=System.currentTimeMillis();clickSound();clearWidgets();init();
    }
    private void line(GuiGraphics g,String s,int x,int y,int color) {g.drawString(font,s,x,y,color);}
    private void clipped(GuiGraphics g,String s,int x,int y,int w,int color) {line(g,font.plainSubstrByWidth(s,w),x,y,color);}
    private void bookFrame(GuiGraphics g,int x,int y) {
        g.fill(x-7,y-6,x+WIDTH+7,y+HEIGHT+7,0xbf000000);
        // 3D-ish raised leather cover, distinct style edge and two dyed facing pages.
        g.fill(x-3,y-3,x+WIDTH+3,y+HEIGHT+3,edgeColor());
        g.fill(x,y,x+WIDTH,y+HEIGHT,dye(.09f));
        g.fillGradient(x+5,y+4,x+WIDTH-5,y+HEIGHT-5,dye(.45f),dye(.21f));
        g.fill(x+12,y+74,x+WIDTH-12,y+270,spineColor());
        g.fillGradient(x+16,y+78,x+WIDTH/2-3,y+269,dye(.48f),dye(.35f));
        g.fillGradient(x+WIDTH/2+3,y+78,x+WIDTH-16,y+269,dye(.38f),dye(.48f));
        g.fill(x+WIDTH/2-3,y+78,x+WIDTH/2+3,y+269,dye(.08f));
        g.fill(x+WIDTH/2-1,y+79,x+WIDTH/2+1,y+268,edgeColor());
        g.fill(x+13,y+34,x+WIDTH-13,y+36,edgeColor());
        g.fill(x+13,y+62,x+WIDTH-13,y+63,dye(.82f));
        g.fill(x+13,y+277,x+WIDTH-13,y+278,edgeColor());
        ornaments(g,x,y);
        clipped(g,bookName,x+22,y+11,WIDTH-43,PALE);
        line(g,"THE ECLIPSE GRIMOIRE  -  "+bookStyle.toUpperCase(),x+22,y+23,FADED);
        line(g,"LV "+level+"  |  XP "+xp+(xpNext==0?"  MAX":" / "+xpNext),x+17,y+65,PALE);
        line(g,"MANA "+mana+" / "+maxMana,x+WIDTH-130,y+65,PALE);
        g.fill(x+16,y+75,x+WIDTH/2-13,y+77,dye(.18f));
        g.fill(x+16,y+75,x+16+(int)((WIDTH/2-29)*Math.min(1.0,xpNext==0?1.0:(double)xp/Math.max(1,xpNext))),y+77,edgeColor());
        g.fill(x+WIDTH/2+13,y+75,x+WIDTH-15,y+77,dye(.18f));
        g.fill(x+WIDTH/2+13,y+75,x+WIDTH/2+13+(int)((WIDTH/2-29)*(double)mana/Math.max(1,maxMana)),y+77,magic());
        g.drawCenteredString(font,"FOLIO  "+(leaf+1)+" / "+leafCount(),x+WIDTH/2,y+286,PALE);
    }
    private void ornaments(GuiGraphics g,int x,int y) {
        int c=edgeColor();
        if("natural".equals(bookStyle)) {
            for(int i=0;i<9;i++) {
                int yy=y+89+i*19;
                g.fill(x+15,yy,x+21+(i%3)*2,yy+2,c);
                g.fill(x+WIDTH-21-(i%3)*2,yy,x+WIDTH-15,yy+2,c);
            }
        } else if("celestial".equals(bookStyle)) {
            for(int i=0;i<10;i++) {
                int xx=x+29+i*42, yy=y+87+(i%3)*52;
                g.fill(xx,yy,xx+2,yy+2,c);
                g.fill(xx-2,yy+1,xx+4,yy+2,dye(.8f));
            }
            for(int i=0;i<5;i++) {
                int yy=y+94+i*29;
                g.fill(x+WIDTH-31,yy,x+WIDTH-23,yy+1,c);
            }
        } else if("gothic".equals(bookStyle)) {
            for(int i=0;i<12;i++) {
                int xx=x+18+i*38;
                g.fill(xx,y+7,xx+3,y+14,c);
                g.fill(xx,y+HEIGHT-15,xx+3,y+HEIGHT-9,c);
            }
        } else if("relic".equals(bookStyle)) {
            for(int i=0;i<12;i++) {
                int yy=y+89+i*14;
                g.fill(x+17+(i%3)*3,yy,x+21+(i%3)*3,yy+2,dye(.85f));
                g.fill(x+WIDTH-23-(i%4)*2,yy,x+WIDTH-18,yy+2,c);
            }
            g.fill(x+17,y+82,x+23,y+83,c);
        } else {
            for(int i=0;i<4;i++) {
                int xx=i%2==0?x+17:x+WIDTH-22;
                int yy=i/2==0?y+82:y+260;
                g.fill(xx,yy,xx+6,yy+2,c);
                g.fill(xx+2,yy-2,xx+4,yy+5,c);
            }
        }
        // The center sigil changes shape with the theme, but retains your selected dye.
        int sx=x+WIDTH/2,sy=y+19;
        g.fill(sx-9,sy,sx+10,sy+1,c);
        g.fill(sx,sy-8,sx+1,sy+9,c);
        g.fill(sx-3,sy-3,sx+4,sy+4,dye(.17f));
        g.fill(sx-1,sy-1,sx+2,sy+2,magic());
    }
    private void renderSection(GuiGraphics g,int x,int y,int mx,int my) {
        switch(section) {
            case SPELLS -> {
                String title=CHAPTER_NAMES[Math.min(leaf,CHAPTER_NAMES.length-1)];
                line(g,title,x+23,y+90,edgeColor());
                clipped(g,"CHAPTER "+(leaf+1)+" - "+(SPELL_CHAPTERS[leaf].length)+" SPELLS",x+23,y+104,180,FADED);
                line(g,"Your level: "+level,x+23,y+135,PALE);
                line(g,"Cast from the book",x+23,y+156,FADED);
                line(g,"or hold G for your wheel.",x+23,y+171,FADED);
                line(g,"Unlocked: bright text",x+23,y+200,PALE);
                line(g,"Locked: level required",x+23,y+216,FADED);
                line(g,"KNOWN INCANTATIONS",x+244,y+89,edgeColor());
                String note="Hover over a spell to read its description";
                for(SpellHint h:hints)if(mx>=h.x&&mx<h.x+h.w&&my>=h.y&&my<h.y+h.h) {note=h.description;break;}
                clipped(g,note,x+23,y+252,420,FADED);
            }
            case COVEN -> {
                line(g,"THE COVEN REGISTER",x+23,y+90,edgeColor());
                clipped(g,coven.isEmpty()?"No coven yet":coven,x+23,y+108,183,PALE);
                clipped(g,"Members: "+covenSize+"  |  Online: "+members.size(),x+23,y+124,184,FADED);
                int visible=Math.min(4,members.size());
                for(int i=0;i<visible;i++) clipped(g,"* "+members.get(i),x+23,y+133+i*11,178,PALE);
                if(!invitation.isEmpty()) clipped(g,"Invite: "+invitation,x+23,y+168,185,PALE);
                line(g,"ONLINE PLAYERS",x+247,y+90,edgeColor());
                line(g,"Invite someone to join your coven",x+247,y+103,FADED);
                for(int i=0;i<4;i++) {
                    int idx=leaf*4+i;
                    if(idx>=players.size())break;
                    clipped(g,players.get(idx),x+247,y+119+i*31,93,PALE);
                    if(members.contains(players.get(idx))) clipped(g,"IN COVEN",x+349,y+121+i*31,82,edgeColor());
                }
                if(players.isEmpty()) line(g,"No other players online",x+247,y+130,FADED);
                line(g,"Open the book again to refresh the roster.",x+23,y+263,FADED);
            }
            case FAMILIARS -> {
                line(g,"YOUR FAMILIAR BONDS",x+23,y+91,edgeColor());
                line(g,"Bound companions: "+familiarRoster.size(),x+23,y+100,FADED);
                line(g,"COMPANION DETAILS",x+246,y+91,edgeColor());
                if(familiarRoster.isEmpty()) {
                    line(g,"No registered familiars.",x+27,y+137,PALE);
                    line(g,"Bond a tame animal you own.",x+246,y+129,FADED);
                } else {
                    familiarIndex=Math.min(familiarIndex,familiarRoster.size()-1);
                    CompoundTag f=familiarRoster.getCompound(familiarIndex);
                    clipped(g,f.getString("name"),x+247,y+115,180,PALE);
                    clipped(g,f.getString("type"),x+247,y+132,183,FADED);
                    line(g,f.getBoolean("near")?"Nearby  -  "+f.getInt("distance")+" blocks":"Not loaded in this dimension",x+247,y+155,FADED);
                    if(f.getBoolean("near"))line(g,"Health: "+f.getInt("health"),x+247,y+174,PALE);
                    line(g,"Bonding never changes pet ownership.",x+247,y+197,FADED);
                }
                line(g,"Roster updates when you reopen the book.",x+23,y+262,FADED);
            }
            case WHEEL -> {
                WheelPreferences prefs=WheelPreferences.get();
                List<String> order=prefs.order();String chosen=order.get(Math.floorMod(wheelIndex,order.size()));
                line(g,"YOUR QUICK-CAST WHEEL",x+23,y+92,edgeColor());
                line(g,"Hold G, scroll, release to cast.",x+23,y+106,FADED);
                line(g,"SPELL ORDER",x+246,y+91,edgeColor());
                clipped(g,SpellWheel.label(chosen)+" ("+(wheelIndex+1)+"/"+order.size()+")",x+243,y+143,193,PALE);
                line(g,"Level "+MagicData.requiredLevel(chosen)+" | "+(prefs.shown(chosen)?"Visible":"Hidden"),x+245,y+177,FADED);
                line(g,"Compact HUD; scroll changes pages.",x+22,y+263,FADED);
            }
            case SETTINGS -> {
                line(g,"THE GRIMOIRE'S NAME",x+24,y+95,edgeColor());
                line(g,"Name your personal spellbook.",x+23,y+109,FADED);
                line(g,"YOUR COLOR SIGNATURE",x+242,y+95,edgeColor());
                g.fill(x+241,y+196,x+336,y+203,magic());
                g.fill(x+341,y+196,x+431,y+203,accent());
                line(g,"Magic and book dyes are separate.",x+242,y+209,FADED);
                line(g,"Choose a different book design",x+23,y+249,PALE);
                line(g,"in the STYLE section.",x+23,y+261,FADED);
            }
            case STYLE -> {
                line(g,"BINDING & PAGE STYLE",x+23,y+91,edgeColor());
                int idx=0;for(int i=0;i<STYLES.length;i++)if(STYLES[i].equals(bookStyle))idx=i;
                clipped(g,STYLE_NAMES[idx],x+23,y+116,184,PALE);
                clipped(g,STYLE_DESC[idx],x+23,y+138,184,FADED);
                line(g,"Pick a design on the right.",x+23,y+161,PALE);
                line(g,"Book color stays "+bookColor+".",x+23,y+180,FADED);
                line(g,"PICK YOUR DESIGN",x+246,y+91,edgeColor());
                line(g,"Styles apply to both facing pages,",x+23,y+246,FADED);
                line(g,"the cover, details and binding.",x+23,y+258,FADED);
            }
        }
    }
    private void pageTurnOverlay(GuiGraphics g,int x,int y,float partial) {
        long elapsed=System.currentTimeMillis()-turnStarted;
        if(turnStarted==0 || elapsed>340) return;
        double phase=Math.min(1.0,elapsed/340.0);
        double curve=Math.sin(phase*Math.PI);
        int baseX=turnForward?x+WIDTH/2+3:x+15;
        int endX=turnForward?x+WIDTH-16:x+WIDTH/2-3;
        int visible=(int)((endX-baseX)*(1.0-.91*curve));
        if(turnForward) {
            g.fill(endX-visible,y+82,endX,y+268,0xcc181222);
            g.fill(endX-visible,y+82,endX-visible+2,y+268,edgeColor());
        } else {
            g.fill(baseX,y+82,baseX+visible,y+268,0xcc181222);
            g.fill(baseX+visible-2,y+82,baseX+visible,y+268,edgeColor());
        }
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g);
        float scale=bookScale();
        int virtualMouseX=Math.round(mouseX/scale),virtualMouseY=Math.round(mouseY/scale);
        int x=left(),y=top();
        g.pose().pushPose();
        g.pose().scale(scale,scale,1f);
        bookFrame(g,x,y);
        renderSection(g,x,y,virtualMouseX,virtualMouseY);
        super.render(g,virtualMouseX,virtualMouseY,partial);
        pageTurnOverlay(g,x,y,partial);
        g.pose().popPose();
    }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        float s=bookScale();return super.mouseClicked(mouseX/s,mouseY/s,button);
    }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button) {
        float s=bookScale();return super.mouseReleased(mouseX/s,mouseY/s,button);
    }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double dragX,double dragY) {
        float s=bookScale();return super.mouseDragged(mouseX/s,mouseY/s,button,dragX/s,dragY/s);
    }
    @Override public boolean mouseScrolled(double mouseX,double mouseY,double delta) {
        float s=bookScale();return super.mouseScrolled(mouseX/s,mouseY/s,delta);
    }
    private final class PageButton extends Button {
        private final boolean selected;
        private PageButton(int x,int y,int w,int h,Component title,OnPress action,boolean selected) {
            super(x,y,w,h,title,action,Button.DEFAULT_NARRATION);this.selected=selected;
        }
        @Override protected void renderWidget(GuiGraphics g,int mx,int my,float partial) {
            int x=getX(),y=getY(),w=width,h=height;
            boolean hover=isHoveredOrFocused();
            int edge=selected||hover?edgeColor():dye(.78f);
            int inside=!active?dye(.15f):selected?dye(.58f):hover?dye(.48f):dye(.32f);
            g.fill(x,y,x+w,y+h,edge);
            g.fill(x+1,y+1,x+w-1,y+h-1,inside);
            if(selected)g.fill(x+3,y+h-3,x+w-3,y+h-1,magic());
            String text=font.plainSubstrByWidth(getMessage().getString(),w-8);
            g.drawCenteredString(font,text,x+w/2,y+(h-8)/2,active?PALE:0xff938ba0);
        }
    }
    @Override public boolean isPauseScreen(){return false;}
}
