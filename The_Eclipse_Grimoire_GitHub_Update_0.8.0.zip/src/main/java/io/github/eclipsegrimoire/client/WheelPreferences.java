package io.github.eclipsegrimoire.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import net.minecraft.client.Minecraft;

/** Per-installation client controls. Never trusts external spell IDs and never modifies server progress. */
public final class WheelPreferences {
    private WheelPreferences() {}
    public static final List<String> DEFAULT=List.of("ward","power","mend","veil","bind","tether",
        "circle","seal","absolute","infuse","pulse","shatter","thunder","blink","witchfire","aegis", "witchlight","dispel");
    private static final String[] COLOR_OPTIONS={"magic","purple","crimson","blue","emerald","gold","white","shadow","rose"};
    private static final WheelPreferences INSTANCE=new WheelPreferences();
    private final List<String> order=new ArrayList<>(DEFAULT);
    private final Set<String> hidden=new HashSet<>();
    private int opacity=60,radius=72;
    private String color="magic";
    private boolean loaded;
    public static WheelPreferences get() { INSTANCE.load();return INSTANCE; }

    private Path path() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config/eclipse_grimoire_wheel.properties");
    }
    private void load() {
        if(loaded) return;
        loaded=true;
        Properties p=new Properties();
        try {
            if(Files.exists(path())) try(InputStream input=Files.newInputStream(path())) {p.load(input);}
        } catch(IOException e) {System.err.println("[Eclipse] Wheel settings couldn't be read: "+e.getMessage());}
        String listed=p.getProperty("order",String.join(",",DEFAULT));
        LinkedHashSet<String> valid=new LinkedHashSet<>();
        for(String id:listed.split(",")) if(DEFAULT.contains(id)) valid.add(id);
        valid.addAll(DEFAULT);
        order.clear();order.addAll(valid);
        hidden.clear();
        for(String id:p.getProperty("hidden","").split(",")) if(DEFAULT.contains(id)) hidden.add(id);
        opacity=parse(p.getProperty("opacity"),60,35,85);
        radius=parse(p.getProperty("radius"),72,58,94);
        color=p.getProperty("color","magic");
        if(!Arrays.asList(COLOR_OPTIONS).contains(color)) color="magic";
    }
    private static int parse(String raw,int fallback,int min,int max) {
        try{return Math.max(min,Math.min(max,Integer.parseInt(raw)));}catch(Exception e){return fallback;}
    }
    private void save() {
        Properties properties=new Properties();
        properties.setProperty("order",String.join(",",order));
        properties.setProperty("hidden",String.join(",",hidden));
        properties.setProperty("opacity",Integer.toString(opacity));
        properties.setProperty("radius",Integer.toString(radius));
        properties.setProperty("color",color);
        try {
            Files.createDirectories(path().getParent());
            try(OutputStream output=Files.newOutputStream(path())) {properties.store(output,"Eclipse Grimoire wheel — reset from the grimoire Wheel page");}
        } catch(IOException e) {System.err.println("[Eclipse] Wheel settings couldn't be saved: "+e.getMessage());}
    }
    public List<String> order(){return List.copyOf(order);}
    public boolean shown(String id){return !hidden.contains(id);}
    public int opacity(){return opacity;}
    public int radius(){return radius;}
    public String color(){return color;}
    public void move(String id,int offset){
        int index=order.indexOf(id);
        if(index<0) return;
        int to=Math.floorMod(index+offset,order.size());
        order.remove(index);order.add(to,id);save();
    }
    public void toggle(String id){
        if(!DEFAULT.contains(id)) return;
        if(hidden.contains(id)) hidden.remove(id);
        else if(hidden.size()<DEFAULT.size()-1) hidden.add(id);
        save();
    }
    public void cycleOpacity(){opacity=opacity>=85?35:opacity+10;save();}
    public void cycleRadius(){radius=radius<=62?72:radius<=72?88:62;save();}
    public String sizeLabel(){return radius<=62?"COMPACT":radius<=72?"NORMAL":"LARGE";}
    public void cycleColor(){
        for(int i=0;i<COLOR_OPTIONS.length;i++) if(COLOR_OPTIONS[i].equals(color)) {
            color=COLOR_OPTIONS[(i+1)%COLOR_OPTIONS.length];save();return;
        }
        color="magic";save();
    }
    public void reset(){order.clear();order.addAll(DEFAULT);hidden.clear();opacity=60;radius=72;color="magic";save();}
}
