package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Level-gated Witchlight and targeted Dispel integrated with the original mana system. */
public final class WitchcraftSpells {
    private WitchcraftSpells() {}
    private static final String LIGHT_UNTIL="witchlightUntil",LIGHT_WORLD="witchlightDimension";
    public static int rgb(String color){return ArcaneEffects.rgb(color);}
    public static boolean lightActive(ServerPlayer p) {
        CompoundTag n=MagicData.data(p);
        return n.getLong(LIGHT_UNTIL)>p.serverLevel().getGameTime()
            && p.serverLevel().dimension().location().toString().equals(n.getString(LIGHT_WORLD));
    }
    public static void stopLight(ServerPlayer p) {
        MagicData.data(p).remove(LIGHT_UNTIL);MagicData.data(p).remove(LIGHT_WORLD);
    }
    public static int cast(ServerPlayer player,String spell) {
        int required=MagicData.requiredLevel(spell);
        if(MagicData.level(player)<required){message(player,"Unlocks at magic level "+required+".");return 0;}
        if("witchlight".equals(spell)) {
            if(lightActive(player)){
                stopLight(player);
                player.removeEffect(MobEffects.NIGHT_VISION);
                message(player,"Witchlight extinguished.");return 1;
            }
            if(!MagicData.spend(player,12)){message(player,"Witchlight needs 12 mana.");return 0;}
            CompoundTag data=MagicData.data(player);
            data.putLong(LIGHT_UNTIL,player.serverLevel().getGameTime()+2400); // two minutes
            data.putString(LIGHT_WORLD,player.serverLevel().dimension().location().toString());
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,2500,0));
            ArcaneEffects.sigil(player.serverLevel(),MagicData.magic(player),player.position(),1.5);
            player.serverLevel().playSound(null,player.blockPosition(),SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.PLAYERS,.9f,1.6f);
            MagicData.earnXp(player,4);
            message(player,"Witchlight summoned for 2 minutes. Its orb follows you, and you can see in dark caves.");
            return 1;
        }
        if(!"dispel".equals(spell)) return 0;
        ServerLevel level=player.serverLevel();
        BlockHitResult block=player.pick(12.0,1f,false) instanceof BlockHitResult b?b:null;
        BlockPos target=block==null?null:block.getBlockPos();
        MagicDecorBlock furniture=target!=null && level.getBlockState(target).getBlock() instanceof MagicDecorBlock m?m:null;
        boolean wardObject=furniture!=null && (furniture.kind()==MagicDecorBlock.Kind.WARDSTONE || furniture.kind()==MagicDecorBlock.Kind.BELL);
        ServerPlayer other=null;
        Vec3 eye=player.getEyePosition(),end=eye.add(player.getLookAngle().scale(12));
        double best=Double.MAX_VALUE;
        for(ServerPlayer candidate:level.players()) {
            if(candidate==player || !candidate.isAlive()) continue;
            var intersect=candidate.getBoundingBox().inflate(.28).clip(eye,end);
            if(intersect.isEmpty() || !player.hasLineOfSight(candidate)) continue;
            double distance=eye.distanceToSqr(intersect.get());
            if(distance<best && (target==null || distance<eye.distanceToSqr(block.getLocation()))) {
                best=distance;other=candidate;
            }
        }
        if(other!=null && !player.server.isPvpAllowed() && !CovenData.get(level).same(other.getUUID(),player.getUUID())) {
            message(player,"Dispel of other players is disabled while server PvP is off.");return 0;
        }
        if(!wardObject && (other==null || !(MotionMagic.active(other) || lightActive(other)
            || MagicData.data(other).hasUUID("tetherTarget")))) {
            message(player,"Look at an active Wardstone, Witch's Bell, or a player with temporary Eclipse magic. No mana spent.");
            return 0;
        }
        if(!MagicData.spend(player,18)){message(player,"Dispel needs 18 mana.");return 0;}
        if(wardObject) {
            WitchcraftData.get(level).suppress(target,level.getGameTime()+300); // 15 sec, never erases ownership
            ArcaneEffects.sigil(level,MagicData.magic(player),Vec3.atCenterOf(target),1.5);
            message(player,"Dispel silenced this "+furniture.kind().name().toLowerCase()+" for 15 seconds. Its owner and binding remain intact.");
        } else {
            if(MotionMagic.active(other)) MotionMagic.stop(other);
            if(lightActive(other)) {stopLight(other);other.removeEffect(MobEffects.NIGHT_VISION);}
            if(MagicData.data(other).hasUUID("tetherTarget")) TetherMagic.release(other,"Arcane Tether disrupted by Dispel.");
            ArcaneEffects.sigil(level,MagicData.magic(player),other.position().add(0,.5,0),1.7);
            message(player,"Dispel disrupted "+other.getName().getString()+"'s active magical effects.");
            other.sendSystemMessage(Component.literal("[Eclipse] Your active magic was disrupted by "+player.getGameProfile().getName()+"."));
        }
        level.playSound(null,player.blockPosition(),SoundEvents.GLASS_BREAK,SoundSource.PLAYERS,.8f,.75f);
        MagicData.earnXp(player,5);
        return 1;
    }
    public static void tick(ServerPlayer p) {
        if(!lightActive(p) || p.tickCount%2!=0) return;
        ServerLevel level=p.serverLevel();
        double t=p.tickCount*.14;
        Vec3 center=p.position().add(-Math.sin(Math.toRadians(p.getYRot()))*.65,
            p.getBbHeight()+.42+.13*Math.sin(t),Math.cos(Math.toRadians(p.getYRot()))*.65);
        for(int k=0;k<6;k++) {
            double a=t+k*2*Math.PI/6;
            Vec3 point=center.add(Math.sin(a)*.12,Math.cos(a*2)*.11,Math.cos(a)*.12);
            ArcaneEffects.point(level,MagicData.magic(p),point);
        }
        if(p.tickCount%8==0) level.sendParticles(ParticleTypes.END_ROD,center.x,center.y,center.z,3,.09,.09,.09,.005);
    }
    private static void message(ServerPlayer p,String text){p.sendSystemMessage(Component.literal("[Eclipse] "+text));}
}
