# The Eclipse Grimoire — Forge 1.20.1 — Alpha 0.5.0

**Alpha 0.5.0 SOURCE, not a playable JAR.** The previous 0.4.0 JAR is user-tested and working; this new source must be compiled in GitHub Actions and tested before it replaces 0.4.0. This upgrade preserves the same mod ID and existing world/player data.

## New: Arcane Tether (magic level 2)

- Aim at a **mob** within 14 blocks, then cast `/eclipse cast tether` or select **Arcane Tether** in your spellbook or G-key spell wheel.
- Costs 10 mana to attach, no recurring mana cost. Recast to release for free. No spell cooldown.
- A gently pulling, glowing particle tether in your current magic color connects you to the mob. Most passive, tame and hostile mobs can be targeted; players cannot. Large bosses and certain modded mobs may resist normal pulling physics.
- You may have **one tethered creature at a time**. The cord breaks when the creature is over 23 blocks away, dies, unloads, or when you disconnect/change dimensions.
- A tether is **not taming**, loyalty, damage protection, or crowd control: hostile mobs can still attack you, and normal block collisions may stop the pull. The target is never teleported through blocks. Animal ownership is unchanged.
- If another online witch already has a valid tether on the mob, you cannot steal it without their release. Dead/stale bindings are cleaned up on the next attempt.

## New: refined grimoire screens

- Shadow-black parchment panels with gilt corners, an eclipse-inspired emblem, selected-tab highlights, and subtler button art.
- Visible colored mana and experience bars at the top; the colors reflect your magic and book settings.
- Spells divided into **Protection & Utility** and **Power & Counterspells** with cost or required level shown; hovering reveals descriptions.
- Coven page reorganized for creating covens, invitations, joining, leaving and viewing status. Familiar and settings pages have clearer layouts.
- The existing grimoire-from-lectern interaction, level system, mana economy, friendly-fire logic, colored warded salt, cauldron rituals and spell wheel remain.

## Level requirements / commands

- **Arcane Tether** unlocks at **level 2**. Other spell requirements remain unchanged.
- `/eclipse cast tether`: attach to the mob you're looking at; repeat to release.
- `/eclipse level`: your current level, XP and mana.
- `/eclipse grimoire`: get a grimoire; right-click to open or place on a lectern.
- **Spell wheel:** hold your remappable key (default G), scroll to choose a spell, release key to cast. Continues to permit movement.

## GitHub build process for this repository

1. Upload **`The_Eclipse_Grimoire_GitHub_Update_0.5.0.zip`** directly to the **repository ROOT** of `eclipsemidnight82/Eclipsed-Magic` on branch `main`. Do not extract the ZIP in GitHub and do not upload it into `eclipse_grimoire_safe_build`.
2. Open `.github/workflows/build.yml`, click edit/pencil, replace all text with **`Eclipsed_Magic_Build_0_5.yml`**, then commit. This automatically extracts the source from the ZIP into the Forge project build directory.
3. Open GitHub Actions. Download the **0.5.0 artifact ZIP** only if the corresponding workflow has a green checkmark.
4. Extract it; install only the compiled mod `.jar` into a separate CurseForge **Minecraft 1.20.1 Forge** test profile. Back up/remove 0.4.0 from that profile's `mods` folder rather than running both versions together.
5. Test in a new or backed-up world. For multiplayer, server and all clients need the same mod version.

## Alpha 0.5.0 test checklist

- Place and read the grimoire from a lectern; verify all four tabs and buttons fit on screen at your GUI scale.
- Check that spell levels, mana/XP bars and coven controls function as before. If the book clips at a very large GUI scale, reduce GUI scale in Video Settings.
- Reach level 2 and aim directly at a sheep, wolf or zombie within 14 blocks; cast Arcane Tether.
- Walk and turn. Check whether the glowing line follows and the mob is gently pulled without clipping through solid walls.
- Cast it again to release. Tether another mob; confirm a broken tether after moving 23+ blocks away.
- Test the G-key wheel with Arcane Tether unlocked and check WASD/mouse-look remain enabled.
- Check old colored salt barriers, salted doors, cauldrons, leveling and spell damage still work.

**No full Forge compilation or gameplay test has been performed on this 0.5.0 source yet.** Report the first `error:` line in the GitHub Actions Compile step if the build fails. GitHub's success verifies compilation, not multiplayer/gameplay behavior.

Minecraft 1.20.1 · Forge 47.4.0 · Java 17 · MIT source license.
