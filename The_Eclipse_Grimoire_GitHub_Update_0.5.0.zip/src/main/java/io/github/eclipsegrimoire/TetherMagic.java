package io.github.eclipsegrimoire;

import java.util.UUID;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** A single, server-authoritative magic leash per caster, with a visible colored strand.
 *  Uses normal entity velocity/collision rather than teleporting or changing ownership/AI.
 */
public final class TetherMagic {
    private TetherMagic() { }
    private static final String TARGET = "tetherTarget";
    private static final String HELD_BY = "EclipseTetherOwner";
    private static final int RANGE = 14;
    private static final int BREAK_DISTANCE = 23;

    public static int cast(ServerPlayer player) {
        CompoundTag magic = MagicData.data(player);
        if (magic.hasUUID(TARGET)) {
            release(player, "Arcane Tether released.");
            return 1;
        }
        Mob target = findLookedAtMob(player);
        if (target == null) {
            message(player, "Look directly at a mob within 14 blocks, then cast Arcane Tether.");
            return 0;
        }
        if (target.getPersistentData().hasUUID(HELD_BY)) {
            UUID otherId = target.getPersistentData().getUUID(HELD_BY);
            ServerPlayer other = player.getServer().getPlayerList().getPlayer(otherId);
            boolean stillHeld = other != null && other.serverLevel() == player.serverLevel()
                && MagicData.data(other).hasUUID(TARGET)
                && MagicData.data(other).getUUID(TARGET).equals(target.getUUID());
            if (stillHeld) {
                message(player, "That creature is already tethered by another witch.");
                return 0;
            }
            target.getPersistentData().remove(HELD_BY); // clear a stale link after a logout/chunk unload
        }
        if (!MagicData.spend(player, 10)) {
            message(player, "Arcane Tether needs 10 mana.");
            return 0;
        }
        magic.putUUID(TARGET, target.getUUID());
        target.getPersistentData().putUUID(HELD_BY, player.getUUID());
        MagicData.earnXp(player, 4);
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.EVOKER_CAST_SPELL,
            SoundSource.PLAYERS, 0.7f, 1.3f);
        message(player, "Arcane Tether linked to " + target.getName().getString() + ". Cast again to release.");
        return 1;
    }

    /** Match an actual line of sight, not simply the closest nearby mob. */
    private static Mob findLookedAtMob(ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        Mob best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Mob mob : player.serverLevel().getEntitiesOfClass(Mob.class,
            player.getBoundingBox().inflate(RANGE), m -> m.isAlive() && !m.isSpectator())) {
            var hit = mob.getBoundingBox().inflate(0.32).clip(eye, end);
            if (hit.isEmpty() || !player.hasLineOfSight(mob)) continue;
            double distance = eye.distanceToSqr(hit.get());
            if (distance < bestDistance) {best = mob; bestDistance = distance;}
        }
        return best;
    }

    public static void tick(ServerPlayer player) {
        CompoundTag magic = MagicData.data(player);
        if (!magic.hasUUID(TARGET)) return;
        ServerLevel level = player.serverLevel();
        Entity entity = level.getEntity(magic.getUUID(TARGET));
        if (!(entity instanceof Mob mob) || !mob.isAlive() || !player.isAlive()) {
            release(player, "Arcane Tether faded (creature unavailable).");
            return;
        }
        if (!mob.getPersistentData().hasUUID(HELD_BY)
            || !player.getUUID().equals(mob.getPersistentData().getUUID(HELD_BY))) {
            magic.remove(TARGET);
            return;
        }
        Vec3 start = player.position().add(0, player.getBbHeight() * 0.55, 0);
        Vec3 end = mob.getBoundingBox().getCenter();
        double distance = player.distanceTo(mob);
        if (distance > BREAK_DISTANCE) {
            release(player, "Arcane Tether broke: the creature moved too far away.");
            return;
        }
        // Leave a loose leash radius. Ordinary collision still prevents dragging through solid walls.
        if (distance > 3.0) {
            Vec3 pull = player.position().subtract(mob.position());
            double power = Math.min(0.36, 0.11 + (distance - 3.0) * 0.033);
            Vec3 toward = pull.normalize().scale(power);
            Vec3 current = mob.getDeltaMovement();
            mob.setDeltaMovement(current.x * 0.70 + toward.x,
                current.y * 0.80 + Math.max(-0.10, Math.min(0.22, toward.y)),
                current.z * 0.70 + toward.z);
            mob.hasImpulse = true;
        }
        if (player.tickCount % 3 == 0) {
            DustParticleOptions particle = particleFor(MagicData.magic(player));
            for (int i=0; i<=12; i++) {
                Vec3 point = start.lerp(end, (double)i/12);
                // A small animated ripple makes the strand feel magical rather than like a rigid lead.
                double shimmer = Math.sin(player.tickCount * 0.45 + i * 0.9) * 0.055;
                level.sendParticles(particle, point.x, point.y + shimmer, point.z, 1, 0, 0, 0, 0);
            }
        }
    }

    public static void release(ServerPlayer player, String reason) {
        CompoundTag magic = MagicData.data(player);
        if (!magic.hasUUID(TARGET)) return;
        UUID id = magic.getUUID(TARGET);
        magic.remove(TARGET);
        Entity entity = player.serverLevel().getEntity(id);
        if (entity instanceof Mob mob && mob.getPersistentData().hasUUID(HELD_BY)
            && player.getUUID().equals(mob.getPersistentData().getUUID(HELD_BY)))
            mob.getPersistentData().remove(HELD_BY);
        if (reason != null && !reason.isEmpty()) message(player, reason);
    }

    private static DustParticleOptions particleFor(String color) {
        int rgb = switch (color) {
            case "crimson" -> 0xe34e69;
            case "blue" -> 0x54a6ef;
            case "emerald" -> 0x43bd94;
            case "gold" -> 0xe6b74e;
            case "white" -> 0xe7dfe9;
            case "shadow" -> 0x91829f;
            case "rose" -> 0xed91cb;
            default -> 0xa46af5;
        };
        return new DustParticleOptions(new Vector3f(((rgb >> 16) & 255)/255f,
            ((rgb >> 8) & 255)/255f, (rgb & 255)/255f), 1.15f);
    }

    private static void message(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal("[Eclipse] " + text));
    }
}
