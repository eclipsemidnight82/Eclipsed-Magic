package io.github.eclipsegrimoire.client;

import java.util.ArrayList;
import java.util.List;
import io.github.eclipsegrimoire.MagicData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** Dark-arcane spellbook: grouped spells, live-looking mana/XP bars, tidy coven tools.
 *  Only vanilla GuiGraphics primitives are used; no third-party UI libraries or fonts.
 */
public final class GrimoireScreen extends Screen {
    private enum Page { SPELLS, COVEN, FAMILIARS, SETTINGS }
    private Page page=Page.SPELLS;
    private final String name, startingCoven, invitation;
    private final int level, xp, xpNext, mana, maxMana;
    private String magicColor, uiColor;
    private EditBox nameInput, covenInput, playerInput;
    private final List<SpellHint> hints=new ArrayList<>();
    private static final int WIDTH=400, HEIGHT=250;
    private static final int IVORY=0xffeee0d2, FADED=0xffac9bbb, GOLD=0xffc9a86c;
    private static final String[] COLORS={"purple","crimson","blue","emerald","gold","white","shadow","rose"};
    private record SpellHint(int x,int y,int width,int height,String text) { }

    public GrimoireScreen(ItemStack book) {
        super(Component.literal("The Eclipse Grimoire"));
        CompoundTag tag=book.getTag();
        name=tag!=null&&tag.contains("eclipseName")?tag.getString("eclipseName"):MagicData.DEFAULT_BOOK;
        magicColor=tag!=null&&tag.contains("eclipseMagic")?tag.getString("eclipseMagic"):"purple";
        uiColor=tag!=null&&tag.contains("eclipseUI")?tag.getString("eclipseUI"):"shadow";
        level=tag!=null&&tag.contains("eclipseLevel")?tag.getInt("eclipseLevel"):1;
        xp=tag!=null?tag.getInt("eclipseXp"):0;
        xpNext=tag!=null&&tag.contains("eclipseXpNext")?tag.getInt("eclipseXpNext"):35;
        mana=tag!=null&&tag.contains("eclipseMana")?tag.getInt("eclipseMana"):100;
        maxMana=tag!=null&&tag.contains("eclipseMaxMana")?tag.getInt("eclipseMaxMana"):100;
        startingCoven=tag!=null?tag.getString("eclipseCoven"):"";
        invitation=tag!=null?tag.getString("eclipseInvite"):"";
    }
    private int accent() {return 0xff000000|switch(uiColor) {
        case "purple"->0xa46af5;case "crimson"->0xe34e69;case "blue"->0x54a6ef;
        case "emerald"->0x43bd94;case "gold"->0xe6b74e;case "white"->0xe7dfe9;
        case "rose"->0xed91cb;default->0x80728f;
    };}
    private int magicTint() {return 0xff000000|switch(magicColor) {
        case "crimson"->0xe34e69;case "blue"->0x54a6ef;case "emerald"->0x43bd94;
        case "gold"->0xe6b74e;case "white"->0xe7dfe9;case "shadow"->0x9d8caa;
        case "rose"->0xed91cb;default->0xa46af5;
    };}
    private int left() {return (width-WIDTH)/2;}
    private int top() {return (height-HEIGHT)/2;}

    @Override protected void init() {
        hints.clear();
        int x=left(), y=top();
        Page[] pages=Page.values();
        String[] tabs={"SPELLS","COVEN","FAMILIARS","SETTINGS"};
        for(int i=0;i<pages.length;i++) {
            final Page target=pages[i];
            addRenderableWidget(button(x+12+i*95,y+39,91,18,tabs[i],b->switchPage(target),page==target));
        }
        switch(page) {
            case SPELLS -> initSpells(x,y);
            case COVEN -> initCoven(x,y);
            case FAMILIARS -> {
                addRenderableWidget(button(x+108,y+161,184,23,"BOND MY TAMED PET",b->{
                    command("eclipse familiar bond");close();
                },false));
            }
            case SETTINGS -> initSettings(x,y);
        }
        addRenderableWidget(button(x+323,y+226,65,17,"CLOSE",b->close(),false));
    }
    private void initSpells(int x,int y) {
        int leftX=x+17, rightX=x+208, rowY=y+100, step=20, w=174;
        spellButton("Warding Shield", "ward",8,"Resist damage and protect coven allies",leftX,rowY,w);
        spellButton("Mending Light", "mend",12,"Heal yourself, coven and bonded pets",leftX,rowY+step,w);
        spellButton("Veil of Shadows", "veil",15,"Become invisible and move faster",leftX,rowY+step*2,w);
        spellButton("Salt Circle", "circle",20,"Conjure a ring that blocks outsiders",leftX,rowY+step*3,w);
        spellButton("Infuse Salt", "infuse",8,"Color white salt with your magic",leftX,rowY+step*4,w);
        spellButton("Arcane Tether", "tether",10,"Bind a mob; cast again to release it",leftX,rowY+step*5,w);
        spellButton("Surge of Power", "power",10,"Gain Strength and Speed",rightX,rowY,w);
        spellButton("Chains of Night", "bind",15,"Slow and weaken hostile creatures",rightX,rowY+step,w);
        spellButton("Seal Salt", "seal",12,"Charge connected salt with your magic",rightX,rowY+step*2,w);
        spellButton("Shatter Ward", "shatter",22,"Dispel a targeted connected salt ward",rightX,rowY+step*3,w);
        spellButton("Alzur's Thunder", "thunder",30,"Strike hostile foes with lightning",rightX,rowY+step*4,w);
        spellButton("The Final Aegis", "aegis",40,"Last-resort defensive blast",rightX,rowY+step*5,w);
    }
    private void initCoven(int x,int y) {
        covenInput=new EditBox(font,x+18,y+113,219,20,Component.literal("Coven name"));
        covenInput.setMaxLength(24);covenInput.setHint(Component.literal("Coven name"));
        addRenderableWidget(covenInput);
        addRenderableWidget(button(x+246,y+113,137,20,"CREATE COVEN",b->{
            String value=covenInput.getValue().trim();
            if(value.matches("[a-zA-Z0-9_ -]{2,24}")){command("eclipse coven create "+value);close();}
        },false));
        playerInput=new EditBox(font,x+18,y+151,219,20,Component.literal("Online player username"));
        playerInput.setMaxLength(16);playerInput.setHint(Component.literal("Online player username"));
        addRenderableWidget(playerInput);
        addRenderableWidget(button(x+246,y+151,137,20,"INVITE PLAYER",b->{
            String value=playerInput.getValue().trim();
            if(value.matches("[a-zA-Z0-9_]{3,16}")){command("eclipse coven invite "+value);close();}
        },false));
        addRenderableWidget(button(x+18,y+189,116,20,"JOIN INVITE",b->{command("eclipse coven join");close();},false));
        addRenderableWidget(button(x+143,y+189,116,20,"LEAVE COVEN",b->{command("eclipse coven leave");close();},false));
        addRenderableWidget(button(x+268,y+189,115,20,"COVEN INFO",b->{command("eclipse coven info");close();},false));
    }
    private void initSettings(int x,int y) {
        nameInput=new EditBox(font,x+18,y+112,235,20,Component.literal("Grimoire name"));
        nameInput.setMaxLength(32);nameInput.setValue(name);
        addRenderableWidget(nameInput);
        addRenderableWidget(button(x+260,y+112,123,20,"SAVE NAME",b->{
            command("eclipse rename "+nameInput.getValue());close();
        },false));
        addRenderableWidget(button(x+18,y+177,175,22,"MAGIC: "+magicColor.toUpperCase(),b->{
            magicColor=nextColor(magicColor);command("eclipse color magic "+magicColor);switchPage(Page.SETTINGS);
        },false));
        addRenderableWidget(button(x+206,y+177,177,22,"BOOK: "+uiColor.toUpperCase(),b->{
            uiColor=nextColor(uiColor);command("eclipse color book "+uiColor);switchPage(Page.SETTINGS);
        },false));
    }
    private Button button(int x,int y,int w,int h,String text,Button.OnPress press,boolean selected) {
        return new ArcaneButton(x,y,w,h,Component.literal(text),press,selected);
    }
    private void spellButton(String title,String id,int cost,String details,int x,int y,int width) {
        int needed=MagicData.requiredLevel(id);
        boolean unlocked=level>=needed;
        String caption=title+(unlocked?"  ["+cost+"]":"  [LV "+needed+"]");
        Button b=button(x,y,width,18,caption,clicked->{command("eclipse cast "+id);close();},false);
        b.active=unlocked;
        addRenderableWidget(b);
        hints.add(new SpellHint(x,y,width,18,title+": "+details));
    }
    private String nextColor(String current) {
        for(int i=0;i<COLORS.length;i++) if(COLORS[i].equals(current)) return COLORS[(i+1)%COLORS.length];
        return COLORS[0];
    }
    private void command(String value) {
        if(Minecraft.getInstance().player!=null && Minecraft.getInstance().player.connection!=null)
            Minecraft.getInstance().player.connection.sendCommand(value);
    }
    private void close() {Minecraft.getInstance().setScreen(null);}
    private void switchPage(Page selected) {page=selected;clearWidgets();init();}

    private void frame(GuiGraphics g,int x,int y) {
        int w=WIDTH,h=HEIGHT;
        // Book boards, gilded edging, shadow-black parchment and a pronounced spine.
        g.fill(x-4,y-3,x+w+4,y+h+4,0xb8000000);
        g.fill(x,y,x+w,y+h,0xff120e19);
        g.fill(x+2,y+2,x+w-2,y+h-2,GOLD);
        g.fillGradient(x+4,y+4,x+w-4,y+h-4,0xff271b30,0xff17111f);
        g.fill(x+7,y+7,x+w-7,y+34,0xff1a1323);
        g.fill(x+7,y+32,x+w-7,y+34,accent());
        g.fill(x+8,y+80,x+w-8,y+h-29,0xff231a29);
        g.fill(x+11,y+83,x+w/2-3,y+h-32,0xff2b202f);
        g.fill(x+w/2+3,y+83,x+w-11,y+h-32,0xff291e2e);
        g.fill(x+w/2-2,y+83,x+w/2+2,y+h-32,0xff160e1d);
        g.fill(x+w/2-1,y+84,x+w/2,y+h-33,0xff785c6b);
        // Ornamental corner rivets and eclipse-like medallion.
        for(int px:new int[]{x+9,x+w-11}) for(int py:new int[]{y+9,y+h-11}) {
            g.fill(px,py,px+3,py+3,GOLD);
        }
        int cx=x+22,cy=y+19;
        g.fill(cx-9,cy-1,cx+9,cy+1,GOLD);
        g.fill(cx-1,cy-9,cx+1,cy+9,GOLD);
        g.fill(cx-5,cy-5,cx+5,cy+5,0xff1a1323);
        g.fill(cx-3,cy-3,cx+3,cy+3,accent());
        g.fill(cx-1,cy-3,cx+3,cy+1,0xff1a1323);
        String title=font.plainSubstrByWidth(name,w-120);
        g.drawCenteredString(font,title,x+w/2+15,y+10,IVORY);
        g.drawCenteredString(font,"ARCANA  -  WITCHCRAFT  -  COVEN",x+w/2+15,y+22,FADED);
        g.fill(x+11,y+61,x+w-11,y+76,0xff180f20);
        g.drawString(font,"LV "+level+"    XP "+xp+(xpNext==0?" / MAX":" / "+xpNext),x+17,y+63,IVORY);
        g.drawString(font,"MANA  "+mana+" / "+maxMana,x+w-121,y+63,IVORY);
        int middle=x+w/2;
        g.fill(x+17,y+74,middle-9,y+77,0xff3f3248);
        g.fill(x+17,y+74,x+17+(int)((w/2-26)*(xpNext==0?1.0:Math.min(1.0,(double)xp/Math.max(1,xpNext)))),y+77,GOLD);
        g.fill(middle+9,y+74,x+w-17,y+77,0xff3f3248);
        g.fill(middle+9,y+74,middle+9+(int)((w/2-26)*(double)Math.max(0,mana)/Math.max(1,maxMana)),y+77,magicTint());
        g.fill(x+9,y+h-27,x+w-9,y+h-26,0xff876c77);
    }
    private void label(GuiGraphics g,String text,int x,int y,int color) {g.drawString(font,text,x,y,color);}
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial) {
        renderBackground(g);
        int x=left(),y=top();
        frame(g,x,y);
        switch(page) {
            case SPELLS -> {
                label(g,"PROTECTION & UTILITY",x+20,y+87,GOLD);
                label(g,"POWER & COUNTERSPELLS",x+211,y+87,GOLD);
                String tip="Hover over a spell for details  |  Hold G for the spell wheel";
                for(SpellHint hint:hints) if(mouseX>=hint.x && mouseX<hint.x+hint.width
                    && mouseY>=hint.y && mouseY<hint.y+hint.height) {tip=hint.text;break;}
                label(g,font.plainSubstrByWidth(tip,306),x+15,y+229,FADED);
            }
            case COVEN -> {
                label(g,"YOUR COVEN",x+18,y+90,GOLD);
                label(g,font.plainSubstrByWidth(startingCoven.isEmpty()?"None - Create one below":startingCoven,255),x+93,y+90,IVORY);
                label(g,"CREATE A COVEN",x+19,y+102,FADED);
                label(g,"INVITE AN ONLINE PLAYER",x+19,y+140,FADED);
                label(g,"PENDING: "+font.plainSubstrByWidth(invitation.isEmpty()?"None":invitation,265),x+18,y+218,FADED);
            }
            case FAMILIARS -> {
                label(g,"THE FAMILIAR BOND",x+31,y+100,GOLD);
                label(g,"Your companion is part of your magic.",x+31,y+116,IVORY);
                label(g,"Tame an animal and look directly at it",x+31,y+133,FADED);
                label(g,"before using the bond below.",x+31,y+144,FADED);
                label(g,"Bonded pets are protected from your spells.",x+31,y+197,FADED);
                label(g,"Arcane Tether works on wild and hostile mobs, too.",x+20,y+218,FADED);
            }
            case SETTINGS -> {
                label(g,"NAME YOUR GRIMOIRE",x+19,y+99,GOLD);
                label(g,"MAGICAL SIGNATURE",x+19,y+147,GOLD);
                g.fill(x+19,y+161,x+190,y+168,magicTint());
                g.fill(x+207,y+161,x+381,y+168,accent());
                label(g,"Your magic color sets spell and tether particles.",x+19,y+207,FADED);
                label(g,"Your book color sets the borders and accents.",x+19,y+218,FADED);
            }
        }
        super.render(g,mouseX,mouseY,partial);
    }

    /** Custom button skin, preserving vanilla focus, keyboard interaction and narration. */
    private final class ArcaneButton extends Button {
        private final boolean selected;
        private ArcaneButton(int x,int y,int w,int h,Component title,OnPress action,boolean selected) {
            super(x,y,w,h,title,action,Button.DEFAULT_NARRATION);
            this.selected=selected;
        }
        @Override protected void renderWidget(GuiGraphics g,int mouseX,int mouseY,float partial) {
            int x=getX(),y=getY(),w=width,h=height;
            boolean hover=isHoveredOrFocused();
            int fill=!active?0xff211b25:(selected?0xff42304d:(hover?0xff46334f:0xff302437));
            int edge=!active?0xff54485a:(selected||hover?accent():0xff6e586c);
            g.fill(x,y,x+w,y+h,edge);
            g.fill(x+1,y+1,x+w-1,y+h-1,fill);
            if(selected) g.fill(x+2,y+h-3,x+w-2,y+h-1,magicTint());
            String text=font.plainSubstrByWidth(getMessage().getString(),w-9);
            g.drawCenteredString(font,text,x+w/2,y+(h-8)/2,active?IVORY:0xff887b8e);
        }
    }
    @Override public boolean isPauseScreen() {return false;}
}
