# In-game checklist — Alpha 0.11.2

- [ ] Game launches and version shows 0.11.2-alpha.
- [ ] Place a fresh Scrying Crystal, bind three different player/mob blood taglocks, and see all three saved in the registry.
- [ ] Offer duplicate blood and verify it updates, not duplicates, the person.
- [ ] Try View on a tracked player; confirm the true first-person view and Escape exit.
- [ ] Select a player, click Remove once; verify the person is **still listed**. Click Confirm; verify only that entry disappears.
- [ ] Bind them again with new blood; verify they appear normally.
- [ ] Save/reload the world and verify crystal lists persist.
- [ ] Kill a bound regular mob; verify it disappears from that crystal list.
- [ ] Temporarily unload a bound creature without killing it; verify its entry stays with NOT LOADED.
- [ ] Have a bound player die and respawn; verify their registry entry remains and vision works after respawn if tracked.
- [ ] Test multiple crystals with different targets; removing from one crystal must not alter another crystal's registry.
- [ ] Break one crystal; verify its own registry is destroyed without removing records from other crystals.
- [ ] Bind a tamed animal as a familiar; in the grimoire click Cast Away then Confirm. Verify it remains alive/tamed but leaves the grimoire roster.
- [ ] Ensure protected poppets, chalice immortality, older spells, runes, and all pages still work.
