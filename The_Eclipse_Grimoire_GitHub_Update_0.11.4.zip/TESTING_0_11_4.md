# Alpha 0.11.4 — In-game Visual Test

1. Back up the world and keep the working 0.11.3 JAR.
2. Install only the newly compiled 0.11.4 JAR for the mod in a Forge 1.20.1 test profile.
3. Spawn a Witch’s Bell from the Creative Inventory. It should have the same black/metal/purple 3D look in inventory and when placed, with **no black-magenta checkerboard**.
4. Collect blood with an empty Taglock Vial. The needle, cap and glass outline should not move or change shape; only the liquid region fills red.
5. Check that the chalice’s liquid, crystal translucency, poppet state icons, scrying registry, and normal spells still work.
6. Test once in multiplayer before release.
