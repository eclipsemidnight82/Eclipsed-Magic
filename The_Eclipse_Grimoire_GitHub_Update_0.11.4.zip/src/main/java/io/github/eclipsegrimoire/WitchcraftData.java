package io.github.eclipsegrimoire;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Dimension-local persistent owners of the physical Wardstones and Witch Bells. */
public final class WitchcraftData extends SavedData {
    private final Map<Long,UUID> stones=new HashMap<>(),bells=new HashMap<>(),armedRunes=new HashMap<>();
    private final Map<Long,Long> muted=new HashMap<>();
    private final Map<Long,Long> lastBell=new HashMap<>();
    public static WitchcraftData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(WitchcraftData::load,WitchcraftData::new,"eclipse_witchcraft_items");
    }
    private static WitchcraftData load(CompoundTag nbt) {
        WitchcraftData result=new WitchcraftData();
        read(nbt.getList("stones",Tag.TAG_COMPOUND),result.stones);
        read(nbt.getList("bells",Tag.TAG_COMPOUND),result.bells);
        read(nbt.getList("armedRunes",Tag.TAG_COMPOUND),result.armedRunes);
        return result;
    }
    private static void read(ListTag list,Map<Long,UUID> destination) {
        for(Tag element:list) {
            CompoundTag t=(CompoundTag)element;
            if(t.hasUUID("owner")) destination.put(t.getLong("pos"),t.getUUID("owner"));
        }
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.put("stones",write(stones));tag.put("bells",write(bells));tag.put("armedRunes",write(armedRunes));return tag;
    }
    private static ListTag write(Map<Long,UUID> map) {
        ListTag result=new ListTag();
        map.forEach((pos,owner)->{CompoundTag t=new CompoundTag();t.putLong("pos",pos);t.putUUID("owner",owner);result.add(t);});
        return result;
    }
    private Map<Long,UUID> map(MagicDecorBlock.Kind kind) {
        return kind==MagicDecorBlock.Kind.WARDSTONE?stones:bells;
    }
    public void bind(BlockPos pos,MagicDecorBlock.Kind kind,UUID owner) {
        map(kind).put(pos.asLong(),owner);setDirty();
    }
    public void remove(BlockPos pos) {
        long key=pos.asLong();
        boolean changed=stones.remove(key)!=null;changed=bells.remove(key)!=null || changed;
        changed=armedRunes.remove(key)!=null || changed;if(changed) setDirty();
        muted.remove(key);lastBell.remove(key);
    }
    public void armRune(BlockPos pos,UUID owner) {armedRunes.put(pos.asLong(),owner);setDirty();}
    public void disarmRune(BlockPos pos) {if(armedRunes.remove(pos.asLong())!=null)setDirty();}
    public Map<Long,UUID> armedRunes(){return Map.copyOf(armedRunes);}
    public UUID owner(BlockPos pos,MagicDecorBlock.Kind kind) {return map(kind).get(pos.asLong());}
    public Map<Long,UUID> wardstones(){return Map.copyOf(stones);}
    public Map<Long,UUID> bells(){return Map.copyOf(bells);}
    public void suppress(BlockPos pos,long untilTick){muted.put(pos.asLong(),untilTick);}
    public boolean suppressed(BlockPos pos,long tick){return muted.getOrDefault(pos.asLong(),0L)>tick;}
    public boolean readyToRing(BlockPos pos,long tick) {
        long k=pos.asLong();
        if(lastBell.getOrDefault(k,-10000L)+100>tick) return false;
        lastBell.put(k,tick);return true;
    }
}
