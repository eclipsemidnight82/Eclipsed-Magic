package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Vector3f;

/** Lightweight physical witchcraft furniture with no ticking block entities. */
public final class MagicDecorBlock extends Block {
    public enum Kind { CANDLE, BRAZIER, RUNE, WARDSTONE, BELL }
    private static final VoxelShape CANDLE=Block.box(6,0,6,10,11,10);
    private static final VoxelShape BRAZIER=Block.box(3,0,3,13,11,13);
    private static final VoxelShape RUNE=Block.box(1,0,1,15,0.3,15);
    private static final VoxelShape STONE=Block.box(4,0,4,12,15,12);
    private static final VoxelShape BELL=Block.box(3,0,3,13,13,13);
    private final Kind kind;
    private final String color;

    public MagicDecorBlock(Kind kind,String color,BlockBehaviour.Properties properties) {
        super(properties);
        this.kind=kind;
        this.color=color;
    }
    public Kind kind(){return kind;}
    public String color(){return color;}
    @Override public VoxelShape getShape(BlockState state,BlockGetter level,BlockPos pos,CollisionContext ctx) {
        return switch(kind){case CANDLE->CANDLE;case BRAZIER->BRAZIER;case RUNE->RUNE;case WARDSTONE->STONE;case BELL->BELL;};
    }
    @Override public void animateTick(BlockState state,Level level,BlockPos pos,RandomSource random) {
        if(kind==Kind.BELL) return;
        if(random.nextInt(kind==Kind.RUNE?7:3)!=0) return;
        int rgb=WitchcraftSpells.rgb(color);
        float r=((rgb>>16)&255)/255f,g=((rgb>>8)&255)/255f,b=(rgb&255)/255f;
        double y=pos.getY()+(kind==Kind.BRAZIER?.85:kind==Kind.WARDSTONE?.95:kind==Kind.RUNE?.04:.76);
        double x=pos.getX()+.5+(random.nextDouble()-.5)*.17;
        double z=pos.getZ()+.5+(random.nextDouble()-.5)*.17;
        level.addParticle(new DustParticleOptions(new Vector3f(r,g,b),kind==Kind.BRAZIER?1.55f:.95f),x,y,z,0,.025,0);
        if(kind==Kind.CANDLE || kind==Kind.BRAZIER) {
            level.addParticle(ParticleTypes.FLAME,x,y,z,0,.025,0);
            if(random.nextInt(7)==0) level.addParticle(ParticleTypes.SMOKE,x,y+.05,z,0,.025,0);
        }
        if(kind==Kind.WARDSTONE && random.nextInt(5)==0)
            level.addParticle(ParticleTypes.ENCHANT,x,y,z,0,.05,0);
    }
    @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,
                                           InteractionHand hand,BlockHitResult hit) {
        if(kind==Kind.BELL) {
            if(!level.isClientSide()) {
                level.playSound(null,pos,SoundEvents.BELL_BLOCK,SoundSource.BLOCKS,1.2f,1.08f);
                player.displayClientMessage(Component.literal("[Eclipse] The Witch's Bell rings."),true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide());
        }
        if(kind==Kind.WARDSTONE && !level.isClientSide()) {
            WitchcraftData data=WitchcraftData.get((net.minecraft.server.level.ServerLevel)level);
            java.util.UUID owner=data.owner(pos,Kind.WARDSTONE);
            if(owner==null && player instanceof net.minecraft.server.level.ServerPlayer server) {
                data.bind(pos,Kind.WARDSTONE,server.getUUID()); owner=server.getUUID();
            }
            player.displayClientMessage(Component.literal(owner!=null && owner.equals(player.getUUID())
                ?"[Eclipse] Your Wardstone guards this place."
                :"[Eclipse] This Wardstone belongs to another witch."),true);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }
}
