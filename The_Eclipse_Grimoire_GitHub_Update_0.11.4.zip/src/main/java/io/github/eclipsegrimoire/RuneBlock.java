package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** One block ID per magic color, eight independently modeled rune states per color. */
public final class RuneBlock extends Block {
    public static final EnumProperty<RunePattern> PATTERN=EnumProperty.create("pattern",RunePattern.class);
    private static final VoxelShape THIN=Block.box(1,0,1,15,.3,15);
    private final String color;
    public RuneBlock(String color,BlockBehaviour.Properties properties) {
        super(properties);
        this.color=color;
        registerDefaultState(stateDefinition.any().setValue(PATTERN,RunePattern.MOON));
    }
    public String color(){return color;}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b) {b.add(PATTERN);}
    @Override public VoxelShape getShape(BlockState s,BlockGetter level,BlockPos pos,CollisionContext c) {return THIN;}
    @Override public boolean canSurvive(BlockState state,net.minecraft.world.level.LevelReader level,BlockPos pos) {
        return level.getBlockState(pos.below()).isFaceSturdy(level,pos.below(),Direction.UP);
    }
    @Override public void neighborChanged(BlockState s,Level level,BlockPos pos,Block block,BlockPos from,boolean moving) {
        if(!s.canSurvive(level,pos)) level.destroyBlock(pos,false);
    }
    @Override public void animateTick(BlockState s,Level level,BlockPos pos,RandomSource rand) {
        if(rand.nextInt(s.getValue(PATTERN)==RunePattern.BINDING?4:9)!=0) return;
        int c=ArcaneEffects.rgb(color);
        level.addParticle(ArcaneEffects.dust(color,.8f),pos.getX()+.15+rand.nextDouble()*.7,
            pos.getY()+.04,pos.getZ()+.15+rand.nextDouble()*.7,0,.018,0);
    }
}
