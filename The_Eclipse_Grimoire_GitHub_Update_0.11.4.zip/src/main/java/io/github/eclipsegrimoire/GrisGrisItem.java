package io.github.eclipsegrimoire;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Passive protective charm carried in the inventory: one hex blocked per minute. */
public final class GrisGrisItem extends Item {
    public GrisGrisItem(Properties properties){super(properties);}
}
