package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** One-poppet display shelf backed by SavedData, so wards work in unloaded chunks. */
public final class PoppetShelfBlock extends Block {
    public static final BooleanProperty OCCUPIED=BooleanProperty.create("occupied");
    private static final VoxelShape SHAPE=Block.box(1,0,1,15,8,15);
    public PoppetShelfBlock(BlockBehaviour.Properties props){super(props);registerDefaultState(stateDefinition.any().setValue(OCCUPIED,false));}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(OCCUPIED);}
    @Override public VoxelShape getShape(BlockState s,BlockGetter g,BlockPos p,CollisionContext c){return SHAPE;}
    @Override public InteractionResult use(BlockState state,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){
        if(level.isClientSide())return InteractionResult.SUCCESS;
        if(!(player instanceof ServerPlayer witch))return InteractionResult.PASS;
        ServerLevel server=(ServerLevel)level;BloodRelicsData data=BloodRelicsData.get(server);
        ItemStack existing=data.shelf(server,pos),held=witch.getItemInHand(hand);
        if(!existing.isEmpty()&&player.isShiftKeyDown()&&held.isEmpty()) {
            data.removeShelf(server,pos);server.setBlock(pos,state.setValue(OCCUPIED,false),3);
            if(!player.getInventory().add(existing))player.drop(existing,false);
            witch.sendSystemMessage(Component.literal("[Eclipse] The poppet has been retrieved from the shelf."));
        } else if(existing.isEmpty()&&held.is(EclipseMod.POPPET.get())&&held.hasTag()&&held.getTag().hasUUID("Target")) {
            ItemStack stored=held.copy();stored.setCount(1);data.setShelf(server,pos,stored);
            if(!witch.isCreative())held.shrink(1);
            server.setBlock(pos,state.setValue(OCCUPIED,true),3);
            witch.sendSystemMessage(Component.literal("[Eclipse] Displaying the poppet bound to "+stored.getTag().getString("Name")+"."));
        } else witch.sendSystemMessage(Component.literal(existing.isEmpty()?"[Eclipse] Hold a bound poppet to display it on the shelf.":
            "[Eclipse] Shelf holds a poppet bound to "+existing.getTag().getString("Name")+". Sneak-use with an empty hand to retrieve it."));
        return InteractionResult.CONSUME;
    }
    @Override public void onRemove(BlockState old,Level level,BlockPos pos,BlockState next,boolean moved){
        if(!old.is(next.getBlock())&&level instanceof ServerLevel server){
            ItemStack stored=BloodRelicsData.get(server).removeShelf(server,pos);
            if(!stored.isEmpty())Block.popResource(server,pos,stored);
        }
        super.onRemove(old,level,pos,next,moved);
    }
}
