package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** A one-pet charm: bind your own tamed familiar, inspect its location, or recall it if loaded. */
public final class FamiliarCharmItem extends Item {
    public FamiliarCharmItem(Properties props){super(props);}
    @Override public InteractionResult interactLivingEntity(ItemStack stack,Player player,LivingEntity living,InteractionHand hand) {
        if(!(living instanceof TamableAnimal pet) || !pet.isTame()) return InteractionResult.PASS;
        if(!player.getUUID().equals(pet.getOwnerUUID())) {
            if(!player.level().isClientSide()) player.displayClientMessage(Component.literal("[Eclipse] You can bind only your own tame familiar."),true);
            return InteractionResult.FAIL;
        }
        if(player instanceof ServerPlayer witch) {
            if(stack.getOrCreateTag().hasUUID("EclipseFamiliar") && !witch.isShiftKeyDown()) {
                witch.sendSystemMessage(Component.literal("[Eclipse] Sneak-right-click a different familiar to rebind this charm."));
                return InteractionResult.CONSUME;
            }
            stack.getOrCreateTag().putUUID("EclipseFamiliar",pet.getUUID());
            stack.getOrCreateTag().putUUID("EclipseFamiliarOwner",witch.getUUID());
            stack.getOrCreateTag().putString("EclipseFamiliarName",pet.getName().getString());
            pet.getPersistentData().putUUID("EclipseFamiliarOwner",witch.getUUID());
            MagicData.registerFamiliar(witch,pet);
            MagicData.refreshBooks(witch);
            witch.sendSystemMessage(Component.literal("[Eclipse] Familiar Charm bound to "+pet.getName().getString()+". Right-click in air to locate; sneak-right-click to recall."));
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide());
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
        ItemStack held=player.getItemInHand(hand);
        if(player instanceof ServerPlayer witch) {
            if(held.getTag()==null || !held.getTag().hasUUID("EclipseFamiliar") ||
                !witch.getUUID().equals(held.getTag().getUUID("EclipseFamiliarOwner"))) {
                witch.sendSystemMessage(Component.literal("[Eclipse] Right-click your own tamed pet with this charm to bind it."));
                return InteractionResultHolder.fail(held);
            }
            Entity entity=witch.serverLevel().getEntity(held.getTag().getUUID("EclipseFamiliar"));
            if(!(entity instanceof TamableAnimal pet) || !pet.isAlive() || !pet.isTame() ||
                !witch.getUUID().equals(pet.getOwnerUUID())) {
                witch.sendSystemMessage(Component.literal("[Eclipse] "+held.getTag().getString("EclipseFamiliarName")
                    +" is not currently loaded in this dimension. Its bond is safe; no teleport attempted."));
                return InteractionResultHolder.success(held);
            }
            if(!MagicData.hasFamiliar(witch,pet.getUUID()) ||
                !pet.getPersistentData().hasUUID("EclipseFamiliarOwner") ||
                !witch.getUUID().equals(pet.getPersistentData().getUUID("EclipseFamiliarOwner"))){
                witch.sendSystemMessage(Component.literal("[Eclipse] This pet is no longer bound. Rebind it with the charm first."));
                return InteractionResultHolder.fail(held);
            }
            if(!witch.isShiftKeyDown()) {
                witch.sendSystemMessage(Component.literal("[Eclipse] "+pet.getName().getString()+": "
                    +(int)witch.distanceTo(pet)+" blocks away, health "+(int)pet.getHealth()+". Sneak-use to recall."));
                return InteractionResultHolder.success(held);
            }
            if(witch.distanceToSqr(pet)>128*128) {
                witch.sendSystemMessage(Component.literal("[Eclipse] Familiar must be loaded within 128 blocks to recall safely."));
                return InteractionResultHolder.fail(held);
            }
            for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++) {
                BlockPos feet=witch.blockPosition().offset(dx,0,dz);
                if(!witch.serverLevel().hasChunkAt(feet) || !witch.serverLevel().getBlockState(feet).isAir() ||
                   !witch.serverLevel().getBlockState(feet.above()).isAir() ||
                   !witch.serverLevel().getBlockState(feet.below()).isFaceSturdy(level,feet.below(),Direction.UP)) continue;
                Vec3 dest=new Vec3(feet.getX()+.5,feet.getY(),feet.getZ()+.5);
                AABB moved=pet.getBoundingBox().move(dest.subtract(pet.position()));
                if(!level.noCollision(pet,moved)) continue;
                pet.teleportTo(dest.x,dest.y,dest.z);
                pet.setDeltaMovement(Vec3.ZERO);pet.fallDistance=0;
                witch.sendSystemMessage(Component.literal("[Eclipse] Familiar recalled: "+pet.getName().getString()));
                return InteractionResultHolder.success(held);
            }
            witch.sendSystemMessage(Component.literal("[Eclipse] No safe nearby landing space for your familiar."));
            return InteractionResultHolder.fail(held);
        }
        return InteractionResultHolder.sidedSuccess(held,level.isClientSide());
    }
}
