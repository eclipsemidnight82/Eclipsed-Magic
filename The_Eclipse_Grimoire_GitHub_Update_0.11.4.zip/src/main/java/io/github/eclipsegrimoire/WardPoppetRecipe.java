package io.github.eclipsegrimoire;

import net.minecraft.core.RegistryAccess;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** Craft golden apple + linked poppet: one-life protective ward for the named donor. */
public final class WardPoppetRecipe extends CustomRecipe {
    public WardPoppetRecipe(net.minecraft.resources.ResourceLocation id, CraftingBookCategory category){super(id,category);}
    @Override public boolean matches(CraftingContainer inv,Level level){
        int bound=0,apple=0;
        for(int i=0;i<inv.getContainerSize();i++){
            ItemStack s=inv.getItem(i);if(s.isEmpty())continue;
            if(s.is(Items.GOLDEN_APPLE))apple++;
            else if(s.is(EclipseMod.POPPET.get()) && s.hasTag() && s.getTag().hasUUID("Target"))bound++;
            else return false;
        }
        return bound==1&&apple==1;
    }
    @Override public ItemStack assemble(CraftingContainer inv,RegistryAccess access){
        for(int i=0;i<inv.getContainerSize();i++){
            ItemStack s=inv.getItem(i);
            if(s.is(EclipseMod.POPPET.get())&&s.hasTag()&&s.getTag().hasUUID("Target")){
                ItemStack charged=s.copy();charged.setCount(1);charged.getOrCreateTag().putInt("WardCharge",1);return charged;
            }
        }
        return ItemStack.EMPTY;
    }
    @Override public boolean canCraftInDimensions(int w,int h){return w*h>=2;}
    @Override public RecipeSerializer<?> getSerializer(){return EclipseMod.WARD_POPPET_RECIPE.get();}
}
