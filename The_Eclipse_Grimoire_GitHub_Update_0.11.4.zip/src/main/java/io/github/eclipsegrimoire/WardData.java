package io.github.eclipsegrimoire;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.phys.AABB;

/** Persistent ownership for ground salt, colored door wards, and full doorway seals. */
public final class WardData extends SavedData {
    private final Map<Long,UUID> chargedSalt=new HashMap<>();
    private final Map<Long,UUID> saltedDoors=new HashMap<>();
    private final Map<Long,String> doorColors=new HashMap<>();
    private final Set<Long> absoluteDoors=new HashSet<>();
    private final Map<Long,OpeningSeal> openings=new HashMap<>();
    public static final int MAX_NETWORK=512, MAX_OPENINGS=128;

    /** start points to the actual door bottom, or to the salt at an empty threshold. */
    public record OpeningSeal(BlockPos start, Direction.Axis widthAxis, int width, UUID owner,
                              String color, boolean door) {
        public AABB area() {
            int dx=widthAxis==Direction.Axis.X?width:1;
            int dz=widthAxis==Direction.Axis.Z?width:1;
            int y=start.getY()+(door?0:1);
            return new AABB(start.getX(),y,start.getZ(),start.getX()+dx,y+2,start.getZ()+dz);
        }
        public BlockPos tile(int n) {
            return start.relative(widthAxis==Direction.Axis.X?Direction.EAST:Direction.SOUTH,n);
        }
    }
    public static WardData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(WardData::load,WardData::new,"eclipse_salt_wards");
    }
    private static WardData load(CompoundTag tag) {
        WardData data=new WardData();
        for(Tag e:tag.getList("charged",Tag.TAG_COMPOUND)) {
            CompoundTag t=(CompoundTag)e;
            if(t.hasUUID("owner")) data.chargedSalt.put(t.getLong("pos"),t.getUUID("owner"));
        }
        for(Tag e:tag.getList("doors",Tag.TAG_COMPOUND)) {
            CompoundTag t=(CompoundTag)e;
            if(!t.hasUUID("owner")) continue;
            long key=t.getLong("pos");
            data.saltedDoors.put(key,t.getUUID("owner"));
            if(t.contains("color",Tag.TAG_STRING)) data.doorColors.put(key,t.getString("color"));
            if(t.getBoolean("absolute")) data.absoluteDoors.add(key);
        }
        for(Tag e:tag.getList("openings",Tag.TAG_COMPOUND)) {
            CompoundTag t=(CompoundTag)e;
            if(!t.hasUUID("owner") || !t.contains("pos",Tag.TAG_LONG)) continue;
            int width=t.getInt("width");
            if(width<1 || width>3) continue;
            BlockPos start=BlockPos.of(t.getLong("pos"));
            Direction.Axis axis=t.getBoolean("alongX")?Direction.Axis.X:Direction.Axis.Z;
            data.openings.put(start.asLong(),new OpeningSeal(start,axis,width,t.getUUID("owner"),t.getString("color"),false));
        }
        return data;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        tag.put("charged",encode(chargedSalt));
        ListTag doors=new ListTag();
        saltedDoors.forEach((pos,owner)->{
            CompoundTag t=new CompoundTag();t.putLong("pos",pos);t.putUUID("owner",owner);
            t.putString("color",doorColors.getOrDefault(pos,"white"));
            t.putBoolean("absolute",absoluteDoors.contains(pos));doors.add(t);
        });
        tag.put("doors",doors);
        ListTag empty=new ListTag();
        openings.values().forEach(o->{
            CompoundTag t=new CompoundTag();t.putLong("pos",o.start().asLong());
            t.putUUID("owner",o.owner());t.putInt("width",o.width());
            t.putBoolean("alongX",o.widthAxis()==Direction.Axis.X);t.putString("color",o.color());empty.add(t);
        });
        tag.put("openings",empty);
        return tag;
    }
    private static ListTag encode(Map<Long,UUID> source) {
        ListTag all=new ListTag();
        source.forEach((pos,owner)->{CompoundTag t=new CompoundTag();t.putLong("pos",pos);t.putUUID("owner",owner);all.add(t);});
        return all;
    }
    public static Set<BlockPos> connectedSalt(ServerLevel level,BlockPos start) {
        if(!level.hasChunkAt(start) || !EclipseMod.isSalt(level.getBlockState(start))) return Set.of();
        Set<BlockPos> found=new HashSet<>();
        ArrayDeque<BlockPos> queue=new ArrayDeque<>();queue.add(start);
        while(!queue.isEmpty()) {
            BlockPos p=queue.removeFirst();
            if(found.contains(p)) continue;
            if(!level.hasChunkAt(p) || !EclipseMod.isSalt(level.getBlockState(p))) continue;
            found.add(p);
            if(found.size()>MAX_NETWORK) return Set.of();
            for(Direction d:Direction.Plane.HORIZONTAL) queue.addLast(p.relative(d));
        }
        return found;
    }
    public int enchantNetwork(Set<BlockPos> network,UUID caster) {
        if(network.isEmpty() || network.size()>MAX_NETWORK) return 0;
        for(BlockPos p:network) chargedSalt.put(p.asLong(),caster);
        setDirty();return network.size();
    }
    public int shatterNetwork(Set<BlockPos> network) {
        int removed=0;
        for(BlockPos p:network) if(chargedSalt.remove(p.asLong())!=null) removed++;
        if(removed>0) setDirty();return removed;
    }
    public int enchantCircle(Set<BlockPos> positions,UUID caster) {return enchantNetwork(positions,caster);}
    public UUID chargedOwner(ServerLevel level,BlockPos p) {
        UUID owner=chargedSalt.get(p.asLong());
        if(owner==null) return null;
        if(EclipseMod.isSalt(level.getBlockState(p))) return owner;
        chargedSalt.remove(p.asLong());setDirty();return null;
    }
    public static BlockPos doorBase(ServerLevel level,BlockPos pos) {
        BlockState state=level.getBlockState(pos);
        if(!(state.getBlock() instanceof DoorBlock)) return null;
        return state.getValue(DoorBlock.HALF)==DoubleBlockHalf.UPPER?pos.below():pos;
    }
    public UUID doorOwner(ServerLevel level,BlockPos pos) {
        BlockPos base=doorBase(level,pos);
        return base==null?null:saltedDoors.get(base.asLong());
    }
    public String doorColor(ServerLevel level,BlockPos pos) {
        BlockPos base=doorBase(level,pos);
        return base==null?"white":doorColors.getOrDefault(base.asLong(),"white");
    }
    public boolean saltDoor(ServerLevel level,BlockPos pos,UUID owner) {
        return saltDoor(level,pos,owner,"white");
    }
    public boolean saltDoor(ServerLevel level,BlockPos pos,UUID owner,String color) {
        BlockPos base=doorBase(level,pos);
        if(base==null || saltedDoors.containsKey(base.asLong())) return false;
        saltedDoors.put(base.asLong(),owner);doorColors.put(base.asLong(),color);setDirty();return true;
    }
    public boolean isAbsoluteDoor(ServerLevel level,BlockPos pos) {
        BlockPos base=doorBase(level,pos);
        return base!=null && absoluteDoors.contains(base.asLong());
    }
    /** Only the owner (or a server operator) can upgrade their own door to total lockdown. */
    public boolean makeAbsoluteDoor(ServerLevel level,BlockPos pos,UUID player,boolean op) {
        BlockPos base=doorBase(level,pos);
        if(base==null) return false;
        UUID owner=saltedDoors.get(base.asLong());
        if(owner==null || (!op && !owner.equals(player)) || absoluteDoors.contains(base.asLong())) return false;
        absoluteDoors.add(base.asLong());setDirty();return true;
    }
    public boolean shatterDoor(ServerLevel level,BlockPos pos) {
        BlockPos base=doorBase(level,pos);
        if(base==null || saltedDoors.remove(base.asLong())==null) return false;
        doorColors.remove(base.asLong());absoluteDoors.remove(base.asLong());setDirty();return true;
    }
    public boolean clearDoor(ServerLevel level,BlockPos pos,UUID player,boolean operator) {
        BlockPos base=doorBase(level,pos);
        if(base==null) return false;
        UUID owner=saltedDoors.get(base.asLong());
        if(owner==null || (!operator && !owner.equals(player))) return false;
        saltedDoors.remove(base.asLong());doorColors.remove(base.asLong());absoluteDoors.remove(base.asLong());
        setDirty();return true;
    }
    public void broken(ServerLevel level,BlockPos pos) {
        if(chargedSalt.remove(pos.asLong())!=null) setDirty();
        // Note that BlockEvent.BreakEvent fires before the vanilla door block is removed.
        BlockPos base=doorBase(level,pos);
        if(base!=null && saltedDoors.remove(base.asLong())!=null) {
            doorColors.remove(base.asLong());absoluteDoors.remove(base.asLong());setDirty();
        }
        if(removeOpeningAt(pos)) setDirty();
    }
    /** Find a salt-lined frame 1-3 blocks wide, two blocks tall, with side pillars and a lintel. */
    public static OpeningSeal findEmptyFrame(ServerLevel level,BlockPos targeted,UUID caster,String color) {
        for(Direction.Axis axis:List.of(Direction.Axis.X,Direction.Axis.Z)) {
            Direction positive=axis==Direction.Axis.X?Direction.EAST:Direction.SOUTH;
            Direction negative=positive.getOpposite();
            for(int width=1;width<=3;width++) for(int index=0;index<width;index++) {
                BlockPos start=targeted.relative(negative,index);
                BlockPos before=start.relative(negative);
                BlockPos after=start.relative(positive,width);
                if(!solidPair(level,before) || !solidPair(level,after)) continue;
                boolean okay=true;
                for(int i=0;i<width;i++) {
                    BlockPos salt=start.relative(positive,i);
                    if(!level.hasChunkAt(salt) || !EclipseMod.isSalt(level.getBlockState(salt))
                        || !caster.equals(WardData.get(level).chargedOwner(level,salt))
                        || !level.getBlockState(salt.above()).isAir()
                        || !level.getBlockState(salt.above(2)).isAir()
                        || !level.getBlockState(salt.above(3)).isCollisionShapeFullBlock(level,salt.above(3))) {
                        okay=false;break;
                    }
                }
                if(okay) return new OpeningSeal(start,axis,width,caster,color,false);
            }
        }
        return null;
    }
    private static boolean solidPair(ServerLevel level,BlockPos pos) {
        return level.hasChunkAt(pos) && level.getBlockState(pos.above()).isCollisionShapeFullBlock(level,pos.above())
            && level.getBlockState(pos.above(2)).isCollisionShapeFullBlock(level,pos.above(2));
    }
    public boolean sealEmpty(OpeningSeal seal) {
        if(seal==null || openings.size()>=MAX_OPENINGS) return false;
        for(OpeningSeal current:openings.values()) if(current.area().intersects(seal.area())) return false;
        openings.put(seal.start().asLong(),seal);setDirty();return true;
    }
    public OpeningSeal openingAt(BlockPos target) {
        for(OpeningSeal seal:openings.values()) {
            for(int i=0;i<seal.width();i++) if(seal.tile(i).equals(target)) return seal;
        }
        return null;
    }
    public boolean removeOpeningAt(BlockPos target) {
        OpeningSeal seal=openingAt(target);
        if(seal==null) return false;
        openings.remove(seal.start().asLong());setDirty();return true;
    }
    public List<OpeningSeal> activeSeals(ServerLevel level) {
        List<OpeningSeal> all=new ArrayList<>();
        // Clean broken door/threshold protection after chunk loading, without forcing chunks to load.
        var doorIterator=absoluteDoors.iterator();
        while(doorIterator.hasNext()) {
            long key=doorIterator.next();BlockPos base=BlockPos.of(key);
            if(!level.hasChunkAt(base)) continue;
            BlockState state=level.getBlockState(base);
            if(!(state.getBlock() instanceof DoorBlock) || !saltedDoors.containsKey(key)) {
                doorIterator.remove();saltedDoors.remove(key);doorColors.remove(key);setDirty();continue;
            }
            Direction facing=state.getValue(DoorBlock.FACING);
            Direction.Axis axis=facing.getAxis()==Direction.Axis.Z?Direction.Axis.X:Direction.Axis.Z;
            all.add(new OpeningSeal(base,axis,1,saltedDoors.get(key),doorColors.getOrDefault(key,"white"),true));
        }
        var iterator=openings.values().iterator();
        while(iterator.hasNext()) {
            OpeningSeal seal=iterator.next();
            if(!level.hasChunkAt(seal.start())) continue;
            boolean okay=true;
            for(int i=0;i<seal.width();i++) {
                BlockPos salt=seal.tile(i);
                if(!level.hasChunkAt(salt) || !EclipseMod.isSalt(level.getBlockState(salt))) {okay=false;break;}
            }
            if(!okay) {iterator.remove();setDirty();continue;}
            all.add(seal);
        }
        return all;
    }
    /** Unstuck command: only the owner or an operator can release the nearest absolute ward. */
    public List<OpeningSeal> visibleDoors(ServerLevel level) {
        List<OpeningSeal> all=new ArrayList<>();
        for(Map.Entry<Long,UUID> entry:saltedDoors.entrySet()) {
            BlockPos pos=BlockPos.of(entry.getKey());
            if(!level.hasChunkAt(pos)) continue;
            BlockState state=level.getBlockState(pos);
            if(!(state.getBlock() instanceof DoorBlock)) continue;
            Direction facing=state.getValue(DoorBlock.FACING);
            Direction.Axis axis=facing.getAxis()==Direction.Axis.Z?Direction.Axis.X:Direction.Axis.Z;
            all.add(new OpeningSeal(pos,axis,1,entry.getValue(),doorColors.getOrDefault(entry.getKey(),"white"),true));
        }
        return all;
    }
    public boolean releaseNearest(ServerPlayer player,double range) {
        double best=range*range;BlockPos selected=null;boolean isDoor=false;
        for(long key:absoluteDoors) {
            BlockPos pos=BlockPos.of(key);UUID owner=saltedDoors.get(key);
            if(!player.createCommandSourceStack().hasPermission(2) && !player.getUUID().equals(owner)) continue;
            double d=pos.distToCenterSqr(player.getX(),player.getY(),player.getZ());
            if(d<best) {best=d;selected=pos;isDoor=true;}
        }
        for(OpeningSeal seal:openings.values()) {
            if(!player.createCommandSourceStack().hasPermission(2) && !player.getUUID().equals(seal.owner())) continue;
            double d=seal.start().distToCenterSqr(player.getX(),player.getY(),player.getZ());
            if(d<best) {best=d;selected=seal.start();isDoor=false;}
        }
        if(selected==null) return false;
        if(isDoor) {absoluteDoors.remove(selected.asLong());setDirty();return true;}
        return removeOpeningAt(selected);
    }
    public static boolean canCross(ServerLevel level,UUID caster,LivingEntity actor) {
        if(caster==null) return true;
        if(caster.equals(actor.getUUID())) return true;
        CovenData covens=CovenData.get(level);
        if(covens.same(caster,actor.getUUID())) return true;
        if(actor instanceof TamableAnimal pet && pet.isTame() && pet.getOwnerUUID()!=null) {
            UUID petOwner=pet.getOwnerUUID();
            if(caster.equals(petOwner) || covens.same(caster,petOwner)) return true;
        }
        if(actor.getPersistentData().hasUUID("EclipseFamiliarOwner")) {
            UUID familiarOwner=actor.getPersistentData().getUUID("EclipseFamiliarOwner");
            return caster.equals(familiarOwner) || covens.same(caster,familiarOwner);
        }
        return false;
    }
}
