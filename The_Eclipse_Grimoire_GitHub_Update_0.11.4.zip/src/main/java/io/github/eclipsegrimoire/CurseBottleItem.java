package io.github.eclipsegrimoire;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/** Single-use hex cleansing bottle; does not remove ordinary vanilla potion effects. */
public final class CurseBottleItem extends Item {
    public CurseBottleItem(Properties properties){super(properties);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
        ItemStack stack=player.getItemInHand(hand);
        if(!(player instanceof ServerPlayer witch)) return InteractionResultHolder.success(stack);
        if(!HexMagic.cleanse(witch)) {
            witch.sendSystemMessage(Component.literal("[Eclipse] The curse bottle finds no hex to absorb."));
            return InteractionResultHolder.fail(stack);
        }
        if(!witch.isCreative()) {
            stack.shrink(1);
            ItemStack glass=new ItemStack(Items.GLASS_BOTTLE);
            if(!witch.getInventory().add(glass)) witch.drop(glass,false);
        }
        witch.serverLevel().playSound(null,witch.blockPosition(),SoundEvents.GLASS_BREAK,SoundSource.PLAYERS,.7f,1.1f);
        witch.sendSystemMessage(Component.literal("[Eclipse] The curse bottle absorbed your hex and shattered. Your magic is free."));
        return InteractionResultHolder.success(stack);
    }
}
