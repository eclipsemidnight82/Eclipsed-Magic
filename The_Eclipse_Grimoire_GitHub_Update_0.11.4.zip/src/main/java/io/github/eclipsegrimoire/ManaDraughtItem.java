package io.github.eclipsegrimoire;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

/** Portable mana restoration, using the existing server-authoritative mana pool. */
public final class ManaDraughtItem extends Item {
    public ManaDraughtItem(Properties properties){super(properties);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(!level.isClientSide() && player instanceof ServerPlayer witch) {
            int missing=MagicData.maxMana(witch)-MagicData.mana(witch);
            if(missing<=0) {
                witch.sendSystemMessage(Component.literal("[Eclipse] Your mana is already full."));
                return InteractionResultHolder.fail(stack);
            }
            int restored=Math.min(50,missing);
            MagicData.mana(witch,MagicData.mana(witch)+restored);
            if(!witch.isCreative()) {
                stack.shrink(1);
                ItemStack bottle=new ItemStack(Items.GLASS_BOTTLE);
                if(!witch.getInventory().add(bottle)) witch.drop(bottle,false);
            }
            level.playSound(null,player.blockPosition(),SoundEvents.BREWING_STAND_BREW,SoundSource.PLAYERS,.9f,1.5f);
            witch.sendSystemMessage(Component.literal("[Eclipse] Mana restored: +"+restored+" ("+MagicData.mana(witch)+"/"+MagicData.maxMana(witch)+")."));
            MagicData.refreshBooks(witch);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide());
    }
}
