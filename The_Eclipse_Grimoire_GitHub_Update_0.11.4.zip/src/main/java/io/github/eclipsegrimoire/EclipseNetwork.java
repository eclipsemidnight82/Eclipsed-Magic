package io.github.eclipsegrimoire;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/** Server-authoritative book and low-bandwidth HUD sync; server validates every spell cast. */
public final class EclipseNetwork {
    private EclipseNetwork() { }
    private static final String VERSION="8";
    private static final SimpleChannel CHANNEL=NetworkRegistry.newSimpleChannel(
        new ResourceLocation(EclipseMod.MOD_ID,"main"),()->VERSION,VERSION::equals,VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0,OpenGrimoire.class,OpenGrimoire::encode,OpenGrimoire::decode,OpenGrimoire::handle);
        CHANNEL.registerMessage(1,WheelRequest.class,WheelRequest::encode,WheelRequest::decode,WheelRequest::handle);
        CHANNEL.registerMessage(2,WheelState.class,WheelState::encode,WheelState::decode,WheelState::handle);
        CHANNEL.registerMessage(3,ThunderEffect.class,ThunderEffect::encode,ThunderEffect::decode,ThunderEffect::handle);
        CHANNEL.registerMessage(4,WitchfireEffect.class,WitchfireEffect::encode,WitchfireEffect::decode,WitchfireEffect::handle);
        CHANNEL.registerMessage(5,ScryTarget.class,ScryTarget::encode,ScryTarget::decode,ScryTarget::handle);
        CHANNEL.registerMessage(6,ScryRequest.class,ScryRequest::encode,ScryRequest::decode,ScryRequest::handle);
        CHANNEL.registerMessage(7,ScryRegistry.class,ScryRegistry::encode,ScryRegistry::decode,ScryRegistry::handle);
        CHANNEL.registerMessage(8,ScryAction.class,ScryAction::encode,ScryAction::decode,ScryAction::handle);
    }
    public static void open(ServerPlayer player,ItemStack original) {
        ItemStack shown=original.copy();
        MagicData.stamp(shown,player);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new OpenGrimoire(shown));
    }
    /** Called only when a player presses their wheel key, not every tick. */
    public static void requestWheel() {CHANNEL.sendToServer(new WheelRequest());}

    /** Actual beam geometry is rendered client-side and sent to all nearby observers. */
    public static void thunder(ServerLevel level,Vec3 from,Vec3 to,String color,int seed) {
        for(ServerPlayer player:level.players()) {
            if(player.position().distanceToSqr(from)<96*96)
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),new ThunderEffect(from,to,color,seed));
        }
    }
    public static void witchfire(ServerPlayer caster) {
        for(ServerPlayer viewer:caster.serverLevel().players()) {
            if(viewer.position().distanceToSqr(caster.position())<80*80)
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> viewer),
                    new WitchfireEffect(caster.getId(),MagicData.magic(caster)));
        }
    }
    public static void requestScry(net.minecraft.core.BlockPos crystal,java.util.UUID target){CHANNEL.sendToServer(new ScryRequest(crystal,target));}
    public static void requestRegistry(net.minecraft.core.BlockPos crystal){CHANNEL.sendToServer(new ScryAction(crystal,0,null));}
    public static void chooseScry(net.minecraft.core.BlockPos crystal,java.util.UUID target){CHANNEL.sendToServer(new ScryAction(crystal,1,target));}
    public static void forgetScry(net.minecraft.core.BlockPos crystal,java.util.UUID target){CHANNEL.sendToServer(new ScryAction(crystal,2,target));}
    public static void scryRegistry(ServerPlayer player,net.minecraft.core.BlockPos pos,net.minecraft.nbt.CompoundTag payload){
        CHANNEL.send(PacketDistributor.PLAYER.with(()->player),new ScryRegistry(pos,payload));
    }
    /** Instruct the client to attach its own camera only to a real tracked entity. */
    public static void scryTarget(ServerPlayer viewer,int entityId,java.util.UUID uuid,String message,
            net.minecraft.core.BlockPos crystal){
        CHANNEL.send(PacketDistributor.PLAYER.with(()->viewer),new ScryTarget(entityId,uuid,message,crystal));
    }
    private record ScryRequest(net.minecraft.core.BlockPos crystal,java.util.UUID target){
        static void encode(ScryRequest m,FriendlyByteBuf b){b.writeBlockPos(m.crystal);b.writeUUID(m.target);}
        static ScryRequest decode(FriendlyByteBuf b){return new ScryRequest(b.readBlockPos(),b.readUUID());}
        static void handle(ScryRequest m,Supplier<NetworkEvent.Context> sup){
            var ctx=sup.get();ctx.enqueueWork(()->{
                ServerPlayer viewer=ctx.getSender();
                if(viewer!=null)ScryingMagic.view(viewer,m.crystal,m.target);
            });
            ctx.setPacketHandled(true);
        }
    }
    private record ScryAction(net.minecraft.core.BlockPos crystal,int action,java.util.UUID target){
        static void encode(ScryAction m,FriendlyByteBuf b){
            b.writeBlockPos(m.crystal);b.writeVarInt(m.action);b.writeBoolean(m.target!=null);
            if(m.target!=null)b.writeUUID(m.target);
        }
        static ScryAction decode(FriendlyByteBuf b){
            net.minecraft.core.BlockPos pos=b.readBlockPos();int action=b.readVarInt();
            return new ScryAction(pos,action,b.readBoolean()?b.readUUID():null);
        }
        static void handle(ScryAction m,Supplier<NetworkEvent.Context> sup){
            var ctx=sup.get();ctx.enqueueWork(()->{
                ServerPlayer player=ctx.getSender();if(player==null)return;
                if(m.action==0)ScryingMagic.registry(player,m.crystal);
                else if(m.target!=null&&m.action==1)ScryingMagic.view(player,m.crystal,m.target);
                else if(m.target!=null&&m.action==2)ScryingMagic.forget(player,m.crystal,m.target);
            });ctx.setPacketHandled(true);
        }
    }
    private record ScryRegistry(net.minecraft.core.BlockPos crystal,net.minecraft.nbt.CompoundTag registry){
        static void encode(ScryRegistry m,FriendlyByteBuf b){b.writeBlockPos(m.crystal);b.writeNbt(m.registry);}
        static ScryRegistry decode(FriendlyByteBuf b){
            net.minecraft.core.BlockPos pos=b.readBlockPos();net.minecraft.nbt.CompoundTag tag=b.readNbt();
            return new ScryRegistry(pos,tag==null?new net.minecraft.nbt.CompoundTag():tag);
        }
        static void handle(ScryRegistry m,Supplier<NetworkEvent.Context> sup){
            var ctx=sup.get();ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ScryRegistryScreen.receive(m.crystal,m.registry)));
            ctx.setPacketHandled(true);
        }
    }
    private record ScryTarget(int entityId,java.util.UUID uuid,String name,net.minecraft.core.BlockPos crystal){
        static void encode(ScryTarget m,FriendlyByteBuf b){
            b.writeVarInt(m.entityId);
            b.writeBoolean(m.uuid!=null);
            if(m.uuid!=null)b.writeUUID(m.uuid);
            b.writeUtf(m.name,150);
            b.writeBlockPos(m.crystal);
        }
        static ScryTarget decode(FriendlyByteBuf b){
            int entityId=b.readVarInt();
            java.util.UUID uuid=b.readBoolean()?b.readUUID():null;
            return new ScryTarget(entityId,uuid,b.readUtf(150),b.readBlockPos());
        }
        static void handle(ScryTarget m,Supplier<NetworkEvent.Context> supplier){
            var ctx=supplier.get();ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ScryingScreen.receive(m.entityId,m.uuid,m.name,m.crystal)));
            ctx.setPacketHandled(true);
        }
    }
    private record ThunderEffect(Vec3 from,Vec3 to,String color,int seed) {
        static void encode(ThunderEffect msg,FriendlyByteBuf buf) {
            buf.writeDouble(msg.from.x);buf.writeDouble(msg.from.y);buf.writeDouble(msg.from.z);
            buf.writeDouble(msg.to.x);buf.writeDouble(msg.to.y);buf.writeDouble(msg.to.z);
            buf.writeUtf(msg.color,20);buf.writeInt(msg.seed);
        }
        static ThunderEffect decode(FriendlyByteBuf buf) {
            Vec3 from=new Vec3(buf.readDouble(),buf.readDouble(),buf.readDouble());
            Vec3 to=new Vec3(buf.readDouble(),buf.readDouble(),buf.readDouble());
            return new ThunderEffect(from,to,buf.readUtf(20),buf.readInt());
        }
        static void handle(ThunderEffect msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ArcaneRender.bolt(msg.from,msg.to,msg.color,msg.seed)));
            ctx.setPacketHandled(true);
        }
    }
    private record WitchfireEffect(int entityId,String color) {
        static void encode(WitchfireEffect msg,FriendlyByteBuf buf) {buf.writeVarInt(msg.entityId);buf.writeUtf(msg.color,20);}
        static WitchfireEffect decode(FriendlyByteBuf buf) {return new WitchfireEffect(buf.readVarInt(),buf.readUtf(20));}
        static void handle(WitchfireEffect msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ArcaneRender.flame(msg.entityId,msg.color)));
            ctx.setPacketHandled(true);
        }
    }
    private record OpenGrimoire(ItemStack book) {
        static void encode(OpenGrimoire msg,FriendlyByteBuf buf) {buf.writeItem(msg.book);}
        static OpenGrimoire decode(FriendlyByteBuf buf) {return new OpenGrimoire(buf.readItem());}
        static void handle(OpenGrimoire msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.ClientBook.open(msg.book)));
            ctx.setPacketHandled(true);
        }
    }
    private record WheelRequest() {
        static void encode(WheelRequest msg,FriendlyByteBuf buf) { }
        static WheelRequest decode(FriendlyByteBuf buf) {return new WheelRequest();}
        static void handle(WheelRequest msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->{
                ServerPlayer player=ctx.getSender();
                if(player==null) return;
                CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                    new WheelState(MagicData.level(player),MagicData.mana(player),MagicData.maxMana(player),MagicData.magic(player)));
            });
            ctx.setPacketHandled(true);
        }
    }
    private record WheelState(int level,int mana,int maxMana,String magicColor) {
        static void encode(WheelState msg,FriendlyByteBuf buf) {
            buf.writeVarInt(msg.level);buf.writeVarInt(msg.mana);buf.writeVarInt(msg.maxMana);buf.writeUtf(msg.magicColor,32);
        }
        static WheelState decode(FriendlyByteBuf buf) {
            return new WheelState(buf.readVarInt(),buf.readVarInt(),buf.readVarInt(),buf.readUtf(32));
        }
        static void handle(WheelState msg,Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context ctx=supplier.get();
            ctx.enqueueWork(()->DistExecutor.unsafeRunWhenOn(Dist.CLIENT,()->()->
                io.github.eclipsegrimoire.client.SpellWheel.receive(msg.level,msg.mana,msg.maxMana,msg.magicColor)));
            ctx.setPacketHandled(true);
        }
    }
}
