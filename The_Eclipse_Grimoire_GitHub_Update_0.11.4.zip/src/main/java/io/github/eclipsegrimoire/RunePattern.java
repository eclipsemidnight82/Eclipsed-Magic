package io.github.eclipsegrimoire;

import net.minecraft.util.StringRepresentable;

/** Persistent decorative chalk styles; an ordinary rune is inert until enchanted. */
public enum RunePattern implements StringRepresentable {
    MOON("moon"), STAR("star"), ECLIPSE("eclipse"), KNOT("knot"),
    FOCUS("focus"), SUN("sun"), WARD("ward"), BINDING("binding");
    private final String id;
    RunePattern(String id) { this.id=id; }
    @Override public String getSerializedName() {return id;}
    public static RunePattern of(String id) {
        for(RunePattern p:values()) if(p.id.equalsIgnoreCase(id)) return p;
        return MOON;
    }
    public RunePattern next() {return values()[(ordinal()+1)%values().length];}
}
