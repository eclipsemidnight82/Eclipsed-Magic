package io.github.eclipsegrimoire;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Per-crystal saved target registry. Spectator camera always remains client-only. */
public final class ScryingMagic {
    private ScryingMagic() { }

    private static boolean valid(ServerPlayer witch,BlockPos crystal){
        ServerLevel level=witch.serverLevel();
        return level.hasChunkAt(crystal) && witch.distanceToSqr(crystal.getX()+.5,
            crystal.getY()+.5,crystal.getZ()+.5)<=100 &&
            level.getBlockState(crystal).is(EclipseMod.SCRY_CRYSTAL_BLOCK.get());
    }
    public static void registry(ServerPlayer witch,BlockPos crystal){
        if(!valid(witch,crystal)){
            witch.sendSystemMessage(Component.literal("[Eclipse] Stand near your Scrying Crystal to use its registry."));return;
        }
        ListTag targets=new ListTag();
        for(BloodRelicsData.CrystalBond bond:BloodRelicsData.get(witch.serverLevel()).crystalEntries(witch.serverLevel(),crystal)){
            CompoundTag entry=new CompoundTag();
            entry.putUUID("id",bond.subject());entry.putString("name",bond.name());
            entry.putBoolean("player",bond.player());
            LivingEntity live=resolve(witch,bond);
            String state;
            if(bond.player()) {
                ServerPlayer player=witch.server.getPlayerList().getPlayer(bond.subject());
                state=player==null?"OFFLINE":!player.isAlive()?"RESPAWNING":
                    player.level()!=witch.level()?"OTHER DIMENSION":"ONLINE";
            } else state=live==null?"NOT LOADED":!live.isAlive()?"DEAD":"LOADED";
            entry.putString("status",state);targets.add(entry);
        }
        CompoundTag payload=new CompoundTag();payload.put("targets",targets);
        EclipseNetwork.scryRegistry(witch,crystal,payload);
    }
    private static LivingEntity resolve(ServerPlayer witch,BloodRelicsData.CrystalBond bond){
        ServerPlayer online=witch.server.getPlayerList().getPlayer(bond.subject());
        if(online!=null)return online;
        ResourceLocation location=ResourceLocation.tryParse(bond.dimension());
        if(location==null)return null;
        ServerLevel other=witch.server.getLevel(ResourceKey.create(Registries.DIMENSION,location));
        if(other==null)return null;
        Entity entity=other.getEntity(bond.subject());
        return entity instanceof LivingEntity living?living:null;
    }
    public static void forget(ServerPlayer witch,BlockPos crystal,UUID target){
        if(!valid(witch,crystal))return;
        BloodRelicsData data=BloodRelicsData.get(witch.serverLevel());
        if(data.forgetCrystal(witch.serverLevel(),crystal,target)){
            BlockState state=witch.serverLevel().getBlockState(crystal);
            if(state.hasProperty(ScryingCrystalBlock.BOUND))
                witch.serverLevel().setBlock(crystal,state.setValue(ScryingCrystalBlock.BOUND,
                    !data.crystalEntries(witch.serverLevel(),crystal).isEmpty()),3);
        }
        registry(witch,crystal);
    }
    public static void view(ServerPlayer witch,BlockPos crystal,UUID subject) {
        if(!valid(witch,crystal)){
            EclipseNetwork.scryTarget(witch,-1,null,"The crystal connection was broken.",crystal);return;
        }
        long now=witch.serverLevel().getGameTime();
        if(witch.getPersistentData().getLong("EclipseNextScry")>now)return;
        witch.getPersistentData().putLong("EclipseNextScry",now+6);
        BloodRelicsData.CrystalBond bond=BloodRelicsData.get(witch.serverLevel()).crystal(witch.serverLevel(),crystal,subject);
        if(bond==null){
            EclipseNetwork.scryTarget(witch,-1,null,"This target is not in the crystal's blood registry.",crystal);return;
        }
        LivingEntity target=resolve(witch,bond);
        if(target==null || !target.isAlive()){
            EclipseNetwork.scryTarget(witch,-1,null,bond.player()?"Player offline or respawning.":"Creature not currently loaded.",crystal);return;
        }
        if(target.level()!=witch.level()){
            EclipseNetwork.scryTarget(witch,-1,null,"Cross-dimensional vision is not yet supported.",crystal);return;
        }
        if(target!=witch && target instanceof ServerPlayer protectedPlayer &&
            protectedPlayer.getInventory().items.stream().anyMatch(s->s.is(EclipseMod.GRIS_GRIS.get()))){
            EclipseNetwork.scryTarget(witch,-1,null,"A protective charm obscures their eyes.",crystal);return;
        }
        EclipseNetwork.scryTarget(witch,target.getId(),target.getUUID(),target.getName().getString(),crystal);
    }
}
