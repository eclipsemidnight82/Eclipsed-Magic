package io.github.eclipsegrimoire;

import net.minecraft.core.RegistryAccess;
import net.minecraft.core.NonNullList;
import net.minecraft.world.inventory.CraftingContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

/** The crafting grid transfers a real donor UUID to the poppet. No generic or forged result. */
public final class BloodPoppetRecipe extends CustomRecipe {
    public BloodPoppetRecipe(net.minecraft.resources.ResourceLocation id, CraftingBookCategory category){super(id,category);}
    @Override public boolean matches(CraftingContainer inv,Level level){
        int blood=0,doll=0;
        for(int i=0;i<inv.getContainerSize();i++){
            ItemStack s=inv.getItem(i);if(s.isEmpty())continue;
            if(TaglockItem.filled(s))blood++;
            else if(s.is(EclipseMod.POPPET.get()) && (!s.hasTag()||!s.getTag().hasUUID("Target")))doll++;
            else return false;
        }
        return blood==1 && doll==1;
    }
    @Override public ItemStack assemble(CraftingContainer inv,RegistryAccess registries){
        ItemStack blood=ItemStack.EMPTY;
        for(int i=0;i<inv.getContainerSize();i++)if(TaglockItem.filled(inv.getItem(i)))blood=inv.getItem(i);
        if(blood.isEmpty())return ItemStack.EMPTY;
        ItemStack result=new ItemStack(EclipseMod.POPPET.get());
        result.getOrCreateTag().putUUID("Target",blood.getTag().getUUID("Target"));
        result.getOrCreateTag().putString("Name",blood.getTag().getString("Name"));
        result.getOrCreateTag().putString("Dimension",blood.getTag().getString("Dimension"));
        result.getOrCreateTag().putBoolean("Bloodbound",true);
        return result;
    }
    @Override public NonNullList<ItemStack> getRemainingItems(CraftingContainer inv){
        NonNullList<ItemStack> left=NonNullList.withSize(inv.getContainerSize(),ItemStack.EMPTY);
        for(int i=0;i<inv.getContainerSize();i++)if(TaglockItem.filled(inv.getItem(i)))left.set(i,new ItemStack(EclipseMod.TAGLOCK.get()));
        return left;
    }
    @Override public boolean canCraftInDimensions(int w,int h){return w*h>=2;}
    @Override public RecipeSerializer<?> getSerializer(){return EclipseMod.BLOOD_POPPET_RECIPE.get();}
}
