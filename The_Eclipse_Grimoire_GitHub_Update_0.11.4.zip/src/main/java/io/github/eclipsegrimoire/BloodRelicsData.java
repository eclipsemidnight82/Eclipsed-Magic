package io.github.eclipsegrimoire;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;
import net.minecraft.world.item.ItemStack;

/** Global overworld SavedData: blood protection does NOT depend on a loaded chalice chunk. */
public final class BloodRelicsData extends SavedData {
    public record BloodBond(UUID subject,String name,String dimension,BlockPos pos) { }
    public record CrystalBond(UUID subject,String name,String dimension,BlockPos pos,boolean player) { }
    private final Map<UUID,BloodBond> chalices=new HashMap<>();
    private final Map<String,List<CrystalBond>> crystals=new HashMap<>();
    private final Map<String,ItemStack> shelves=new HashMap<>();
    public static BloodRelicsData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(BloodRelicsData::load,
            BloodRelicsData::new,"eclipse_blood_relics");
    }
    private static BloodRelicsData load(CompoundTag tag) {
        BloodRelicsData d=new BloodRelicsData();
        for(Tag raw:tag.getList("chalices",10)) {
            CompoundTag e=(CompoundTag)raw;
            if(e.hasUUID("subject")) {
                UUID id=e.getUUID("subject");
                d.chalices.put(id,new BloodBond(id,e.getString("name"),e.getString("dimension"),BlockPos.of(e.getLong("pos"))));
            }
        }
        for(Tag raw:tag.getList("crystals",10)) {
            CompoundTag e=(CompoundTag)raw;
            if(e.hasUUID("subject")) {
                UUID id=e.getUUID("subject");
                CrystalBond b=new CrystalBond(id,e.getString("name"),e.getString("dimension"),BlockPos.of(e.getLong("pos")),e.getBoolean("player"));
                List<CrystalBond> registry=d.crystals.computeIfAbsent(e.getString("key"),k->new ArrayList<>());
                if(registry.stream().noneMatch(x->x.subject().equals(id)))registry.add(b);
            }
        }
        for(Tag raw:tag.getList("shelves",10)) {
            CompoundTag e=(CompoundTag)raw;ItemStack stack=ItemStack.of(e.getCompound("stack"));
            if(!stack.isEmpty())d.shelves.put(e.getString("key"),stack);
        }
        return d;
    }
    @Override public CompoundTag save(CompoundTag tag) {
        ListTag chalicesOut=new ListTag();
        for(BloodBond b:chalices.values()) {
            CompoundTag e=new CompoundTag();e.putUUID("subject",b.subject());e.putString("name",b.name());
            e.putString("dimension",b.dimension());e.putLong("pos",b.pos().asLong());chalicesOut.add(e);
        }
        ListTag crystalsOut=new ListTag();
        crystals.forEach((key,registry)->{
            for(CrystalBond b:registry){
                CompoundTag e=new CompoundTag();e.putString("key",key);e.putUUID("subject",b.subject());
                e.putString("name",b.name());e.putString("dimension",b.dimension());
                e.putBoolean("player",b.player());e.putLong("pos",b.pos().asLong());crystalsOut.add(e);
            }
        });
        ListTag shelfOut=new ListTag();
        shelves.forEach((key,stack)->{CompoundTag e=new CompoundTag();e.putString("key",key);
            e.put("stack",stack.save(new CompoundTag()));shelfOut.add(e);});
        tag.put("chalices",chalicesOut);tag.put("crystals",crystalsOut);tag.put("shelves",shelfOut);return tag;
    }
    public BloodBond chalice(UUID subject) {return chalices.get(subject);}
    public BloodBond atChalice(ServerLevel level,BlockPos pos) {
        String dimension=level.dimension().location().toString();
        for(BloodBond b:chalices.values()) if(b.dimension().equals(dimension)&&b.pos().equals(pos)) return b;
        return null;
    }
    public boolean bindChalice(ServerLevel level,BlockPos pos,UUID id,String name) {
        BloodBond old=chalices.get(id);
        if(old!=null && !(old.dimension().equals(level.dimension().location().toString()) && old.pos().equals(pos))) return false;
        BloodBond previous=atChalice(level,pos);
        if(previous!=null&&!previous.subject().equals(id))chalices.remove(previous.subject());
        chalices.put(id,new BloodBond(id,name,level.dimension().location().toString(),pos.immutable()));setDirty();return true;
    }
    public void removeChalice(ServerLevel level,BlockPos pos) {
        BloodBond b=atChalice(level,pos);
        if(b!=null){chalices.remove(b.subject());setDirty();}
    }
    public void removeInvalid(UUID subject){if(chalices.remove(subject)!=null)setDirty();}
    public ItemStack shelf(ServerLevel level,BlockPos pos){return shelves.getOrDefault(key(level,pos),ItemStack.EMPTY).copy();}
    public void setShelf(ServerLevel level,BlockPos pos,ItemStack item){shelves.put(key(level,pos),item.copy());setDirty();}
    public ItemStack removeShelf(ServerLevel level,BlockPos pos){ItemStack old=shelves.remove(key(level,pos));if(old!=null)setDirty();return old==null?ItemStack.EMPTY:old;}
    /** Removes the ward charge in SavedData exactly once, including when the shelf chunk is unloaded. */
    public boolean useShelfWard(UUID subject){
        for(ItemStack poppet:shelves.values()){
            if(!poppet.is(EclipseMod.POPPET.get())||!poppet.hasTag())continue;
            CompoundTag tag=poppet.getTag();
            if(tag.hasUUID("Target")&&subject.equals(tag.getUUID("Target"))&&tag.getInt("WardCharge")>0){
                tag.putInt("WardCharge",0);setDirty();return true;
            }
        }
        return false;
    }
    private static String key(ServerLevel level,BlockPos pos){return level.dimension().location().toString()+"@"+pos.asLong();}
    /** Legacy 0.11.1 singular registry data is loaded as the first entry. */
    public List<CrystalBond> crystalEntries(ServerLevel level,BlockPos pos){
        return List.copyOf(crystals.getOrDefault(key(level,pos),List.of()));
    }
    public CrystalBond crystal(ServerLevel level,BlockPos pos,UUID subject){
        for(CrystalBond bond:crystalEntries(level,pos))if(bond.subject().equals(subject))return bond;
        return null;
    }
    public int addCrystal(ServerLevel level,BlockPos pos,UUID subject,String name,String targetDimension,boolean isPlayer){
        String key=key(level,pos);
        List<CrystalBond> registry=crystals.computeIfAbsent(key,k->new ArrayList<>());
        registry.removeIf(b->b.subject().equals(subject));
        if(registry.size()>=16)return -1;
        registry.add(new CrystalBond(subject,name,targetDimension,pos.immutable(),isPlayer));
        setDirty();return registry.size();
    }
    public boolean forgetCrystal(ServerLevel level,BlockPos pos,UUID subject){
        String key=key(level,pos);List<CrystalBond> registry=crystals.get(key);
        if(registry==null || !registry.removeIf(b->b.subject().equals(subject)))return false;
        if(registry.isEmpty())crystals.remove(key);
        setDirty();return true;
    }
    /** Mobs vanish from all registry lists on death; players keep their slot for respawn. */
    public void forgetDeadCreature(UUID subject){
        boolean changed=false;
        for(List<CrystalBond> registry:crystals.values())
            changed |= registry.removeIf(b->b.subject().equals(subject) && !b.player());
        changed |= crystals.entrySet().removeIf(e->e.getValue().isEmpty());
        if(changed)setDirty();
    }
    public void removeCrystal(ServerLevel level,BlockPos pos){if(crystals.remove(key(level,pos))!=null)setDirty();}
}
