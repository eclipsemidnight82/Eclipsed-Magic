package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Placeable target-bound crystal. Views are server-sourced, never guessed client-side. */
public final class ScryingCrystalBlock extends Block {
    public static final BooleanProperty BOUND=BooleanProperty.create("bound");
    private static final VoxelShape SHAPE=Block.box(3,0,3,13,15,13);
    public ScryingCrystalBlock(BlockBehaviour.Properties props){super(props);registerDefaultState(stateDefinition.any().setValue(BOUND,false));}
    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block,BlockState> b){b.add(BOUND);}
    @Override public VoxelShape getShape(BlockState s,BlockGetter g,BlockPos p,CollisionContext c){return SHAPE;}
    @Override public InteractionResult use(BlockState s,Level level,BlockPos pos,Player player,InteractionHand hand,BlockHitResult hit){
        if(level.isClientSide())return InteractionResult.SUCCESS;
        if(!(player instanceof ServerPlayer witch))return InteractionResult.PASS;
        ServerLevel server=(ServerLevel)level;ItemStack held=player.getItemInHand(hand);
        BloodRelicsData data=BloodRelicsData.get(server);
        if(TaglockItem.filled(held)){
            int total=data.addCrystal(server,pos,held.getTag().getUUID("Target"),held.getTag().getString("Name"),
                held.getTag().getString("Dimension"),held.getTag().getBoolean("PlayerBlood"));
            if(total<0){witch.sendSystemMessage(Component.literal("[Eclipse] This crystal's registry is full (16 targets). Forget one to make space."));return InteractionResult.CONSUME;}
            server.setBlock(pos,s.setValue(BOUND,true),3);TaglockItem.empty(held);
            server.playSound(null,pos,SoundEvents.ENCHANTMENT_TABLE_USE,SoundSource.BLOCKS,1f,.8f);
            witch.sendSystemMessage(Component.literal("[Eclipse] Blood registered. "+total+" target(s) saved. Open the crystal to choose a vision."));
        } else ScryingMagic.registry(witch,pos);
        return InteractionResult.CONSUME;
    }
    @Override public void animateTick(BlockState state, Level level, BlockPos pos,
                                      net.minecraft.util.RandomSource random) {
        if (!state.getValue(BOUND) || random.nextInt(7) != 0) return;
        double x=pos.getX()+0.5+(random.nextDouble()-0.5)*0.45;
        double z=pos.getZ()+0.5+(random.nextDouble()-0.5)*0.45;
        level.addParticle(net.minecraft.core.particles.ParticleTypes.ENCHANT,
            x,pos.getY()+0.85+random.nextDouble()*0.38,z,0,0.025,0);
        if(random.nextInt(5)==0)level.addParticle(net.minecraft.core.particles.ParticleTypes.END_ROD,
            x,pos.getY()+1.1,z,0,0.015,0);
    }
    @Override public void onRemove(BlockState s,Level l,BlockPos p,BlockState n,boolean moved){
        if(!s.is(n.getBlock())&&l instanceof ServerLevel server)BloodRelicsData.get(server).removeCrystal(server,p);
        super.onRemove(s,l,p,n,moved);
    }
}
