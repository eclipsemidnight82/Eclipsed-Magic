package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.EclipseNetwork;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;

/** Clean selection menu: target blood is remembered at THIS crystal across world reloads. */
public final class ScryRegistryScreen extends Screen {
    private final BlockPos crystal;
    private final ListTag targets;
    private int page=0;
    // A second click is required to forget a bound player or creature.
    private UUID pendingRemoval=null;
    private static final int PER_PAGE=5;
    private ScryRegistryScreen(BlockPos pos,CompoundTag data){
        super(Component.literal("Scrying Registry"));crystal=pos;
        targets=data.getList("targets",10).copy();
    }
    public static void receive(BlockPos pos,CompoundTag data){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null)mc.setScreen(new ScryRegistryScreen(pos,data));
    }
    @Override protected void init(){
        int x=width/2-155,y=height/2-103;
        for(int row=0;row<PER_PAGE;row++){
            int index=page*PER_PAGE+row;if(index>=targets.size())break;
            CompoundTag target=targets.getCompound(index);
            if(!target.hasUUID("id"))continue;
            UUID id=target.getUUID("id");int yy=y+45+row*29;
            String state=target.getString("status");
            Button watch=Button.builder(Component.literal("View"),b->EclipseNetwork.chooseScry(crystal,id))
                .bounds(x+195,yy+1,49,19).build();
            watch.active=!state.equals("OFFLINE")&&!state.equals("RESPAWNING")&&
                !state.equals("NOT LOADED")&&!state.equals("OTHER DIMENSION");
            addRenderableWidget(watch);
            // Removal affects this crystal's registry ONLY; it never damages the subject.
            addRenderableWidget(Button.builder(Component.literal(id.equals(pendingRemoval)?"Confirm":"Remove"),b->{
                if(id.equals(pendingRemoval)){
                    pendingRemoval=null;
                    EclipseNetwork.forgetScry(crystal,id);
                } else {
                    pendingRemoval=id;
                    rebuildWidgets();
                }
            }).bounds(x+249,yy+1,55,19).build());
        }
        if(page>0)addRenderableWidget(Button.builder(Component.literal("<"),b->{page--;pendingRemoval=null;rebuildWidgets();})
            .bounds(x+15,y+196,28,20).build());
        if((page+1)*PER_PAGE<targets.size())
            addRenderableWidget(Button.builder(Component.literal(">"),b->{page++;pendingRemoval=null;rebuildWidgets();})
                .bounds(x+49,y+196,28,20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"),b->onClose())
            .bounds(x+227,y+196,77,20).build());
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        renderBackground(g);
        int x=width/2-155,y=height/2-103;
        g.fill(x-4,y-4,x+310,y+224,0xe90b0618);
        g.fill(x,y,x+306,y+32,0xff251137);
        g.drawCenteredString(font,"SCRYING REGISTRY",width/2,y+8,0xffe3bdff);
        g.drawCenteredString(font,"Only bloodbound targets are remembered",width/2,y+25,0xffa991c2);
        if(targets.isEmpty()){
            g.drawCenteredString(font,"No blood names remembered.",width/2,y+91,0xffe8d7f2);
            g.drawCenteredString(font,"Offer a filled taglock to the crystal.",width/2,y+110,0xffad94bf);
        }
        for(int row=0;row<PER_PAGE;row++){
            int index=page*PER_PAGE+row;if(index>=targets.size())break;
            CompoundTag target=targets.getCompound(index);
            int yy=y+45+row*29;
            g.fill(x+5,yy-3,x+304,yy+24,row%2==0?0x77462959:0x77352448);
            String name=target.getString("name");
            if(name.length()>22)name=name.substring(0,19)+"...";
            g.drawString(font,name,x+11,yy,0xfff6eaff);
            String status=target.getString("status");
            g.drawString(font,(target.getBoolean("player")?"Player":"Creature")+" • "+status,
                x+11,yy+12,0xffb3a0c3);
        }
        if(pendingRemoval!=null){
            g.drawString(font,"Click Confirm again to forget this target.",x+8,y+185,0xffffcfcf);
        }
        g.drawString(font,"Memories: "+targets.size()+"/16",x+89,y+201,0xffd8c4e9);
        super.render(g,mouseX,mouseY,delta);
    }
    @Override public boolean isPauseScreen(){return false;}
}
