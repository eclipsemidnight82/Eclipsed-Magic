package io.github.eclipsegrimoire.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;

/** Only invoked on the physical client after a server packet is received. */
public final class ClientBook {
    private ClientBook() { }
    public static void open(ItemStack book) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null) mc.setScreen(new GrimoireScreen(book));
    }
}
