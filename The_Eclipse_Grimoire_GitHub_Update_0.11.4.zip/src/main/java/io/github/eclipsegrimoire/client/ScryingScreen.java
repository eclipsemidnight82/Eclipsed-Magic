package io.github.eclipsegrimoire.client;

import io.github.eclipsegrimoire.EclipseNetwork;
import java.util.UUID;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

/** Genuine client-side first-person camera on a *tracked* entity.
 * The player remains physically at the crystal; no gamemode change or teleport.
 * Never paints an approximate top-down map over the world.
 */
public final class ScryingScreen extends Screen {
    private final int targetId;
    private final UUID targetUuid;
    private final String targetName;
    private final BlockPos crystal;
    private CameraType oldCameraType;
    private Entity target;
    private int age=0;
    private boolean restored=false;

    private ScryingScreen(int targetId,UUID targetUuid,String targetName,BlockPos crystal){
        super(Component.literal("Arcane Sight"));
        this.targetId=targetId;this.targetUuid=targetUuid;
        this.targetName=targetName;this.crystal=crystal;
    }

    public static void receive(int targetId,UUID uuid,String message,BlockPos crystal){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.level==null)return;
        if(targetId<0 || uuid==null){
            if(mc.screen instanceof ScryingScreen existing)existing.onClose();
            mc.player.displayClientMessage(Component.literal("[Eclipse] "+message),false);
            return;
        }
        if(mc.screen instanceof ScryingScreen s){
            if(s.targetId==targetId && s.targetUuid.equals(uuid) && s.crystal.equals(crystal))return;
            s.onClose();
        }
        Entity subject=mc.level.getEntity(targetId);
        if(subject==null || !uuid.equals(subject.getUUID())){
            mc.player.displayClientMessage(Component.literal("[Eclipse] The target is beyond your loaded sight. " +
                "Their real first-person camera needs the target and nearby world to be tracked on your client."),false);
            return;
        }
        mc.setScreen(new ScryingScreen(targetId,uuid,message,crystal));
    }

    @Override protected void init(){
        Minecraft mc=Minecraft.getInstance();
        target=mc.level==null?null:mc.level.getEntity(targetId);
        if(target==null || !targetUuid.equals(target.getUUID())){
            mc.execute(()->{if(mc.screen==this)onClose();});
            return;
        }
        if(oldCameraType==null)oldCameraType=mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        mc.setCameraEntity(target);
        // Screen input is captured, so the witch cannot accidentally control the target.
        addRenderableWidget(Button.builder(Component.literal("End Vision"),b->onClose())
            .bounds(width-108,9,98,20).build());
        addRenderableWidget(Button.builder(Component.literal("Other Targets"),b->{
            onClose();EclipseNetwork.requestRegistry(crystal);
        }).bounds(width-221,9,108,20).build());
    }

    @Override public void tick(){
        Minecraft mc=Minecraft.getInstance();
        if(mc.player==null || mc.level==null || target==null || target.isRemoved() ||
            mc.level.getEntity(targetId)!=target || !targetUuid.equals(target.getUUID()) ||
            !mc.player.isAlive()){
            onClose();return;
        }
        // Restore if another client feature unexpectedly takes the camera away.
        if(mc.getCameraEntity()!=target){onClose();return;}
        if(++age%20==0)EclipseNetwork.requestScry(crystal,targetUuid);
    }

    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partial){
        // Do NOT call renderBackground: Minecraft renders the live target world behind us.
        g.fill(5,5,Math.min(width-122,190),40,0x910b051b);
        g.drawString(font,"ARCANE SIGHT",12,11,0xffd8a8ff);
        g.drawString(font,targetName,12,25,0xfff3e5ff);
        g.drawCenteredString(font,"ESC to return to your body",width/2,height-18,0xffe9d1ff);
        super.render(g,mouseX,mouseY,partial);
    }

    @Override public void onClose(){
        Minecraft mc=Minecraft.getInstance();
        restoreCamera();
        if(mc.screen==this)mc.setScreen(null);
    }

    private void restoreCamera(){
        if(restored)return;
        restored=true;
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null)mc.setCameraEntity(mc.player);
        if(oldCameraType!=null)mc.options.setCameraType(oldCameraType);
    }

    @Override public void removed(){restoreCamera();super.removed();}
    @Override public boolean isPauseScreen(){return false;}
}
