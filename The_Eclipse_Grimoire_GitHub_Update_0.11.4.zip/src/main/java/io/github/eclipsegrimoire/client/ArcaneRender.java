package io.github.eclipsegrimoire.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.eclipsegrimoire.ArcaneEffects;
import io.github.eclipsegrimoire.EclipseMod;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client-only short-lived volumetric bolts and animated colored flame sprites.
 *  Rendered as luminous crossed quads: unlike dust, lightning joins into a continuous zigzag.
 */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE,value=Dist.CLIENT)
public final class ArcaneRender {
    private ArcaneRender() { }
    private record Bolt(Vec3 start,Vec3 end,int color,long expiry,int seed) {}
    private record FireAura(int entityId,int color,long expiry) {}
    private static final List<Bolt> BOLTS=new ArrayList<>();
    private static final List<FireAura> FLAMES=new ArrayList<>();

    public static void bolt(Vec3 from,Vec3 to,String color,int seed) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null || from.distanceToSqr(to)>100*100) return;
        BOLTS.add(new Bolt(from,to,ArcaneEffects.rgb(color),mc.level.getGameTime()+8,seed));
        while(BOLTS.size()>40) BOLTS.remove(0);
    }
    public static void flame(int entityId,String color) {
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null) return;
        long until=mc.level.getGameTime()+18;
        FLAMES.removeIf(f->f.entityId()==entityId);
        FLAMES.add(new FireAura(entityId,ArcaneEffects.rgb(color),until));
        while(FLAMES.size()>24) FLAMES.remove(0);
    }
    @SubscribeEvent public static void render(RenderLevelStageEvent event) {
        if(event.getStage()!=RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        Minecraft mc=Minecraft.getInstance();
        if(mc.level==null) {BOLTS.clear();FLAMES.clear();return;}
        long now=mc.level.getGameTime();
        BOLTS.removeIf(b->b.expiry()<now);
        FLAMES.removeIf(f->f.expiry()<now || mc.level.getEntity(f.entityId())==null);
        if(BOLTS.isEmpty() && FLAMES.isEmpty()) return;
        PoseStack pose=event.getPoseStack();
        pose.pushPose();
        Vec3 camera=event.getCamera().getPosition();
        pose.translate(-camera.x,-camera.y,-camera.z);
        MultiBufferSource.BufferSource source=mc.renderBuffers().bufferSource();
        VertexConsumer v=source.getBuffer(RenderType.lightning());
        for(Bolt bolt:BOLTS) drawBolt(pose,v,bolt,(int)(bolt.expiry()-now));
        for(FireAura flame:FLAMES) {
            Entity entity=mc.level.getEntity(flame.entityId());
            if(entity!=null) drawFire(pose,v,entity,flame.color(),now+event.getPartialTick());
        }
        source.endBatch(RenderType.lightning());
        pose.popPose();
    }
    private static void drawBolt(PoseStack pose,VertexConsumer v,Bolt b,int remaining) {
        double distance=b.start().distanceTo(b.end());
        if(distance<.1) return;
        Vec3 forward=b.end().subtract(b.start()).normalize();
        Vec3 side=forward.cross(new Vec3(0,1,0));
        if(side.lengthSqr()<.01) side=forward.cross(new Vec3(1,0,0));
        side=side.normalize();
        Vec3 up=forward.cross(side).normalize();
        int steps=Math.max(12,Math.min(75,(int)(distance*5)));
        int r=(b.color()>>16)&255,g=(b.color()>>8)&255,blue=b.color()&255;
        Vec3 previous=b.start();
        for(int i=1;i<=steps;i++) {
            double t=(double)i/steps;
            double jitter=(i==steps?0:1.0) *(.13+.15*Math.sin(t*Math.PI));
            double pattern=Math.sin(i*14.27+b.seed()*1.41)*jitter;
            Vec3 next=b.start().lerp(b.end(),t).add(side.scale(pattern))
                .add(up.scale(Math.cos(i*11.91+b.seed())*jitter*.7));
            double flicker=.86+.14*Math.sin(remaining*4.5+i);
            quad(pose,v,previous,next,side,.11*flicker,r,g,blue,245);
            quad(pose,v,previous,next,up,.11*flicker,r,g,blue,245);
            quad(pose,v,previous,next,side,.036,255,255,255,255);
            quad(pose,v,previous,next,up,.036,255,255,255,255);
            if(i%7==0 && i<steps-2) {
                Vec3 tip=next.add(side.scale(.35+.3*((i%3)+1)))
                    .add(up.scale(.17+.13*(i%4))).add(forward.scale(.32));
                quad(pose,v,next,tip,up,.055,r,g,blue,215);
                quad(pose,v,next,tip,side,.027,245,245,255,240);
            }
            previous=next;
        }
    }
    /** Eight crossed rising tongues of color, arranged into a whole enclosed wall of flame. */
    private static void drawFire(PoseStack pose,VertexConsumer v,Entity entity,int color,double time) {
        double cx=entity.getX(),cy=entity.getY(),cz=entity.getZ();
        int r=(color>>16)&255,g=(color>>8)&255,b=color&255;
        for(int i=0;i<48;i++) {
            double a=i*Math.PI*2/48;
            Vec3 outward=new Vec3(Math.cos(a),0,Math.sin(a));
            Vec3 tangent=new Vec3(-Math.sin(a),0,Math.cos(a));
            double radius=3.0 + .10*Math.sin(time*.2+i*.73);
            Vec3 root=new Vec3(cx+outward.x*radius,cy+.1,cz+outward.z*radius);
            double height=1.6+.42*Math.sin(time*.38+i*1.8)+.2*Math.sin(i*.6);
            Vec3 middle=root.add(tangent.scale(.12*Math.sin(time*.32+i))).add(0,height*.6,0);
            Vec3 tip=root.add(outward.scale(.24*Math.cos(time*.25+i*2)))
                .add(tangent.scale(.21*Math.sin(time*.4+i))).add(0,height,0);
            // Segmented taper produces a flame tongue instead of a static post.
            quad(pose,v,root,middle,tangent,.20,r,g,b,165);
            quad(pose,v,root,middle,outward,.17,r,g,b,165);
            quad(pose,v,middle,tip,tangent,.11,255,Math.min(255,g+40),Math.min(255,b+20),200);
            quad(pose,v,middle,tip,outward,.10,r,g,b,190);
        }
    }
    private static void quad(PoseStack pose,VertexConsumer v,Vec3 a,Vec3 b,Vec3 perpendicular,
                             double width,int red,int green,int blue,int alpha) {
        Vec3 offset=perpendicular.normalize().scale(width);
        PoseStack.Pose matrix=pose.last();
        vertex(matrix,v,a.add(offset),red,green,blue,alpha);
        vertex(matrix,v,a.subtract(offset),red,green,blue,alpha);
        vertex(matrix,v,b.subtract(offset),red,green,blue,alpha);
        vertex(matrix,v,b.add(offset),red,green,blue,alpha);
    }
    private static void vertex(PoseStack.Pose matrix,VertexConsumer v,Vec3 p,int r,int g,int b,int a) {
        v.vertex(matrix.pose(),(float)p.x,(float)p.y,(float)p.z).color(r,g,b,a).endVertex();
    }
}
