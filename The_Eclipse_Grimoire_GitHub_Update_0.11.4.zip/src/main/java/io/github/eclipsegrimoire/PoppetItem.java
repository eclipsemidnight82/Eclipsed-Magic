package io.github.eclipsegrimoire;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Bloodbound poppets are produced by crafting; old 0.10.x bound dolls still work. */
public final class PoppetItem extends Item {
    public PoppetItem(Properties properties){super(properties);}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(!(player instanceof ServerPlayer witch))return InteractionResultHolder.success(stack);
        if(stack.hasTag()&&stack.getTag().hasUUID("Target")) {
            CompoundTag tag=stack.getTag();
            if(witch.isShiftKeyDown() && (!tag.hasUUID("Binder")||witch.getUUID().equals(tag.getUUID("Binder")))) {
                String name=tag.getString("Name");stack.setTag(null);
                witch.sendSystemMessage(Component.literal("[Eclipse] You released the poppet's bond to "+name+"."));
            } else witch.sendSystemMessage(Component.literal("[Eclipse] Bound to "+tag.getString("Name")+". Use a ritual pin, or sneak-use to unbind."));
        } else witch.sendSystemMessage(Component.literal("[Eclipse] Craft an unbound poppet together with a filled blood taglock to infuse it."));
        return InteractionResultHolder.success(stack);
    }
    @Override public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip,
                                           net.minecraft.world.item.TooltipFlag flag) {
        if (stack.hasTag() && stack.getTag().hasUUID("Target")) {
            tooltip.add(Component.literal("Bloodbound to: " + stack.getTag().getString("Name"))
                .withStyle(ChatFormatting.LIGHT_PURPLE));
            if (stack.getTag().getInt("WardCharge") > 0)
                tooltip.add(Component.literal("Protective ward: 1 life").withStyle(ChatFormatting.GOLD));
            else if (stack.getTag().contains("WardCharge"))
                tooltip.add(Component.literal("Protective ward spent. Recharge with a golden apple.").withStyle(ChatFormatting.GRAY));
            else tooltip.add(Component.literal("A living sympathetic link").withStyle(ChatFormatting.GRAY));
        } else tooltip.add(Component.literal("Unbound - craft with a blood taglock").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack, level, tooltip, flag);
    }
    @Override public Component getName(ItemStack stack){
        if(stack.hasTag()&&stack.getTag().getInt("WardCharge")>0)return Component.literal("Protective Bloodbound Poppet");
        return super.getName(stack);
    }
    @Override public boolean isFoil(ItemStack stack){return stack.hasTag()&&stack.getTag().hasUUID("Target");}

}
