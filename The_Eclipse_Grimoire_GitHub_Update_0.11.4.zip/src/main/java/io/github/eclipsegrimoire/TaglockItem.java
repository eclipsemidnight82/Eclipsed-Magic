package io.github.eclipsegrimoire;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Reusable glass vial and needle. The blood state is saved on the SAME item. */
public final class TaglockItem extends Item {
    public TaglockItem(Properties properties){super(properties);}
    public static boolean filled(ItemStack stack){return stack.is(EclipseMod.TAGLOCK.get())&&stack.hasTag()&&stack.getTag().hasUUID("Target");}
    public static void empty(ItemStack stack){if(stack.is(EclipseMod.TAGLOCK.get()))stack.setTag(null);}
    public static void collect(ItemStack stack,LivingEntity target,ServerPlayer witch){
        CompoundTag tag=stack.getOrCreateTag();
        tag.putUUID("Target",target.getUUID());
        tag.putString("Name",target.getName().getString());
        tag.putString("Dimension",target.level().dimension().location().toString());
        tag.putBoolean("Blood",true);
        tag.putBoolean("PlayerBlood",target instanceof Player);
        witch.sendSystemMessage(Component.literal("[Eclipse] Blood collected from "+target.getName().getString()+". The vial is now filled."));
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(!(player instanceof ServerPlayer witch))return InteractionResultHolder.success(stack);
        if(filled(stack)){
            if(player.isShiftKeyDown()) {String name=stack.getTag().getString("Name");empty(stack);witch.sendSystemMessage(Component.literal("[Eclipse] Washed the blood of "+name+" from the vial."));}
            else witch.sendSystemMessage(Component.literal("[Eclipse] Blood of "+stack.getTag().getString("Name")+". Craft with a poppet, or offer it to a relic. Sneak-use to empty."));
        } else collect(stack,witch,witch);
        return InteractionResultHolder.success(stack);
    }
    @Override public InteractionResult interactLivingEntity(ItemStack stack,Player player,LivingEntity target,InteractionHand hand){
        if(!(player instanceof ServerPlayer witch))return InteractionResult.SUCCESS;
        if(filled(stack)) {witch.sendSystemMessage(Component.literal("[Eclipse] This vial is already filled. Sneak-use in air to empty it."));return InteractionResult.CONSUME;}
        if(target instanceof ServerPlayer && !witch.server.isPvpAllowed()
            && !CovenData.get(witch.serverLevel()).same(witch.getUUID(),target.getUUID())) {
            witch.sendSystemMessage(Component.literal("[Eclipse] Taking blood from other players requires PvP or shared coven membership."));
            return InteractionResult.CONSUME;
        }
        collect(stack,target,witch);return InteractionResult.CONSUME;
    }
    @Override public boolean isFoil(ItemStack stack){return filled(stack);}
    @Override public void appendHoverText(ItemStack stack,Level level,List<Component> lines,TooltipFlag flag){
        if(filled(stack)){
            lines.add(Component.literal("Blood of: "+stack.getTag().getString("Name")).withStyle(ChatFormatting.RED));
            lines.add(Component.literal("Use in a poppet recipe or on a blood relic.").withStyle(ChatFormatting.GRAY));
        } else lines.add(Component.literal("Right-click yourself or a living target to collect blood.").withStyle(ChatFormatting.GRAY));
        super.appendHoverText(stack,level,lines,flag);
    }
}
