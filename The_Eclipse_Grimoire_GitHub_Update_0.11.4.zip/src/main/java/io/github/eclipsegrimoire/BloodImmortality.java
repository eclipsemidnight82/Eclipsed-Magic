package io.github.eclipsegrimoire;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Blood anchors protect players AND living creatures. World-saved; no cooldown or expiry. */
@Mod.EventBusSubscriber(modid=EclipseMod.MOD_ID,bus=Mod.EventBusSubscriber.Bus.FORGE)
public final class BloodImmortality {
    private BloodImmortality(){}
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public static void onDeath(LivingDeathEvent event){
        LivingEntity subject=event.getEntity();
        if(!(subject.level() instanceof ServerLevel world))return;
        BloodRelicsData data=BloodRelicsData.get(world);
        UUID id=subject.getUUID();
        BloodRelicsData.BloodBond bond=data.chalice(id);
        if(bond!=null){
            // Anchors work with unloaded chunks. If loaded, verify the actual relic still exists.
            ServerLevel anchor=world.getServer().getLevel(net.minecraft.resources.ResourceKey.create(
                net.minecraft.core.registries.Registries.DIMENSION,new net.minecraft.resources.ResourceLocation(bond.dimension())));
            if(anchor==null) {data.removeInvalid(id);return;}
            if(anchor.hasChunkAt(bond.pos())&&(!anchor.getBlockState(bond.pos()).is(EclipseMod.BLOOD_CHALICE_BLOCK.get()) ||
                !anchor.getBlockState(bond.pos()).getValue(BloodChaliceBlock.BLOOD))) {
                data.removeInvalid(id);return;
            }
            rescue(event,subject,"[Eclipse] The Bloodbound Chalice refused your death.");
            if(anchor.hasChunkAt(bond.pos()))anchor.sendParticles(ParticleTypes.ENCHANT,bond.pos().getX()+.5,bond.pos().getY()+1,bond.pos().getZ()+.5,26,.4,.4,.4,.05);
            return;
        }
        // A protective poppet carries one charge, whether in the subject's inventory or on a shelf.
        boolean warded=false;
        if(subject instanceof ServerPlayer player){
            for(int i=0;i<player.getInventory().getContainerSize();i++){
                net.minecraft.world.item.ItemStack doll=player.getInventory().getItem(i);
                if(!doll.is(EclipseMod.POPPET.get())||!doll.hasTag())continue;
                net.minecraft.nbt.CompoundTag tag=doll.getTag();
                if(tag.hasUUID("Target")&&id.equals(tag.getUUID("Target"))&&tag.getInt("WardCharge")>0){
                    tag.putInt("WardCharge",0);warded=true;break;
                }
            }
        }
        if(!warded)warded=data.useShelfWard(id);
        if(warded)rescue(event,subject,"[Eclipse] A protective poppet spent its one life ward.");
    }
    private static void rescue(LivingDeathEvent event,LivingEntity subject,String message){
        event.setCanceled(true);
        subject.setHealth(subject.getMaxHealth());
        subject.clearFire();
        subject.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,3));
        subject.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,120,0));
        ServerLevel world=(ServerLevel)subject.level();
        if(subject.getY()<world.getMinBuildHeight()+3){
            BlockPos spawn=world.getSharedSpawnPos();
            subject.teleportTo(spawn.getX()+.5,spawn.getY()+2,spawn.getZ()+.5);
        }
        world.sendParticles(ParticleTypes.ENCHANT,subject.getX(),subject.getY()+1,subject.getZ(),60,.7,.9,.7,.14);
        world.playSound(null,subject.blockPosition(),SoundEvents.TOTEM_USE,SoundSource.PLAYERS,1.1f,.7f);
        if(subject instanceof ServerPlayer player)player.sendSystemMessage(Component.literal(message));
    }
}
