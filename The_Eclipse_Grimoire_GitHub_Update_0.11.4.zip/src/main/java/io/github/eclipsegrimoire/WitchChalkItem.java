package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/** Draw one color-matched floor rune per use; never overwrites any existing block. */
public final class WitchChalkItem extends Item {
    public WitchChalkItem(Properties props){super(props);}
    public static RunePattern selection(ServerPlayer witch) {
        return RunePattern.of(MagicData.data(witch).getString("runePattern"));
    }
    public static void choose(ServerPlayer witch,RunePattern pattern) {
        MagicData.data(witch).putString("runePattern",pattern.getSerializedName());
        witch.sendSystemMessage(Component.literal("[Eclipse] Witch's Chalk: "+pattern.getSerializedName().toUpperCase()+" rune selected."));
        MagicData.refreshBooks(witch);
    }
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand) {
        if(player.isShiftKeyDown()) {
            if(player instanceof ServerPlayer witch) choose(witch,selection(witch).next());
            return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand),level.isClientSide());
        }
        return super.use(level,player,hand);
    }
    @Override public InteractionResult useOn(UseOnContext ctx) {
        if(ctx.getPlayer() instanceof ServerPlayer witch && witch.isShiftKeyDown()) {
            choose(witch,selection(witch).next());return InteractionResult.CONSUME;
        }
        if(ctx.getClickedFace()!=Direction.UP) return InteractionResult.PASS;
        Level level=ctx.getLevel();BlockPos mark=ctx.getClickedPos().above();
        if(!level.getBlockState(mark).isAir() ||
            !level.getBlockState(ctx.getClickedPos()).isFaceSturdy(level,ctx.getClickedPos(),Direction.UP))
            return InteractionResult.FAIL;
        if(level.isClientSide()) return InteractionResult.SUCCESS;
        if(!(ctx.getPlayer() instanceof ServerPlayer witch)) return InteractionResult.PASS;
        String tint=MagicData.magic(witch);
        var block=EclipseMod.RUNE_BLOCKS.getOrDefault(tint,EclipseMod.RUNE_BLOCKS.get("purple"));
        if(block==null) return InteractionResult.FAIL;
        level.setBlock(mark,block.get().defaultBlockState().setValue(RuneBlock.PATTERN,selection(witch)),3);
        if(!witch.isCreative()) ctx.getItemInHand().hurtAndBreak(1,witch,p->p.broadcastBreakEvent(ctx.getHand()));
        level.playSound(null,mark,SoundEvents.AMETHYST_BLOCK_CHIME,SoundSource.BLOCKS,.55f,1.45f);
        ArcaneEffects.sigil((ServerLevel)level,tint,net.minecraft.world.phys.Vec3.atCenterOf(mark),.8);
        witch.sendSystemMessage(Component.literal("[Eclipse] Drew a "+tint+" "+selection(witch).getSerializedName()+" rune."));
        return InteractionResult.CONSUME;
    }
}
