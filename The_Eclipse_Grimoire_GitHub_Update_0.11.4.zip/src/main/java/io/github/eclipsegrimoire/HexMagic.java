package io.github.eclipsegrimoire;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

/** Short, reversible fantasy hexes. Server-authoritative; no offline/world-unloaded effects. */
public final class HexMagic {
    private HexMagic() { }
    private static final String SILENCE="EclipseSilencedUntil";
    private static final String SILENCE_WORLD="EclipseSilenceDimension";
    private static final String EFFECTS="EclipseActiveHexes";
    private static final String[] TYPES={"hex_weaken","hex_silence","hex_bind","hex_mark"};
    public static boolean isHex(String id) {
        for(String t:TYPES) if(t.equals(id)) return true;
        return false;
    }
    public static boolean silenced(ServerPlayer p) {
        CompoundTag tag=p.getPersistentData();
        return tag.getLong(SILENCE)>p.serverLevel().getGameTime()
            && p.serverLevel().dimension().location().toString().equals(tag.getString(SILENCE_WORLD));
    }
    public static LivingEntity aimed(ServerPlayer caster,int range) {
        Vec3 eye=caster.getEyePosition();
        Vec3 end=eye.add(caster.getLookAngle().scale(range));
        LivingEntity closest=null;
        double distance=Double.MAX_VALUE;
        for(LivingEntity target:caster.serverLevel().getEntitiesOfClass(LivingEntity.class,
            caster.getBoundingBox().inflate(range),t->t!=caster && t.isAlive() && !t.isSpectator())) {
            var clip=target.getBoundingBox().inflate(.3).clip(eye,end);
            if(clip.isEmpty() || !caster.hasLineOfSight(target)) continue;
            double d=eye.distanceToSqr(clip.get());
            if(d<distance){closest=target;distance=d;}
        }
        return closest;
    }
    public static int cast(ServerPlayer caster,String spell) {
        int required=MagicData.requiredLevel(spell);
        if(MagicData.level(caster)<required) {say(caster,"Unlocks at magic level "+required+".");return 0;}
        LivingEntity target=aimed(caster,12);
        if(target==null) {say(caster,"Look directly at a creature or player within 12 blocks.");return 0;}
        return apply(caster,target,spell,18,false);
    }
    /** Returns success, preserving mana and pins on invalid/protected targets. */
    public static int apply(ServerPlayer caster,LivingEntity target,String spell,int cost,boolean linked) {
        if(!isHex(spell) || silenced(caster)) {say(caster,"Your magic is silenced or the hex is unknown.");return 0;}
        if(MagicData.level(caster)<MagicData.requiredLevel(spell)) {
            say(caster,"This hex requires magic level "+MagicData.requiredLevel(spell)+".");return 0;
        }
        if(target==caster || !target.isAlive() || SpellCasting.protectedFrom(caster,target)) {
            say(caster,"Your magic cannot hex yourself, your coven, or a protected familiar.");return 0;
        }
        if(target instanceof ServerPlayer victim && !caster.server.isPvpAllowed()) {
            say(caster,"Player hexes are disabled while server PvP is off.");return 0;
        }
        if(target instanceof ServerPlayer victim && absorbWithCharm(victim)) {
            say(caster,"A protective gris-gris absorbed the hex.");
            victim.sendSystemMessage(Component.literal("[Eclipse] Your gris-gris charm absorbed a hex."));
            return 0;
        }
        if(!MagicData.spend(caster,cost)) {say(caster,"You need "+cost+" mana for that hex.");return 0;}
        CompoundTag tags=target.getPersistentData().getCompound(EFFECTS);
        int duration;
        switch(spell) {
            case "hex_weaken" -> {
                duration=600;target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,duration,1));
                target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,200,0));
            }
            case "hex_silence" -> {
                duration=200;
                if(target instanceof ServerPlayer victim) {
                    victim.getPersistentData().putLong(SILENCE,caster.serverLevel().getGameTime()+duration);
                    victim.getPersistentData().putString(SILENCE_WORLD,caster.serverLevel().dimension().location().toString());
                    say(victim,"A silencing hex prevents spellcasting for 10 seconds. Dispel or cleansing breaks it.");
                } else target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,duration,1));
            }
            case "hex_bind" -> {
                duration=120;target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,duration,6));
                target.addEffect(new MobEffectInstance(MobEffects.JUMP,duration,128));
            }
            case "hex_mark" -> {
                duration=1200;target.addEffect(new MobEffectInstance(MobEffects.GLOWING,duration,0));
            }
            default -> {return 0;}
        }
        tags.putLong(spell,caster.serverLevel().getGameTime()+duration);
        target.getPersistentData().put(EFFECTS,tags);
        ArcaneEffects.chains(caster.serverLevel(),MagicData.magic(caster),target.position());
        caster.serverLevel().playSound(null,target.blockPosition(),SoundEvents.EVOKER_CAST_SPELL,SoundSource.PLAYERS,.9f,.65f);
        MagicData.earnXp(caster,linked?3:4);
        say(caster,(linked?"Poppet magic: ":"Hex cast: ")+spell.substring(4).replace('_',' ')+" on "+target.getName().getString()+".");
        return 1;
    }
    private static boolean absorbWithCharm(ServerPlayer target) {
        long now=target.serverLevel().getGameTime();
        for(int i=0;i<target.getInventory().getContainerSize();i++) {
            ItemStack stack=target.getInventory().getItem(i);
            if(!stack.is(EclipseMod.GRIS_GRIS.get())) continue;
            CompoundTag nbt=stack.getOrCreateTag();
            if(nbt.getLong("nextProtection")>now &&
                target.serverLevel().dimension().location().toString().equals(nbt.getString("protectionWorld"))) continue;
            nbt.putLong("nextProtection",now+1200);
            nbt.putString("protectionWorld",target.serverLevel().dimension().location().toString());
            return true;
        }
        return false;
    }
    public static boolean hasHex(LivingEntity target) {
        CompoundTag all=target.getPersistentData();
        long now=target.level().getGameTime();
        if(all.getLong(SILENCE)>now && target.level().dimension().location().toString().equals(all.getString(SILENCE_WORLD))) return true;
        CompoundTag marks=all.getCompound(EFFECTS);
        for(String type:TYPES) if(marks.getLong(type)>now) return true;
        return false;
    }
    public static boolean cleanse(LivingEntity target) {
        CompoundTag all=target.getPersistentData();
        long now=target.level().getGameTime();
        CompoundTag hexes=all.getCompound(EFFECTS);
        boolean active=hasHex(target);
        if(hexes.getLong("hex_weaken")>now) {
            target.removeEffect(MobEffects.WEAKNESS);target.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
        }
        if(hexes.getLong("hex_bind")>now) {
            target.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);target.removeEffect(MobEffects.JUMP);
        }
        if(hexes.getLong("hex_mark")>now) target.removeEffect(MobEffects.GLOWING);
        if(hexes.getLong("hex_silence")>now) target.removeEffect(MobEffects.WEAKNESS);
        all.remove(SILENCE);all.remove(SILENCE_WORLD);all.remove(EFFECTS);
        return active;
    }
    private static void say(ServerPlayer p,String message) {p.sendSystemMessage(Component.literal("[Eclipse] "+message));}
}
