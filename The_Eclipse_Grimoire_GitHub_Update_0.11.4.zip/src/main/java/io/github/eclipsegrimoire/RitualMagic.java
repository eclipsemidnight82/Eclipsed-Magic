package io.github.eclipsegrimoire;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Five tangible altar rites: chalk focus, three enchanted candles, a cauldron, and a reagent. */
public final class RitualMagic {
    private RitualMagic() { }
    public static final String[] NAMES={"healing","restoration","cleansing","protection","revealing"};
    public static Item ingredient(String rite) {
        return switch(rite) {
            case "healing"->Items.GLISTERING_MELON_SLICE;
            case "restoration"->Items.AMETHYST_SHARD;
            case "cleansing"->Items.MILK_BUCKET;
            case "protection"->Items.IRON_INGOT;
            case "revealing"->Items.GLOWSTONE_DUST;
            default->Items.AIR;
        };
    }
    public static int cast(ServerPlayer caster,String rite) {
        if(ingredient(rite)==Items.AIR) {say(caster,"Rituals: healing, restoration, cleansing, protection, revealing.");return 0;}
        if(HexMagic.silenced(caster)) {say(caster,"Your magic has been silenced.");return 0;}
        if(MagicData.level(caster)<3) {say(caster,"Rituals unlock at magic level 3.");return 0;}
        ServerLevel level=caster.serverLevel();
        HitResult hit=caster.pick(6.0f,0f,false);
        if(!(hit instanceof BlockHitResult block)) {say(caster,"Look at your chalk ritual rune.");return 0;}
        BlockPos center=block.getBlockPos();
        if(!(level.getBlockState(center).getBlock() instanceof RuneBlock rune)) {
            say(caster,"Your ritual needs a chalk rune as its focus.");return 0;
        }
        int candles=0;
        boolean cauldron=false;
        for(BlockPos pos:BlockPos.betweenClosed(center.offset(-3,-1,-3),center.offset(3,2,3))) {
            var state=level.getBlockState(pos);
            if(state.getBlock() instanceof MagicDecorBlock decor && decor.kind()==MagicDecorBlock.Kind.CANDLE) candles++;
            if(state.is(Blocks.CAULDRON) || state.is(Blocks.WATER_CAULDRON)) cauldron=true;
        }
        if(candles<3 || !cauldron) {
            say(caster,"Ritual setup: chalk rune + at least 3 enchanted candles + a cauldron within 3 blocks.");return 0;
        }
        if(!caster.getMainHandItem().is(ingredient(rite))) {
            say(caster,"Hold "+ingredient(rite).getDescription().getString()+" in your main hand.");return 0;
        }
        int manaCost=24;
        if(!MagicData.spend(caster,manaCost)) {say(caster,"This ritual requires 24 mana.");return 0;}
        if(!caster.isCreative()) {
            caster.getMainHandItem().shrink(1);
            if(ingredient(rite)==Items.MILK_BUCKET) {
                net.minecraft.world.item.ItemStack bucket=new net.minecraft.world.item.ItemStack(Items.BUCKET);
                if(!caster.getInventory().add(bucket)) caster.drop(bucket,false);
            }
        }
        AABB area=new AABB(center).inflate(8);
        switch(rite) {
            case "healing" -> {
                for(LivingEntity living:level.getEntitiesOfClass(LivingEntity.class,area,
                    e->e.isAlive() && (e==caster || SpellCasting.protectedFrom(caster,e)))) living.heal(10f);
            }
            case "restoration" -> {
                MagicData.mana(caster,Math.min(MagicData.maxMana(caster),MagicData.mana(caster)+85));
                for(ServerPlayer ally:level.getEntitiesOfClass(ServerPlayer.class,area,
                    p->p!=caster && CovenData.get(level).same(p.getUUID(),caster.getUUID())))
                    MagicData.mana(ally,MagicData.mana(ally)+55);
            }
            case "cleansing" -> {
                HexMagic.cleanse(caster);
                for(ServerPlayer ally:level.getEntitiesOfClass(ServerPlayer.class,area,
                    p->CovenData.get(level).same(p.getUUID(),caster.getUUID()))) HexMagic.cleanse(ally);
            }
            case "protection" -> {
                for(LivingEntity living:level.getEntitiesOfClass(LivingEntity.class,area,
                    e->e.isAlive() && (e==caster || SpellCasting.protectedFrom(caster,e))))
                    living.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,1200,1));
            }
            case "revealing" -> {
                for(LivingEntity living:level.getEntitiesOfClass(LivingEntity.class,area.inflate(8),
                    e->e.isAlive() && e!=caster && !SpellCasting.protectedFrom(caster,e)))
                    living.addEffect(new MobEffectInstance(MobEffects.GLOWING,300,0));
            }
            default -> {return 0;}
        }
        MagicData.earnXp(caster,10);
        ArcaneEffects.sigil(level,rune.color(),Vec3.atCenterOf(center),2.8);
        level.sendParticles(ParticleTypes.ENCHANT,center.getX()+.5,center.getY()+1.2,center.getZ()+.5,
            75,1.8,.9,1.8,.16);
        level.playSound(null,center,SoundEvents.ENCHANTMENT_TABLE_USE,SoundSource.BLOCKS,1.2f,.7f);
        say(caster,"Rite of "+rite+" completed. The altar's magic answers your call.");
        return 1;
    }
    private static void say(ServerPlayer p,String s) {p.sendSystemMessage(Component.literal("[Eclipse] "+s));}
}
