package io.github.eclipsegrimoire;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Server-side, one-use binding floor runes. World saves contain only armed trap ownership,
 *  while captured creatures are freed on restart and after 60 seconds. */
public final class RuneMagic {
    private RuneMagic() {}
    private record Hold(Vec3 position,long until,String color) {}
    private static final Map<ServerLevel,Map<UUID,Hold>> HELD=new WeakHashMap<>();
    private static Map<UUID,Hold> held(ServerLevel level){return HELD.computeIfAbsent(level,k->new HashMap<>());}

    public static int cast(ServerPlayer p) {
        int needed=MagicData.requiredLevel("rune_bind");
        if(MagicData.level(p)<needed) {p.sendSystemMessage(Component.literal("[Eclipse] Bind Rune unlocks at level "+needed+"."));return 0;}
        HitResult hit=p.pick(8,0,false);
        if(!(hit instanceof BlockHitResult target)) {p.sendSystemMessage(Component.literal("[Eclipse] Look at a Binding chalk rune."));return 0;}
        BlockPos pos=target.getBlockPos();
        if(!(p.serverLevel().getBlockState(pos).getBlock() instanceof RuneBlock) ||
            p.serverLevel().getBlockState(pos).getValue(RuneBlock.PATTERN)!=RunePattern.BINDING) {
            p.sendSystemMessage(Component.literal("[Eclipse] Choose BINDING chalk, draw its rune, then aim at it."));return 0;
        }
        if(!MagicData.spend(p,14)) {p.sendSystemMessage(Component.literal("[Eclipse] Bind Rune requires 14 mana."));return 0;}
        WitchcraftData.get(p.serverLevel()).armRune(pos,p.getUUID());
        ArcaneEffects.sigil(p.serverLevel(),MagicData.magic(p),Vec3.atBottomCenterOf(pos).add(0,.07,0),.8);
        p.serverLevel().playSound(null,pos,SoundEvents.EVOKER_PREPARE_ATTACK,SoundSource.BLOCKS,.8f,1.15f);
        p.sendSystemMessage(Component.literal("[Eclipse] Binding Rune armed. The next outsider will be held for 60 seconds."));
        MagicData.earnXp(p,5);
        return 1;
    }
    public static boolean release(ServerLevel level,UUID target) {return held(level).remove(target)!=null;}
    public static boolean isHeld(ServerLevel level,UUID target) {return held(level).containsKey(target);}
    public static void tick(ServerLevel level) {
        long now=level.getGameTime();
        var map=held(level);
        for(var iterator=map.entrySet().iterator();iterator.hasNext();) {
            var entry=iterator.next();
            Entity e=level.getEntity(entry.getKey());
            Hold hold=entry.getValue();
            if(e==null || !e.isAlive() || now>=hold.until) {iterator.remove();continue;}
            e.setDeltaMovement(Vec3.ZERO);
            if(e.position().distanceToSqr(hold.position)>.002) {
                if(e instanceof ServerPlayer p) p.connection.teleport(hold.position.x,hold.position.y,hold.position.z,p.getYRot(),p.getXRot());
                else e.setPos(hold.position.x,hold.position.y,hold.position.z);
            }
            e.fallDistance=0;
            if(now%10==0) ArcaneEffects.chains(level,hold.color,e.position());
        }
        if(now%2!=0) return;
        for(var entry:WitchcraftData.get(level).armedRunes().entrySet()) {
            BlockPos pos=BlockPos.of(entry.getKey());
            if(!level.hasChunkAt(pos)) continue;
            if(!(level.getBlockState(pos).getBlock() instanceof RuneBlock b) ||
                level.getBlockState(pos).getValue(RuneBlock.PATTERN)!=RunePattern.BINDING) {
                WitchcraftData.get(level).disarmRune(pos);continue;
            }
            if(now%20==0) ArcaneEffects.ring(level,b.color(),Vec3.atBottomCenterOf(pos).add(0,.07,0),.6,16);
            AABB zone=new AABB(pos).inflate(.05,.32,.05);
            for(LivingEntity intruder:level.getEntitiesOfClass(LivingEntity.class,zone,
                e->e.isAlive() && !e.isSpectator())) {
                if(intruder instanceof ServerPlayer player && (player.isCreative() || player.isSpectator()
                    || !player.server.isPvpAllowed())) continue;
                if(WardData.canCross(level,entry.getValue(),intruder) || map.containsKey(intruder.getUUID())) continue;
                if(intruder.getVehicle()!=null) continue; // do not desync mounts or trap riders inside vehicles
                WitchcraftData.get(level).disarmRune(pos);
                map.put(intruder.getUUID(),new Hold(intruder.position(),now+1200,b.color()));
                intruder.setDeltaMovement(Vec3.ZERO);
                level.playSound(null,pos,SoundEvents.EVOKER_CAST_SPELL,SoundSource.BLOCKS,1f,.75f);
                ArcaneEffects.chains(level,b.color(),intruder.position());
                if(intruder instanceof ServerPlayer victim)
                    victim.sendSystemMessage(Component.literal("[Eclipse] A binding rune holds you for one minute. Dispel can free you."));
                break;
            }
        }
    }
}
