# Alpha 0.11.4 — Final Visual Consistency Fix

- Fixed the Witch’s Bell missing-texture checkerboard in both inventory and placed block by replacing a null particle texture reference with a valid model texture (`#frame`). The same 3D block model is used for both states.
- Reworked the blood-filled Taglock Vial sprite using the exact empty vial as the base: glass outline, cylindrical bottle silhouette, bottle cap, and needle are pixel-identical; only the inner liquid region changes to red.
- All gameplay features and saved-data formats remain unchanged from working Alpha 0.11.3.

## Still to verify in Minecraft
- No black/magenta missing-texture checkerboard on the Witch’s Bell in Creative Inventory or when placed.
- Empty and filled Taglock Vials have identical outer shapes and visible red contents only in the filled state.
- The existing scrying, chalice, poppet, coven, familiar, and ritual features remain functional.

Do not publish publicly until the new Forge build and in-game check both pass.
