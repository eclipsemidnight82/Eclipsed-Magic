# Alpha 0.11.3 — visual test before publishing

1. Confirm GitHub workflow builds **0.11.3-alpha** JAR.
2. In a backup 1.20.1 Forge world, place an unbound Scrying Crystal. Confirm glassy/translucent gem, visible pedestal, and no black or pink missing-texture areas. Bind with blood and confirm color difference, little particles and unchanged target-list behavior.
3. Place empty Chalice: bowl looks hollow/dark; bind to donor: **red liquid surface becomes visible**. Empty with sneak-use: red liquid disappears. Confirm immortality still works.
4. Hover/use an empty Blood Taglock. Collect blood from self or mob: item artwork switches to filled red bottle; empty it: icon switches back; tooltip shows donor.
5. Craft blood taglock + poppet: doll becomes bloodbound (red thread). Craft charged poppet with golden apple: shows protective golden rune. Item name/tooltip and ward behavior work.
6. Check Wardstone and Witch's Bell geometry is visible on all sides, no black/pink textures; bell rings; wardstone still repels enemies. Check occupied Poppet Reliquary.
7. Inspect all four ritual pin icons, chalk, mana draught, curse bottle, gris-gris and familiar charm at GUI scales 2 and 3.
8. Scrying first-person view, Remove/Confirm, cast away familiar, all other old features still operate.
9. Test multiplayer and rejoin/restart persistence; inspect side views, inventory previews, daytime/nighttime lighting.
10. Only after all tests pass: call it the public release candidate. Remove older JARs and maintain a world backup.
