# Alpha 0.11.1 true scrying gameplay tests

1. Back up the world and install the 0.11.1 JAR on the client and server.
2. Bind a scry crystal using blood from a second player, standing nearby.
3. Right click with an empty hand. The actual world should render from the other player's moving and turning first-person camera. No overhead tiles.
4. Press ESC or End Vision; the original position and camera mode should be restored.
5. Test while the other player moves and turns their head; try a nearby wolf or other living mob.
6. Try a target outside client tracking distance: expect a clear error message, not a fake map.
7. Test player disconnect/death, target leaving dimension, crystal break, your death, and a Gris-Gris charm on the target.
8. Confirm the original blood chalice, protective poppets, taglocks, rituals, runes, and book still work.

Expected limitations: same dimension and already client-tracked target only. No cross-dimensional or truly far-distance first-person camera until a remote world streaming layer is implemented.
