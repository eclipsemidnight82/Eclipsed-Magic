package io.github.eclipsegrimoire;

import java.util.List;
import java.util.UUID;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

/** Saved per-player magic, simple progression and portable grimoire UI snapshot. */
public final class MagicData {
    private MagicData() { }
    public static final String KEY="EclipseGrimoire";
    public static final String DEFAULT_BOOK="The Eclipse Grimoire";
    public static final List<String> COLORS=List.of("purple","crimson","blue","emerald","gold","white","shadow","rose");
    public static final int LEVEL_CAP=20;
    public static final List<String> BOOK_STYLES=List.of("regal","gothic","natural","celestial","relic");

    public static CompoundTag data(ServerPlayer player) {
        CompoundTag root=player.getPersistentData();
        if(!root.contains(KEY,10)) {
            CompoundTag initial=new CompoundTag();
            initial.putInt("mana",100); initial.putString("name",DEFAULT_BOOK);
            initial.putString("magicColor","purple"); initial.putString("uiColor","shadow");
            initial.putInt("level",1); initial.putInt("xp",0); initial.putString("bookStyle","regal");
            root.put(KEY,initial);
        }
        CompoundTag tag=root.getCompound(KEY);
        // Existing Alpha 0.1/0.2 characters safely start at level one.
        if(!tag.contains("level")) tag.putInt("level",1);
        if(!tag.contains("xp")) tag.putInt("xp",0);
        return tag;
    }
    public static int level(ServerPlayer p) {return Math.max(1,Math.min(LEVEL_CAP,data(p).getInt("level")));}
    public static int xp(ServerPlayer p) {return Math.max(0,data(p).getInt("xp"));}
    public static int xpToNext(int level) {return level>=LEVEL_CAP?0:20+level*15;}
    public static int maxMana(ServerPlayer p) {return 100+(level(p)-1)*20;}
    public static int mana(ServerPlayer p) {return Math.max(0,Math.min(maxMana(p),data(p).getInt("mana")));}
    public static void mana(ServerPlayer p,int value) {data(p).putInt("mana",Math.max(0,Math.min(maxMana(p),value)));}
    public static boolean spend(ServerPlayer p,int cost) {
        if(p.isCreative()) return true;
        if(mana(p)<cost) return false;
        mana(p,mana(p)-cost);return true;
    }
    public static int requiredLevel(String spell) {
        return switch(spell) {
            case "ward","power","mend" -> 1;
            case "veil","bind","tether","pulse" -> 2;
            case "circle","seal","absolute","infuse" -> 3;
            case "thunder","shatter","blink" -> 4;
            case "aegis","witchfire" -> 6;
            default -> Integer.MAX_VALUE;
        };
    }
    public static void earnXp(ServerPlayer p,int amount) {
        if(amount<=0 || level(p)>=LEVEL_CAP) return;
        CompoundTag tag=data(p);
        int level=level(p), xp=xp(p)+amount, oldMax=100+(level-1)*20;
        while(level<LEVEL_CAP && xp>=xpToNext(level)) {
            xp-=xpToNext(level);level++;
            p.sendSystemMessage(Component.literal("[Eclipse] LEVEL UP! Magic level " + level + " — maximum mana " + (100+(level-1)*20) + "."));
        }
        tag.putInt("level",level);
        tag.putInt("xp",level>=LEVEL_CAP?0:xp);
        if(100+(level-1)*20>oldMax) mana(p,mana(p)+(100+(level-1)*20-oldMax));
        refreshBooks(p);
    }
    public static String name(ServerPlayer p) {return data(p).getString("name");}
    public static String magic(ServerPlayer p) {return data(p).getString("magicColor");}
    public static String ui(ServerPlayer p) {return data(p).getString("uiColor");}
    public static String style(ServerPlayer p) {
        String value=data(p).getString("bookStyle");
        return BOOK_STYLES.contains(value)?value:"regal";
    }
    /** Familiar roster is stored on the witch, not as a volatile client-side search. */
    public static void registerFamiliar(ServerPlayer p,TamableAnimal pet) {
        CompoundTag d=data(p);
        ListTag roster=d.getList("familiars",10);
        for(int i=0;i<roster.size();i++) if(roster.getCompound(i).hasUUID("id")
            && pet.getUUID().equals(roster.getCompound(i).getUUID("id"))) roster.remove(i--);
        CompoundTag record=new CompoundTag();
        record.putUUID("id",pet.getUUID());
        record.putString("name",pet.getName().getString());
        record.putString("type",pet.getType().getDescription().getString());
        roster.add(record);
        while(roster.size()>32) roster.remove(0);
        d.put("familiars",roster);
    }
    public static ItemStack newBook(ServerPlayer p) {ItemStack stack=new ItemStack(EclipseMod.GRIMOIRE.get());stamp(stack,p);return stack;}
    public static void stamp(ItemStack stack,ServerPlayer p) {
        CompoundTag tag=stack.getOrCreateTag();
        tag.putString("eclipseName",name(p));
        tag.putString("eclipseMagic",magic(p));
        tag.putString("eclipseUI",ui(p));
        tag.putString("eclipseStyle",style(p));
        tag.putInt("eclipseLevel",level(p));
        tag.putInt("eclipseXp",xp(p));
        tag.putInt("eclipseXpNext",xpToNext(level(p)));
        tag.putInt("eclipseMana",mana(p));
        tag.putInt("eclipseMaxMana",maxMana(p));
        CovenData covens=CovenData.get(p.serverLevel());
        tag.putString("eclipseCoven",covens.of(p.getUUID()));
        tag.putString("eclipseInvite",covens.pending(p.getUUID()));
        String ownCoven=covens.of(p.getUUID());
        ListTag online=new ListTag(), members=new ListTag();
        for(ServerPlayer other:p.server.getPlayerList().getPlayers()) {
            String username=other.getGameProfile().getName();
            if(!other.getUUID().equals(p.getUUID()) && online.size()<80)
                online.add(StringTag.valueOf(username));
            if(!ownCoven.isEmpty() && ownCoven.equals(covens.of(other.getUUID())) && members.size()<80)
                members.add(StringTag.valueOf(username));
        }
        tag.put("eclipseOnlinePlayers",online);
        tag.put("eclipseCovenMembers",members);
        tag.putInt("eclipseCovenCount",ownCoven.isEmpty()?0:covens.count(ownCoven));
        ListTag familiarSnapshot=new ListTag();
        ListTag roster=data(p).getList("familiars",10);
        for(int i=0;i<roster.size() && i<32;i++) {
            CompoundTag entry=roster.getCompound(i).copy();
            if(!entry.hasUUID("id")) continue;
            Entity entity=p.serverLevel().getEntity(entry.getUUID("id"));
            boolean near=entity!=null && entity.isAlive();
            entry.putBoolean("near",near);
            if(near) {
                entry.putString("name",entity.getName().getString());
                entry.putInt("distance",(int)Math.round(entity.distanceTo(p)));
                if(entity instanceof net.minecraft.world.entity.LivingEntity living)
                    entry.putInt("health",(int)Math.ceil(living.getHealth()));
            }
            familiarSnapshot.add(entry);
        }
        tag.put("eclipseFamiliars",familiarSnapshot);
        stack.setHoverName(Component.literal(name(p)));
    }
    public static void refreshBooks(ServerPlayer p) {
        for(int i=0;i<p.getInventory().getContainerSize();i++) {
            ItemStack item=p.getInventory().getItem(i);
            if(item.is(EclipseMod.GRIMOIRE.get())) stamp(item,p);
        }
        p.getInventory().setChanged();
    }
}
