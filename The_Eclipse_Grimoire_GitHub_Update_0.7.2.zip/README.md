# The Eclipse Grimoire — Alpha 0.7.2 (Forge 1.20.1)

Small usability update based on multiplayer gameplay testing of Alpha 0.7.1. All existing 0.7.1 systems are retained.

## Absolute Seal — visible spell (Level 3, 12 mana)
- Open the Warding Arts chapter, then select **Absolute Seal**. It also appears in the configurable spell wheel when unlocked.
- Or use `/eclipse cast absolute`. Aim at an already-salted/warded door, or an enchanted salt threshold spanning a framed opening within 8 blocks.
- Absolute Seal prevents all entities (including the owner and coven) crossing. It is **not** the same as Seal Salt, which can enchant ordinary lines.
- An invalid/unframed/unwarded target will not use mana.
- Emergency exit: `/eclipse ward release` within 12 blocks, by the owner or an operator. Shatter also removes wards.
- The old `/eclipse cast seal` command retains its previous behavior for backwards compatibility.

## Responsive grimoire sizing
- The entire book is now 82% of the former size by default, and automatically shrinks further on small screens and high GUI scale.
- Page elements, buttons, spell descriptions and text fields receive the same scale and mouse coordinate transform.
- All book style/color and page turn features remain intact.

## Build
Upload `The_Eclipse_Grimoire_GitHub_Update_0.7.2.zip` at repository root and replace `.github/workflows/build.yml` with the supplied new workflow. The ZIP extracts over the `eclipse_grimoire_safe_build` Forge project. Keep your working Alpha 0.7.1 JAR as a backup until you test.

This source contains the fixed Forge 1.20.1 vertex API from Build #21 (`matrix.pose()`) so the next build does not depend on a corrective patch.
